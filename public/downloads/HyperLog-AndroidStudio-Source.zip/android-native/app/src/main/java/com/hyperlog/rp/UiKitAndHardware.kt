package com.hyperlog.rp

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView

data class RirVisualPalette(
    val bgColor: Int,
    val borderColor: Int,
    val textColor: Int,
    val statusWord: String
)

object UiKit {
    var themeMode: AppThemeMode = AppThemeMode.DAYLIGHT

    val isDark: Boolean get() = themeMode.isDark

    val COL_BG: Int
        get() = when (themeMode) {
            AppThemeMode.DAYLIGHT -> 0xFFF8FAFC.toInt()
            AppThemeMode.NIGHT_SLATE -> 0xFF0B1120.toInt()
            AppThemeMode.AMOLED -> 0xFF000000.toInt()
            AppThemeMode.GRAPHITE -> 0xFF121316.toInt()
        }

    val COL_CARD: Int
        get() = when (themeMode) {
            AppThemeMode.DAYLIGHT -> 0xFFFFFFFF.toInt()
            AppThemeMode.NIGHT_SLATE -> 0xFF131C2E.toInt()
            AppThemeMode.AMOLED -> 0xFF0D0D12.toInt()
            AppThemeMode.GRAPHITE -> 0xFF1B1D22.toInt()
        }

    val COL_SUBTLE: Int
        get() = when (themeMode) {
            AppThemeMode.DAYLIGHT -> 0xFFF1F5F9.toInt()
            AppThemeMode.NIGHT_SLATE -> 0xFF1A253B.toInt()
            AppThemeMode.AMOLED -> 0xFF16161F.toInt()
            AppThemeMode.GRAPHITE -> 0xFF24272E.toInt()
        }

    val COL_BORDER: Int
        get() = when (themeMode) {
            AppThemeMode.DAYLIGHT -> 0xFFE2E8F0.toInt()
            AppThemeMode.NIGHT_SLATE -> 0xFF26334D.toInt()
            AppThemeMode.AMOLED -> 0xFF242432.toInt()
            AppThemeMode.GRAPHITE -> 0xFF30343E.toInt()
        }

    val COL_TEXT_DARK: Int
        get() = when (themeMode) {
            AppThemeMode.DAYLIGHT -> 0xFF0F172A.toInt()
            AppThemeMode.NIGHT_SLATE -> 0xFFF1F5F9.toInt()
            AppThemeMode.AMOLED -> 0xFFF8FAFC.toInt()
            AppThemeMode.GRAPHITE -> 0xFFF3F4F6.toInt()
        }

    val COL_TEXT_MID: Int
        get() = when (themeMode) {
            AppThemeMode.DAYLIGHT -> 0xFF334155.toInt()
            AppThemeMode.NIGHT_SLATE -> 0xFFCBD5E1.toInt()
            AppThemeMode.AMOLED -> 0xFFD4D4D8.toInt()
            AppThemeMode.GRAPHITE -> 0xFFD1D5DB.toInt()
        }

    val COL_TEXT_MUTED: Int
        get() = when (themeMode) {
            AppThemeMode.DAYLIGHT -> 0xFF64748B.toInt()
            AppThemeMode.NIGHT_SLATE -> 0xFF94A3B8.toInt()
            AppThemeMode.AMOLED -> 0xFFA1A1AA.toInt()
            AppThemeMode.GRAPHITE -> 0xFF9CA3AF.toInt()
        }

    val COL_ACCENT: Int
        get() = if (isDark) 0xFF3B82F6.toInt() else 0xFF2563EB.toInt()

    val COL_CHIP_IDLE: Int
        get() = COL_SUBTLE

    val COL_CHIP_ACTIVE_BG: Int
        get() = if (isDark) 0xFF2563EB.toInt() else 0xFF0F172A.toInt()

    const val COL_PURE_WHITE = 0xFFFFFFFF.toInt()

    val COL_ROW_COMPLETED: Int
        get() = if (isDark) 0xFF102A25.toInt() else 0xFFECFDF5.toInt()

    fun dialogTheme(): Int =
        if (isDark) android.R.style.Theme_Material_Dialog_Alert
        else android.R.style.Theme_Material_Light_Dialog_Alert

    /**
     * Immediate Color-Coded RIR Proximity Feedback:
     * - Green for 1–3 RIR (Optimal hypertrophy proximity)
     * - Yellow for <1 RIR (0 or 0.5 RIR — failure / near-failure)
     * - Neutral Slate for 4+ RIR (Warmup / Deload)
     */
    fun rirPalette(rir: Double): RirVisualPalette {
        return when {
            rir < 1.0 -> RirVisualPalette(
                bgColor = if (isDark) 0xFF422006.toInt() else 0xFFFEF9C3.toInt(),
                borderColor = if (isDark) 0xFFEAB308.toInt() else 0xFFCA8A04.toInt(),
                textColor = if (isDark) 0xFFFDE047.toInt() else 0xFF854D0E.toInt(),
                statusWord = "High Fatigue"
            )
            rir <= 3.0 -> RirVisualPalette(
                bgColor = if (isDark) 0xFF064E3B.toInt() else 0xFFDCFCE7.toInt(),
                borderColor = if (isDark) 0xFF10B981.toInt() else 0xFF16A34A.toInt(),
                textColor = if (isDark) 0xFF6EE7B7.toInt() else 0xFF166534.toInt(),
                statusWord = "Target Zone"
            )
            else -> RirVisualPalette(
                bgColor = COL_SUBTLE,
                borderColor = COL_BORDER,
                textColor = COL_TEXT_MID,
                statusWord = "Deload"
            )
        }
    }

    fun dp(ctx: Context, v: Int): Int =
        (v * ctx.resources.displayMetrics.density).toInt()

    fun roundedBg(fillColor: Int, radiusDp: Float, ctx: Context, strokeColor: Int = 0, strokeWidthDp: Float = 0f): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusDp * ctx.resources.displayMetrics.density
            setColor(fillColor)
            if (strokeWidthDp > 0f) {
                setStroke((strokeWidthDp * ctx.resources.displayMetrics.density).toInt().coerceAtLeast(1), strokeColor)
            }
        }
    }

    fun card(ctx: Context, borderColor: Int = COL_BORDER, borderDp: Float = 1f, padDp: Int = 14): LinearLayout {
        return LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedBg(COL_CARD, 14f, ctx, borderColor, borderDp)
            val p = dp(ctx, padDp)
            setPadding(p, p, p, p)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dp(ctx, 12)
            }
        }
    }

    fun metricBox(ctx: Context, label: String, value: String, valueColor: Int = COL_TEXT_DARK): LinearLayout {
        return LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = roundedBg(COL_SUBTLE, 10f, ctx, COL_BORDER, 1f)
            val px = dp(ctx, 6)
            val py = dp(ctx, 7)
            setPadding(px, py, px, py)
            addView(text(ctx, label, 10f, COL_TEXT_MUTED, bold = true).apply { gravity = Gravity.CENTER })
            addView(spacerV(ctx, 2))
            addView(text(ctx, value, 13f, valueColor, bold = true, tabular = true).apply { gravity = Gravity.CENTER })
        }
    }

    fun text(
        ctx: Context,
        str: String,
        sizeSp: Float = 13f,
        color: Int = COL_TEXT_DARK,
        bold: Boolean = false,
        tabular: Boolean = false
    ): TextView {
        return TextView(ctx).apply {
            text = str
            textSize = sizeSp
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            if (tabular) fontFeatureSettings = "tnum"
        }
    }

    fun chip(ctx: Context, label: String, active: Boolean, onClick: () -> Unit): TextView {
        return TextView(ctx).apply {
            text = label
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(if (active) COL_PURE_WHITE else COL_TEXT_MID)
            background = roundedBg(
                fillColor = if (active) COL_CHIP_ACTIVE_BG else COL_CHIP_IDLE,
                radiusDp = 10f,
                ctx = ctx,
                strokeColor = if (active) COL_CHIP_ACTIVE_BG else COL_BORDER,
                strokeWidthDp = 1f
            )
            val px = dp(ctx, 12)
            val py = dp(ctx, 8)
            setPadding(px, py, px, py)
            gravity = Gravity.CENTER
            setOnClickListener { onClick() }
        }
    }

    fun rirDropdownSpinner(ctx: Context, currentRir: Double, onSelected: (Double) -> Unit): Spinner {
        val labels = RIR_OPTIONS.map { "${formatRirShort(it)} ▾" }
        val dropdownLabels = listOf(
            "0 RIR · Failure (<1 Yellow)",
            "0.5 RIR · Near Fail (<1 Yellow)",
            "1 RIR · Optimal (1–3 Green)",
            "2 RIR · Optimal (1–3 Green)",
            "3 RIR · Optimal (1–3 Green)",
            "4+ RIR · Warmup / Deload"
        )
        val initialIdx = RIR_OPTIONS.indexOfFirst { kotlin.math.abs(it - currentRir) < 0.05 }.let { if (it >= 0) it else 2 }
        val pal = rirPalette(currentRir)

        return Spinner(ctx, Spinner.MODE_DROPDOWN).apply {
            background = roundedBg(pal.bgColor, 9f, ctx, pal.borderColor, 1.4f)
            minimumHeight = dp(ctx, 38)
            val adapter = object : ArrayAdapter<String>(ctx, android.R.layout.simple_spinner_item, labels) {
                override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                    val optRir = RIR_OPTIONS.getOrElse(position) { currentRir }
                    val p = rirPalette(optRir)
                    return TextView(ctx).apply {
                        text = labels[position]
                        textSize = 12f
                        setTypeface(typeface, Typeface.BOLD)
                        fontFeatureSettings = "tnum"
                        setTextColor(p.textColor)
                        gravity = Gravity.CENTER
                        val px = dp(ctx, 8)
                        val py = dp(ctx, 7)
                        setPadding(px, py, px, py)
                    }
                }

                override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
                    val optRir = RIR_OPTIONS.getOrElse(position) { 2.0 }
                    val p = rirPalette(optRir)
                    return TextView(ctx).apply {
                        text = dropdownLabels[position]
                        textSize = 13f
                        setTypeface(typeface, Typeface.BOLD)
                        setTextColor(p.textColor)
                        setBackgroundColor(p.bgColor)
                        val px = dp(ctx, 14)
                        val py = dp(ctx, 11)
                        setPadding(px, py, px, py)
                    }
                }
            }
            this.adapter = adapter
            setSelection(initialIdx, false)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    val chosen = RIR_OPTIONS.getOrElse(position) { currentRir }
                    val newPal = rirPalette(chosen)
                    this@apply.background = roundedBg(newPal.bgColor, 9f, ctx, newPal.borderColor, 1.4f)
                    if (kotlin.math.abs(chosen - currentRir) >= 0.05) {
                        onSelected(chosen)
                    }
                }
                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
        }
    }

    fun hScrollRow(ctx: Context): Pair<HorizontalScrollView, LinearLayout> {
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val hsv = HorizontalScrollView(ctx).apply {
            isHorizontalScrollBarEnabled = false
            addView(row)
        }
        return hsv to row
    }

    fun primaryButton(ctx: Context, label: String, bgColor: Int = COL_CHIP_ACTIVE_BG, onClick: () -> Unit): TextView {
        return TextView(ctx).apply {
            text = label
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(COL_PURE_WHITE)
            gravity = Gravity.CENTER
            minHeight = dp(ctx, 44)
            val px = dp(ctx, 14)
            val py = dp(ctx, 10)
            setPadding(px, py, px, py)
            background = roundedBg(bgColor, 11f, ctx)
            setOnClickListener { onClick() }
        }
    }

    fun outlineButton(ctx: Context, label: String, textColor: Int = COL_TEXT_DARK, onClick: () -> Unit): TextView {
        return TextView(ctx).apply {
            text = label
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(textColor)
            gravity = Gravity.CENTER
            minHeight = dp(ctx, 40)
            val px = dp(ctx, 12)
            val py = dp(ctx, 8)
            setPadding(px, py, px, py)
            background = roundedBg(COL_CARD, 10f, ctx, COL_BORDER, 1f)
            setOnClickListener { onClick() }
        }
    }

    fun progressBar(ctx: Context, fraction: Float, fillColor: Int): View {
        val outer = FrameLayout(ctx).apply {
            background = roundedBg(COL_CHIP_IDLE, 5f, ctx)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(ctx, 9)
            ).apply {
                topMargin = dp(ctx, 6)
                bottomMargin = dp(ctx, 6)
            }
        }
        val clamped = fraction.coerceIn(0f, 1f)
        if (clamped > 0f) {
            outer.post {
                val fillW = (outer.width * clamped).toInt().coerceAtLeast(dp(ctx, 4))
                val inner = View(ctx).apply {
                    background = roundedBg(fillColor, 5f, ctx)
                    layoutParams = FrameLayout.LayoutParams(fillW, FrameLayout.LayoutParams.MATCH_PARENT)
                }
                outer.removeAllViews()
                outer.addView(inner)
            }
        }
        return outer
    }

    fun inputBox(ctx: Context, initialText: String, hintStr: String, inputTypeFlags: Int): EditText {
        return EditText(ctx).apply {
            setText(initialText)
            hint = hintStr
            textSize = 13f
            setTextColor(COL_TEXT_DARK)
            setHintTextColor(COL_TEXT_MUTED)
            inputType = inputTypeFlags
            background = roundedBg(COL_SUBTLE, 9f, ctx, COL_BORDER, 1f)
            val px = dp(ctx, 10)
            val py = dp(ctx, 7)
            setPadding(px, py, px, py)
        }
    }

    fun spacerV(ctx: Context, heightDp: Int): View = View(ctx).apply {
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(ctx, heightDp))
    }

    fun spacerH(ctx: Context, widthDp: Int): View = View(ctx).apply {
        layoutParams = LinearLayout.LayoutParams(dp(ctx, widthDp), 1)
    }
}

object NativeHardwareBridge {
    private fun vibrator(ctx: Context): Vibrator? {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = ctx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
        } catch (_: Exception) {
            null
        }
    }

    fun hasVibrator(ctx: Context): Boolean {
        return try {
            vibrator(ctx)?.hasVibrator() == true
        } catch (_: Exception) {
            false
        }
    }

    fun hapticTick(ctx: Context) {
        try {
            val v = vibrator(ctx) ?: return
            if (v.hasVibrator()) {
                v.vibrate(VibrationEffect.createOneShot(30L, VibrationEffect.DEFAULT_AMPLITUDE))
            }
        } catch (_: Exception) {}
    }

    /**
     * Triple-pulse native vibration motor alert fired when the user-specified rest timer elapses.
     */
    fun hapticRestComplete(ctx: Context) {
        try {
            val v = vibrator(ctx) ?: return
            if (!v.hasVibrator()) return
            if (v.hasAmplitudeControl()) {
                v.vibrate(
                    VibrationEffect.createWaveform(
                        longArrayOf(0L, 280L, 110L, 280L, 110L, 420L),
                        intArrayOf(0, 255, 0, 255, 0, 255),
                        -1
                    )
                )
            } else {
                v.vibrate(VibrationEffect.createWaveform(longArrayOf(0L, 280L, 110L, 280L, 110L, 420L), -1))
            }
        } catch (_: Exception) {}
    }

    fun setKeepScreenOn(activity: Activity, enabled: Boolean) {
        if (enabled) activity.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else activity.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    fun isHealthConnectInstalled(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT >= 34) return true
        return try {
            ctx.packageManager.getPackageInfo("com.google.android.apps.healthdata", 0)
            true
        } catch (_: Exception) {
            false
        }
    }

    fun openHealthConnectOrReportOffline(activity: Activity, summaryLabel: String): String {
        return try {
            val intent = Intent("androidx.health.ACTION_HEALTH_CONNECT_SETTINGS")
            if (intent.resolveActivity(activity.packageManager) != null) {
                activity.startActivity(intent)
                "Opened Android Health Connect for $summaryLabel (Offline SQLite also saved)."
            } else {
                "Saved $summaryLabel locally in Offline SQLite (Health Connect app not installed on this device)."
            }
        } catch (_: Exception) {
            "Saved $summaryLabel locally in Offline SQLite."
        }
    }
}
