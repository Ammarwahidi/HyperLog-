package com.hyperlog.rp

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import java.time.LocalDate
import kotlin.math.roundToInt

class MainActivity : Activity() {

    private lateinit var db: HyperLogDatabase
    private lateinit var rootColumn: LinearLayout
    private lateinit var topBar: LinearLayout
    private lateinit var topDivider: View
    private lateinit var bottomDivider: View
    private lateinit var headerTitleView: TextView
    private lateinit var headerSubtitle: TextView
    private lateinit var themeBtnView: TextView
    private lateinit var backupBtnView: TextView
    private lateinit var bannerView: TextView
    private lateinit var timerBar: LinearLayout
    private lateinit var timerText: TextView
    private lateinit var mainScroll: ScrollView
    private lateinit var pageContent: LinearLayout
    private lateinit var bottomNavRow: LinearLayout

    // Optional live references inside Track tab's inline Rest Timer card so ticks update smoothly without rebuilding EditTexts
    private var inlineTimerClockView: TextView? = null
    private var inlineTimerStatusView: TextView? = null
    private var inlineTimerPlayPauseBtn: TextView? = null

    // UI State
    private var activeTab: Int = 0 // 0=Anatomy, 1=Track, 2=Workouts, 3=Library, 4=Calories
    private var activeWeek: Int = 3
    private var activeDay: Int = 5
    private var activeMajorGroup: MajorMuscleGroup = MajorMuscleGroup.ALL
    private var planeMode: String = "dual"
    private var selectedMuscleId: String = "chest"
    private var weightUnit: String = "kg"
    private var keepScreenOn: Boolean = true
    private var hapticEnabled: Boolean = true
    private var customRestDurationSec: Int = 90
    private var workoutsSubTab: String = "templates"
    private var libraryQuery: String = ""
    private var libraryGroupFilter: MajorMuscleGroup = MajorMuscleGroup.ALL
    private var libraryEquipFilter: String = "All"
    private var selectedDateIso: String = LocalDate.now().toString()
    private var standaloneSession: StandaloneSession? = null

    // Rest Countdown Timer
    private val mainHandler = Handler(Looper.getMainLooper())
    private var restSecondsRemaining: Int = 0
    private var restSecondsTotal: Int = 90
    private var restTimerRunning: Boolean = false
    private var restTimerFinishedAlert: Boolean = false
    private var restExerciseLabel: String = "Set Rest"

    private val timerTickRunnable = object : Runnable {
        override fun run() {
            if (!restTimerRunning) return
            if (restSecondsRemaining > 0) {
                restSecondsRemaining -= 1
                if (restSecondsRemaining == 0) {
                    restTimerRunning = false
                    restTimerFinishedAlert = true
                    if (hapticEnabled) {
                        NativeHardwareBridge.hapticRestComplete(this@MainActivity)
                    }
                    showBanner("Rest complete ($restExerciseLabel) — device vibration triggered!")
                    updateTimerUiLive()
                } else {
                    updateTimerUiLive()
                    mainHandler.postDelayed(this, 1000L)
                }
            }
        }
    }

    companion object {
        private const val REQ_EXPORT_JSON = 1001
        private const val REQ_IMPORT_JSON = 1002
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = HyperLogDatabase(this)

        val prefs = getSharedPreferences("hyperlog_prefs", Context.MODE_PRIVATE)
        UiKit.themeMode = AppThemeMode.fromId(prefs.getString("themeMode", "light"))
        activeWeek = prefs.getInt("activeWeek", 3)
        activeDay = prefs.getInt("activeDay", 5)
        weightUnit = prefs.getString("weightUnit", "kg") ?: "kg"
        keepScreenOn = prefs.getBoolean("keepScreenOn", true)
        hapticEnabled = prefs.getBoolean("hapticEnabled", true)
        customRestDurationSec = prefs.getInt("customRestDurationSec", 90).coerceIn(10, 600)
        restSecondsTotal = customRestDurationSec

        applySystemBarColors()
        NativeHardwareBridge.setKeepScreenOn(this, keepScreenOn)
        db.ensureDaySetRowsMaterialized(activeWeek, activeDay)

        buildShellLayout()
        renderActivePage()
    }

    override fun onDestroy() {
        mainHandler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun applySystemBarColors() {
        window.statusBarColor = UiKit.COL_CARD
        window.navigationBarColor = UiKit.COL_CARD
    }

    private fun savePrefs() {
        getSharedPreferences("hyperlog_prefs", Context.MODE_PRIVATE).edit()
            .putString("themeMode", UiKit.themeMode.id)
            .putInt("activeWeek", activeWeek)
            .putInt("activeDay", activeDay)
            .putString("weightUnit", weightUnit)
            .putBoolean("keepScreenOn", keepScreenOn)
            .putBoolean("hapticEnabled", hapticEnabled)
            .putInt("customRestDurationSec", customRestDurationSec)
            .apply()
    }

    private fun buildShellLayout() {
        rootColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(UiKit.COL_BG)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
            )
        }

        // Top Bar
        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(UiKit.COL_CARD)
            val px = UiKit.dp(this@MainActivity, 14)
            val py = UiKit.dp(this@MainActivity, 10)
            setPadding(px, py, px, py)
        }
        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        headerTitleView = UiKit.text(this, "HyperLog", 18f, UiKit.COL_TEXT_DARK, bold = true)
        headerSubtitle = UiKit.text(this, "OFFLINE HYPERTROPHY · WEEK $activeWeek", 10.5f, UiKit.COL_ACCENT, bold = true)
        titleCol.addView(headerTitleView)
        titleCol.addView(headerSubtitle)
        topBar.addView(titleCol)

        themeBtnView = UiKit.outlineButton(this, "Theme: ${UiKit.themeMode.shortTag}", UiKit.COL_ACCENT) {
            showThemePickerDialog()
        }
        topBar.addView(themeBtnView)
        topBar.addView(UiKit.spacerH(this, 6))

        backupBtnView = UiKit.outlineButton(this, "Backup") { showBackupDialog() }
        topBar.addView(backupBtnView)
        rootColumn.addView(topBar)

        // Hairline Divider
        topDivider = View(this).apply {
            setBackgroundColor(UiKit.COL_BORDER)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, UiKit.dp(this@MainActivity, 1))
        }
        rootColumn.addView(topDivider)

        // Status Toast Banner
        bannerView = UiKit.text(this, "", 12f, UiKit.COL_PURE_WHITE, bold = true).apply {
            setBackgroundColor(0xFF1E293B.toInt())
            val px = UiKit.dp(this@MainActivity, 14)
            val py = UiKit.dp(this@MainActivity, 9)
            setPadding(px, py, px, py)
            visibility = View.GONE
            setOnClickListener { visibility = View.GONE }
        }
        rootColumn.addView(bannerView)

        // Sticky Rest Countdown Bar (visible across all tabs when timer is active)
        timerBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0xFF0F172A.toInt())
            val px = UiKit.dp(this@MainActivity, 12)
            val py = UiKit.dp(this@MainActivity, 8)
            setPadding(px, py, px, py)
            visibility = View.GONE
        }
        timerText = UiKit.text(this, "Rest 0:00", 13f, UiKit.COL_PURE_WHITE, bold = true, tabular = true).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        timerBar.addView(timerText)
        timerBar.addView(UiKit.chip(this, "-15s", false) { adjustRestTimer(-15) })
        timerBar.addView(UiKit.spacerH(this, 5))
        timerBar.addView(UiKit.chip(this, "+15s", false) { adjustRestTimer(15) })
        timerBar.addView(UiKit.spacerH(this, 5))
        timerBar.addView(UiKit.chip(this, "Stop", true) { stopRestTimer() })
        rootColumn.addView(timerBar)

        // Main Scrollable Viewport
        pageContent = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = UiKit.dp(this@MainActivity, 12)
            setPadding(p, p, p, UiKit.dp(this@MainActivity, 24))
        }
        mainScroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
            addView(pageContent)
        }
        rootColumn.addView(mainScroll)

        // Bottom Divider
        bottomDivider = View(this).apply {
            setBackgroundColor(UiKit.COL_BORDER)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, UiKit.dp(this@MainActivity, 1))
        }
        rootColumn.addView(bottomDivider)

        // 5-Tab Bottom Navigation Bar
        bottomNavRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(UiKit.COL_CARD)
            val py = UiKit.dp(this@MainActivity, 6)
            setPadding(0, py, 0, py)
        }
        rootColumn.addView(bottomNavRow)

        setContentView(rootColumn)
        rebuildBottomNav()
    }

    private fun refreshShellTheme() {
        applySystemBarColors()
        rootColumn.setBackgroundColor(UiKit.COL_BG)
        topBar.setBackgroundColor(UiKit.COL_CARD)
        topDivider.setBackgroundColor(UiKit.COL_BORDER)
        bottomDivider.setBackgroundColor(UiKit.COL_BORDER)
        bottomNavRow.setBackgroundColor(UiKit.COL_CARD)
        headerTitleView.setTextColor(UiKit.COL_TEXT_DARK)
        headerSubtitle.setTextColor(UiKit.COL_ACCENT)
        themeBtnView.text = "Theme: ${UiKit.themeMode.shortTag}"
        themeBtnView.setTextColor(UiKit.COL_ACCENT)
        themeBtnView.background = UiKit.roundedBg(UiKit.COL_CARD, 10f, this, UiKit.COL_BORDER, 1f)
        backupBtnView.setTextColor(UiKit.COL_TEXT_DARK)
        backupBtnView.background = UiKit.roundedBg(UiKit.COL_CARD, 10f, this, UiKit.COL_BORDER, 1f)
        rebuildBottomNav()
        renderActivePage()
    }

    private fun showThemePickerDialog() {
        val modes = AppThemeMode.entries
        val labels = modes.map { mode ->
            val mark = if (mode == UiKit.themeMode) "✓ " else "   "
            "$mark${mode.label}"
        }.toTypedArray()

        AlertDialog.Builder(this, UiKit.dialogTheme())
            .setTitle("Appearance & Night Themes")
            .setItems(labels) { _, which ->
                UiKit.themeMode = modes[which]
                savePrefs()
                NativeHardwareBridge.hapticTick(this)
                refreshShellTheme()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun rebuildBottomNav() {
        bottomNavRow.removeAllViews()
        val tabs = listOf("Anatomy", "Track", "Workouts", "Library", "Calories")
        tabs.forEachIndexed { idx, label ->
            val selected = activeTab == idx
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                minimumHeight = UiKit.dp(this@MainActivity, 48)
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener {
                    activeTab = idx
                    rebuildBottomNav()
                    mainScroll.scrollTo(0, 0)
                    renderActivePage()
                }
            }
            val indicator = View(this).apply {
                background = UiKit.roundedBg(if (selected) UiKit.COL_ACCENT else 0x00000000, 3f, this@MainActivity)
                layoutParams = LinearLayout.LayoutParams(UiKit.dp(this@MainActivity, 24), UiKit.dp(this@MainActivity, 3)).apply {
                    bottomMargin = UiKit.dp(this@MainActivity, 4)
                }
            }
            item.addView(indicator)
            item.addView(UiKit.text(
                this, label, 11.5f,
                if (selected) UiKit.COL_ACCENT else UiKit.COL_TEXT_MUTED,
                bold = selected
            ))
            bottomNavRow.addView(item)
        }
    }

    private fun showBanner(msg: String) {
        bannerView.text = "$msg  (Tap to dismiss)"
        bannerView.visibility = View.VISIBLE
    }

    // =========================================================================
    // VIBRATION REST TIMER ENGINE
    // =========================================================================
    private fun formatClock(sec: Int): String {
        val clamped = sec.coerceAtLeast(0)
        return String.format("%d:%02d", clamped / 60, clamped % 60)
    }

    private fun startRestTimer(seconds: Int, exerciseName: String) {
        mainHandler.removeCallbacks(timerTickRunnable)
        val target = seconds.coerceIn(5, 900)
        customRestDurationSec = target
        restSecondsTotal = target
        restSecondsRemaining = target
        restExerciseLabel = exerciseName
        restTimerFinishedAlert = false
        restTimerRunning = true
        savePrefs()
        updateTimerUiLive()
        mainHandler.postDelayed(timerTickRunnable, 1000L)
    }

    private fun togglePauseResumeRestTimer() {
        if (restTimerRunning) {
            restTimerRunning = false
            mainHandler.removeCallbacks(timerTickRunnable)
            updateTimerUiLive()
        } else {
            val startFrom = if (restSecondsRemaining > 0) restSecondsRemaining else customRestDurationSec
            restSecondsRemaining = startFrom
            restSecondsTotal = restSecondsTotal.coerceAtLeast(startFrom)
            restTimerFinishedAlert = false
            restTimerRunning = true
            updateTimerUiLive()
            mainHandler.removeCallbacks(timerTickRunnable)
            mainHandler.postDelayed(timerTickRunnable, 1000L)
        }
    }

    private fun adjustRestTimer(delta: Int) {
        if (restTimerRunning || restSecondsRemaining > 0) {
            val next = (restSecondsRemaining + delta).coerceIn(5, 900)
            restSecondsRemaining = next
            customRestDurationSec = next
            restSecondsTotal = maxOf(restSecondsTotal, next)
        } else {
            customRestDurationSec = (customRestDurationSec + delta).coerceIn(10, 900)
            restSecondsTotal = customRestDurationSec
        }
        restTimerFinishedAlert = false
        savePrefs()
        updateTimerUiLive()
    }

    private fun setPresetRestSeconds(sec: Int) {
        val clean = sec.coerceIn(10, 900)
        customRestDurationSec = clean
        restSecondsTotal = clean
        restTimerFinishedAlert = false
        savePrefs()
        if (restTimerRunning) {
            startRestTimer(clean, restExerciseLabel)
        } else {
            restSecondsRemaining = 0
            updateTimerUiLive()
            if (activeTab == 1) renderActivePage()
        }
    }

    private fun stopRestTimer() {
        mainHandler.removeCallbacks(timerTickRunnable)
        restTimerRunning = false
        restSecondsRemaining = 0
        restTimerFinishedAlert = false
        updateTimerUiLive()
    }

    private fun updateTimerUiLive() {
        // Sticky global bar (shown when timer is actively counting or paused mid-rest on other tabs)
        if (restSecondsRemaining > 0 && (restTimerRunning || activeTab != 1)) {
            timerText.text = "Rest ${formatClock(restSecondsRemaining)} · $restExerciseLabel"
            timerBar.visibility = View.VISIBLE
        } else {
            timerBar.visibility = View.GONE
        }

        // Inline Track page console views (if visible)
        val shownClock = if (restSecondsRemaining > 0 || restTimerRunning) restSecondsRemaining else customRestDurationSec
        inlineTimerClockView?.text = if (restTimerFinishedAlert && restSecondsRemaining == 0) "0:00" else formatClock(shownClock)
        inlineTimerClockView?.setTextColor(
            when {
                restTimerFinishedAlert -> 0xFF10B981.toInt()
                restTimerRunning -> UiKit.COL_ACCENT
                else -> UiKit.COL_TEXT_DARK
            }
        )
        inlineTimerStatusView?.text = when {
            restTimerFinishedAlert -> "REST COMPLETE · VIBRATED — START NEXT SET!"
            restTimerRunning -> "COUNTING DOWN · $restExerciseLabel"
            restSecondsRemaining > 0 -> "PAUSED · $restExerciseLabel"
            else -> "READY · TARGET ${customRestDurationSec}s (${formatClock(customRestDurationSec)})"
        }
        inlineTimerPlayPauseBtn?.text = when {
            restTimerRunning -> "Pause"
            restSecondsRemaining > 0 -> "Resume"
            else -> "Start ${customRestDurationSec}s"
        }
    }

    private fun renderActivePage() {
        inlineTimerClockView = null
        inlineTimerStatusView = null
        inlineTimerPlayPauseBtn = null

        headerSubtitle.text = "OFFLINE HYPERTROPHY · WEEK $activeWeek"
        pageContent.removeAllViews()
        when (activeTab) {
            0 -> renderAnatomyPage()
            1 -> renderTrackSetsPage()
            2 -> renderWorkoutsPage()
            3 -> renderLibraryPage()
            4 -> renderCaloriesPage()
        }
        updateTimerUiLive()
    }

    // =========================================================================
    // PAGE 1: ANATOMY & HYPERTROPHY LANDMARKS (CLEAN MOBILE ALIGNMENT & FREQ)
    // =========================================================================
    private fun renderAnatomyPage() {
        val landmarks = db.getLandmarks()
        val allSets = db.getSetLogs()
        val dayExercises = db.getDayExercises()
        val weekMeta = MESOCYCLE_WEEKS.find { it.week == activeWeek } ?: MESOCYCLE_WEEKS[2]

        val completedWeekSets = allSets.filter { it.week == activeWeek && it.completed }
        val setsByMuscle = completedWeekSets
            .groupBy { it.muscleId }
            .mapValues { it.value.size }

        val freqByMuscle = dayExercises
            .groupBy { it.muscleId }
            .mapValues { (_, exs) -> exs.map { it.dayNumber }.distinct().sorted() }

        // Clean Header + 5-Column Mesocycle Week Bar (Zero subtitle clutter)
        val weekCard = UiKit.card(this, padDp = 13)
        weekCard.addView(UiKit.text(this, "Anatomy & Volume Landmarks", 17f, UiKit.COL_TEXT_DARK, bold = true))
        weekCard.addView(UiKit.spacerV(this, 2))
        weekCard.addView(UiKit.text(this, "${weekMeta.fullLabel} · Target ${weekMeta.targetRir}", 12f, UiKit.COL_TEXT_MUTED))
        weekCard.addView(UiKit.spacerV(this, 10))

        // Equal 5-column grid for Wk 1..Wk 5 so mobile alignment is crisp without horizontal cutoff
        val wkGrid = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        MESOCYCLE_WEEKS.forEachIndexed { idx, wm ->
            val shortTag = if (wm.week == 5) "Deload" else "Wk ${wm.week}"
            val btn = UiKit.chip(this, shortTag, activeWeek == wm.week) {
                activeWeek = wm.week
                savePrefs()
                db.ensureDaySetRowsMaterialized(activeWeek, activeDay)
                renderActivePage()
            }.apply {
                val px = UiKit.dp(this@MainActivity, 4)
                val py = UiKit.dp(this@MainActivity, 8)
                setPadding(px, py, px, py)
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    if (idx < MESOCYCLE_WEEKS.lastIndex) rightMargin = UiKit.dp(this@MainActivity, 5)
                }
            }
            wkGrid.addView(btn)
        }
        weekCard.addView(wkGrid)
        pageContent.addView(weekCard)

        // Major Muscle Group Filter + Human Body Canvas Card
        val diagramCard = UiKit.card(this, padDp = 13)
        val topHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        topHeader.addView(UiKit.text(this, "Muscle Map", 14f, UiKit.COL_TEXT_DARK, bold = true).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        listOf("dual" to "Split", "anterior" to "Front", "posterior" to "Back").forEachIndexed { idx, (id, lbl) ->
            topHeader.addView(UiKit.chip(this, lbl, planeMode == id) {
                planeMode = id
                renderActivePage()
            })
            if (idx < 2) topHeader.addView(UiKit.spacerH(this, 4))
        }
        diagramCard.addView(topHeader)
        diagramCard.addView(UiKit.spacerV(this, 8))

        val (grpScroll, grpRow) = UiKit.hScrollRow(this)
        MajorMuscleGroup.entries.forEach { grp ->
            grpRow.addView(UiKit.chip(this, grp.label, activeMajorGroup == grp) {
                activeMajorGroup = grp
                if (!grp.matchesMuscle(selectedMuscleId)) {
                    selectedMuscleId = landmarks.values.firstOrNull { grp.matchesMuscle(it.id) }?.id ?: "chest"
                }
                renderActivePage()
            })
            grpRow.addView(UiKit.spacerH(this, 6))
        }
        diagramCard.addView(grpScroll)
        diagramCard.addView(UiKit.spacerV(this, 8))

        val bodyView = HumanBodyDiagramView(this) { tappedMuscle ->
            selectedMuscleId = tappedMuscle
            NativeHardwareBridge.hapticTick(this)
            renderActivePage()
        }.apply {
            this.planeMode = this@MainActivity.planeMode
            this.activeMajorGroup = this@MainActivity.activeMajorGroup
            this.selectedMuscleId = this@MainActivity.selectedMuscleId
            this.setsByMuscle = setsByMuscle
            this.landmarks = landmarks
        }
        diagramCard.addView(bodyView)
        diagramCard.addView(UiKit.spacerV(this, 8))

        // Quick-Select Region Strip for effortless mobile thumb tapping
        diagramCard.addView(UiKit.text(this, "QUICK-SELECT REGION", 10f, UiKit.COL_TEXT_MUTED, bold = true))
        diagramCard.addView(UiKit.spacerV(this, 5))
        val (quickScroll, quickRow) = UiKit.hScrollRow(this)
        val filteredList = landmarks.values.filter { activeMajorGroup.matchesMuscle(it.id) }
        filteredList.forEach { lm ->
            val mSets = setsByMuscle[lm.id] ?: 0
            quickRow.addView(UiKit.chip(this, "${lm.shortName} ($mSets)", selectedMuscleId == lm.id) {
                selectedMuscleId = lm.id
                NativeHardwareBridge.hapticTick(this)
                renderActivePage()
            })
            quickRow.addView(UiKit.spacerH(this, 6))
        }
        diagramCard.addView(quickScroll)
        pageContent.addView(diagramCard)

        // Selected Muscle Inspector Card — Clean 4-col Landmarks + Dedicated 3-col Frequency/Effort/Load Row
        val selectedLm = landmarks[selectedMuscleId] ?: landmarks.values.firstOrNull()
        if (selectedLm != null) {
            val logged = setsByMuscle[selectedLm.id] ?: 0
            val zone = evaluateVolumeZone(logged, selectedLm)
            val daysHitting = freqByMuscle[selectedLm.id] ?: emptyList()
            val muscleSetRows = completedWeekSets.filter { it.muscleId == selectedLm.id }
            val avgRirStr = if (muscleSetRows.isNotEmpty()) {
                String.format("%.1f RIR", muscleSetRows.map { it.rir }.average())
            } else "—"
            val loadKg = muscleSetRows.sumOf { it.weightKg * it.reps }.roundToInt()

            val inspCard = UiKit.card(this, borderColor = UiKit.COL_ACCENT, borderDp = 1.5f, padDp = 14)
            val titleRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val titleLeft = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            titleLeft.addView(UiKit.text(this, selectedLm.name, 16f, UiKit.COL_TEXT_DARK, bold = true))
            titleLeft.addView(UiKit.text(this, "${zone.fullLabel} · $logged sets logged", 12f, zone.strokeColor, bold = true, tabular = true))
            titleRow.addView(titleLeft)
            titleRow.addView(UiKit.outlineButton(this, "Edit") { showEditLandmarkDialog(selectedLm) })
            inspCard.addView(titleRow)

            inspCard.addView(UiKit.progressBar(this, logged.toFloat() / selectedLm.mrv.coerceAtLeast(1).toFloat(), zone.fillColor))
            inspCard.addView(UiKit.spacerV(this, 4))

            // 4-Column Landmark Grid (MV | MEV | MAV | MRV)
            val lmGrid = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            listOf(
                "MV" to "${selectedLm.mv}",
                "MEV" to "${selectedLm.mev}",
                "MAV" to "${selectedLm.mavMin}–${selectedLm.mavMax}",
                "MRV" to "${selectedLm.mrv}"
            ).forEachIndexed { idx, (lbl, v) ->
                val colColor = if (lbl == "MAV") UiKit.COL_ACCENT else UiKit.COL_TEXT_DARK
                lmGrid.addView(UiKit.metricBox(this, lbl, v, colColor).apply {
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                        if (idx < 3) rightMargin = UiKit.dp(this@MainActivity, 6)
                    }
                })
            }
            inspCard.addView(lmGrid)
            inspCard.addView(UiKit.spacerV(this, 6))

            // Dedicated 3-Column Strip: Frequency | Avg Effort | Weekly Load
            val freqTargetClean = formatFreqRange(selectedLm.freqMin, selectedLm.freqMax)
            val freqDisplay = "${daysHitting.size}x (${freqTargetClean.removeSuffix("/wk")})"
            val statRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            listOf(
                "FREQUENCY" to freqDisplay,
                "AVG EFFORT" to avgRirStr,
                "WEEKLY LOAD" to "${loadKg} kg"
            ).forEachIndexed { idx, (lbl, v) ->
                statRow.addView(UiKit.metricBox(this, lbl, v).apply {
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                        if (idx < 2) rightMargin = UiKit.dp(this@MainActivity, 6)
                    }
                })
            }
            inspCard.addView(statRow)
            inspCard.addView(UiKit.spacerV(this, 8))
            inspCard.addView(UiKit.text(this, selectedLm.guidance, 12f, UiKit.COL_TEXT_MUTED))

            if (daysHitting.isNotEmpty()) {
                inspCard.addView(UiKit.spacerV(this, 10))
                val (dScroll, dRow) = UiKit.hScrollRow(this)
                daysHitting.forEach { dNum ->
                    dRow.addView(UiKit.outlineButton(this, "Track Day $dNum →", UiKit.COL_ACCENT) {
                        standaloneSession = null
                        activeDay = dNum
                        savePrefs()
                        db.ensureDaySetRowsMaterialized(activeWeek, activeDay)
                        activeTab = 1
                        rebuildBottomNav()
                        renderActivePage()
                    })
                    dRow.addView(UiKit.spacerH(this, 8))
                }
                inspCard.addView(dScroll)
            }
            pageContent.addView(inspCard)
        }

        // Filtered Muscle List Cards (Clean Frequency & Mobile Alignment)
        pageContent.addView(UiKit.text(this, "${activeMajorGroup.label} Landmarks (${filteredList.size})", 14f, UiKit.COL_TEXT_DARK, bold = true))
        pageContent.addView(UiKit.spacerV(this, 8))

        filteredList.forEach { lm ->
            val logged = setsByMuscle[lm.id] ?: 0
            val zone = evaluateVolumeZone(logged, lm)
            val freq = freqByMuscle[lm.id]?.size ?: 0
            val freqTarget = formatFreqRange(lm.freqMin, lm.freqMax)
            val isSel = lm.id == selectedMuscleId

            val mCard = UiKit.card(this, borderColor = if (isSel) UiKit.COL_ACCENT else UiKit.COL_BORDER, borderDp = if (isSel) 1.5f else 1f, padDp = 12)
            mCard.setOnClickListener {
                selectedMuscleId = lm.id
                renderActivePage()
            }
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            row.addView(UiKit.text(this, lm.name, 14f, UiKit.COL_TEXT_DARK, bold = true).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            row.addView(UiKit.text(this, "$logged / ${lm.mavMin}–${lm.mavMax} · ${zone.shortLabel}", 12f, zone.strokeColor, bold = true, tabular = true))
            mCard.addView(row)
            mCard.addView(UiKit.progressBar(this, logged.toFloat() / lm.mrv.coerceAtLeast(1).toFloat(), zone.fillColor))

            val metaBottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            metaBottom.addView(UiKit.text(this, "MV ${lm.mv} · MEV ${lm.mev} · MAV ${lm.mavMin}–${lm.mavMax} · MRV ${lm.mrv}", 11f, UiKit.COL_TEXT_MUTED, tabular = true).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            metaBottom.addView(UiKit.text(this, "Freq ${freq}x ($freqTarget)", 11f, UiKit.COL_TEXT_MID, bold = true, tabular = true))
            mCard.addView(metaBottom)
            pageContent.addView(mCard)
        }
    }

    private fun showEditLandmarkDialog(lm: MuscleLandmark) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = UiKit.dp(this@MainActivity, 16)
            setPadding(p, p, p, p)
        }
        val mvIn = UiKit.inputBox(this, lm.mv.toString(), "MV", InputType.TYPE_CLASS_NUMBER)
        val mevIn = UiKit.inputBox(this, lm.mev.toString(), "MEV", InputType.TYPE_CLASS_NUMBER)
        val mavMinIn = UiKit.inputBox(this, lm.mavMin.toString(), "MAV Min", InputType.TYPE_CLASS_NUMBER)
        val mavMaxIn = UiKit.inputBox(this, lm.mavMax.toString(), "MAV Max", InputType.TYPE_CLASS_NUMBER)
        val mrvIn = UiKit.inputBox(this, lm.mrv.toString(), "MRV", InputType.TYPE_CLASS_NUMBER)

        listOf("MV (Maintenance)" to mvIn, "MEV (Minimum Effective)" to mevIn, "MAV Min" to mavMinIn, "MAV Max" to mavMaxIn, "MRV (Max Recoverable)" to mrvIn).forEach { (lbl, ed) ->
            box.addView(UiKit.text(this, lbl, 11f, UiKit.COL_TEXT_MUTED, bold = true))
            box.addView(ed)
            box.addView(UiKit.spacerV(this, 6))
        }

        AlertDialog.Builder(this, UiKit.dialogTheme())
            .setTitle("Tune ${lm.shortName} Landmarks")
            .setView(box)
            .setPositiveButton("Save") { _, _ ->
                db.saveLandmark(lm.copy(
                    mv = mvIn.text.toString().toIntOrNull() ?: lm.mv,
                    mev = mevIn.text.toString().toIntOrNull() ?: lm.mev,
                    mavMin = mavMinIn.text.toString().toIntOrNull() ?: lm.mavMin,
                    mavMax = mavMaxIn.text.toString().toIntOrNull() ?: lm.mavMax,
                    mrv = mrvIn.text.toString().toIntOrNull() ?: lm.mrv
                ))
                showBanner("Updated volume landmarks for ${lm.shortName}")
                renderActivePage()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // =========================================================================
    // PAGE 2: TRACK SETS + COLOR-CODED RIR DROPDOWN + VIBRATION REST TIMER
    // =========================================================================
    private fun renderTrackSetsPage() {
        val landmarks = db.getLandmarks()
        val days = db.getWorkoutDays()
        val allSets = db.getSetLogs()
        val feedbackMap = db.getFeedbackMap()
        val currentStandalone = standaloneSession

        // 1. Session & Unit Card
        val sessionCard = UiKit.card(this, padDp = 13)
        if (currentStandalone != null) {
            val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val left = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            left.addView(UiKit.text(this, "STANDALONE TEMPLATE SESSION", 10f, UiKit.COL_ACCENT, bold = true))
            left.addView(UiKit.text(this, currentStandalone.templateName, 16f, UiKit.COL_TEXT_DARK, bold = true))
            top.addView(left)
            top.addView(UiKit.outlineButton(this, "Exit") {
                standaloneSession = null
                renderActivePage()
            })
            sessionCard.addView(top)
        } else {
            val wkGrid = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            MESOCYCLE_WEEKS.forEachIndexed { idx, wm ->
                val shortTag = if (wm.week == 5) "Deload" else "Wk ${wm.week}"
                wkGrid.addView(UiKit.chip(this, shortTag, activeWeek == wm.week) {
                    activeWeek = wm.week; savePrefs()
                    db.ensureDaySetRowsMaterialized(activeWeek, activeDay)
                    renderActivePage()
                }.apply {
                    val px = UiKit.dp(this@MainActivity, 4)
                    val py = UiKit.dp(this@MainActivity, 7)
                    setPadding(px, py, px, py)
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                        if (idx < MESOCYCLE_WEEKS.lastIndex) rightMargin = UiKit.dp(this@MainActivity, 5)
                    }
                })
            }
            sessionCard.addView(wkGrid)
            sessionCard.addView(UiKit.spacerV(this, 8))

            val (dayScroll, dayRow) = UiKit.hScrollRow(this)
            (1..7).forEach { d ->
                val isRest = days.find { it.dayNumber == d }?.isRestDay == true
                dayRow.addView(UiKit.chip(this, if (isRest) "Day $d (Rest)" else "Day $d", activeDay == d) {
                    activeDay = d; savePrefs()
                    db.ensureDaySetRowsMaterialized(activeWeek, activeDay)
                    renderActivePage()
                })
                dayRow.addView(UiKit.spacerH(this, 6))
            }
            sessionCard.addView(dayScroll)
            sessionCard.addView(UiKit.spacerV(this, 8))

            days.find { it.dayNumber == activeDay }?.let { dEnt ->
                sessionCard.addView(UiKit.text(this, dEnt.title, 15f, UiKit.COL_TEXT_DARK, bold = true))
                sessionCard.addView(UiKit.text(this, dEnt.focusSummary, 12f, UiKit.COL_TEXT_MUTED))
            }
        }

        // Unit Toggle & Wake-Lock Switch
        sessionCard.addView(UiKit.spacerV(this, 10))
        val hwRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        listOf("kg", "lb").forEach { u ->
            hwRow.addView(UiKit.chip(this, u.uppercase(), weightUnit == u) {
                weightUnit = u; savePrefs(); renderActivePage()
            })
            hwRow.addView(UiKit.spacerH(this, 6))
        }
        hwRow.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(0, 1, 1f) })
        hwRow.addView(UiKit.text(this, "Keep Awake", 12f, UiKit.COL_TEXT_MID))
        val wakeSwitch = Switch(this).apply {
            isChecked = keepScreenOn
            setOnCheckedChangeListener { _, checked ->
                keepScreenOn = checked
                savePrefs()
                NativeHardwareBridge.setKeepScreenOn(this@MainActivity, checked)
            }
        }
        hwRow.addView(wakeSwitch)
        sessionCard.addView(hwRow)
        pageContent.addView(sessionCard)

        // 2. Dedicated Native Vibration Rest Timer Card (User-Specified Rest Duration + Native Motor)
        val timerCard = UiKit.card(
            this,
            borderColor = if (restTimerFinishedAlert) 0xFF10B981.toInt() else if (restTimerRunning) UiKit.COL_ACCENT else UiKit.COL_BORDER,
            borderDp = if (restTimerRunning || restTimerFinishedAlert) 1.5f else 1f,
            padDp = 13
        )
        val tTop = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val tLeft = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val statusTv = UiKit.text(this, "VIBRATION REST TIMER", 10.5f, UiKit.COL_ACCENT, bold = true)
        val clockTv = UiKit.text(this, formatClock(customRestDurationSec), 28f, UiKit.COL_TEXT_DARK, bold = true, tabular = true)
        inlineTimerStatusView = statusTv
        inlineTimerClockView = clockTv
        tLeft.addView(statusTv)
        tLeft.addView(clockTv)
        tTop.addView(tLeft)

        val playPauseBtn = UiKit.primaryButton(this, "Start ${customRestDurationSec}s", UiKit.COL_ACCENT) {
            togglePauseResumeRestTimer()
        }
        inlineTimerPlayPauseBtn = playPauseBtn
        tTop.addView(playPauseBtn)
        tTop.addView(UiKit.spacerH(this, 6))
        tTop.addView(UiKit.outlineButton(this, "Reset") { stopRestTimer() })
        timerCard.addView(tTop)

        timerCard.addView(UiKit.spacerV(this, 8))

        // Presets + -15s/+15s + Custom Seconds Input Dialog
        val (presetScroll, presetRow) = UiKit.hScrollRow(this)
        presetRow.addView(UiKit.chip(this, "-15s", false) { adjustRestTimer(-15) })
        presetRow.addView(UiKit.spacerH(this, 5))
        listOf(60, 90, 120, 180).forEach { sec ->
            presetRow.addView(UiKit.chip(this, "${sec}s", customRestDurationSec == sec && !restTimerRunning) {
                setPresetRestSeconds(sec)
            })
            presetRow.addView(UiKit.spacerH(this, 5))
        }
        presetRow.addView(UiKit.chip(this, "+15s", false) { adjustRestTimer(15) })
        presetRow.addView(UiKit.spacerH(this, 5))
        presetRow.addView(UiKit.outlineButton(this, "Custom Sec (${customRestDurationSec}s)", UiKit.COL_ACCENT) {
            showCustomRestSecondsDialog()
        })
        timerCard.addView(presetScroll)

        timerCard.addView(UiKit.spacerV(this, 8))
        val vibFoot = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val motorStatus = if (NativeHardwareBridge.hasVibrator(this)) "Native Motor Ready" else "Motor Simulated"
        vibFoot.addView(UiKit.text(this, "Haptic Alarm ($motorStatus)", 11.5f, UiKit.COL_TEXT_MUTED).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        vibFoot.addView(UiKit.outlineButton(this, "Test Vibrate") {
            NativeHardwareBridge.hapticRestComplete(this)
            showBanner("Triggered native vibration motor test pulse!")
        })
        vibFoot.addView(UiKit.spacerH(this, 6))
        val hapSwitch = Switch(this).apply {
            isChecked = hapticEnabled
            setOnCheckedChangeListener { _, checked ->
                hapticEnabled = checked
                savePrefs()
                if (checked) NativeHardwareBridge.hapticTick(this@MainActivity)
            }
        }
        vibFoot.addView(hapSwitch)
        timerCard.addView(vibFoot)
        pageContent.addView(timerCard)

        // 3. RIR Proximity Color Feedback Legend
        val legendCard = UiKit.card(this, padDp = 10)
        val legRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val greenPal = UiKit.rirPalette(2.0)
        val yellowPal = UiKit.rirPalette(0.0)
        legRow.addView(UiKit.text(this, "RIR Guide: ", 11.5f, UiKit.COL_TEXT_DARK, bold = true))
        legRow.addView(UiKit.text(this, " 1–3 RIR Optimal ", 11f, greenPal.textColor, bold = true).apply {
            background = UiKit.roundedBg(greenPal.bgColor, 6f, this@MainActivity, greenPal.borderColor, 1f)
            val px = UiKit.dp(this@MainActivity, 6); val py = UiKit.dp(this@MainActivity, 3)
            setPadding(px, py, px, py)
        })
        legRow.addView(UiKit.spacerH(this, 6))
        legRow.addView(UiKit.text(this, " <1 RIR Failure ", 11f, yellowPal.textColor, bold = true).apply {
            background = UiKit.roundedBg(yellowPal.bgColor, 6f, this@MainActivity, yellowPal.borderColor, 1f)
            val px = UiKit.dp(this@MainActivity, 6); val py = UiKit.dp(this@MainActivity, 3)
            setPadding(px, py, px, py)
        })
        legRow.addView(UiKit.spacerH(this, 6))
        legRow.addView(UiKit.text(this, "4+ Deload", 11f, UiKit.COL_TEXT_MUTED))
        legendCard.addView(legRow)
        pageContent.addView(legendCard)

        // Gather Exercises to Render
        data class TrackBlock(val exId: String, val name: String, val muscleId: String, val repRange: String, val restSec: Int, val defaultW: Double, val sets: List<SetLog>)

        val blocks: List<TrackBlock> = if (currentStandalone != null) {
            currentStandalone.exercises.map { item ->
                val rows = allSets.filter { it.templateSessionId == currentStandalone.sessionId && it.exerciseId == item.id }.sortedBy { it.setIndex }
                TrackBlock(item.id, item.name, item.primaryMuscle, item.reps, item.restSeconds, item.defaultWeightKg, rows)
            }
        } else {
            db.getDayExercises().filter { it.dayNumber == activeDay }.map { ex ->
                val rows = allSets.filter { it.templateSessionId == null && it.week == activeWeek && it.dayNumber == activeDay && it.exerciseId == ex.id }.sortedBy { it.setIndex }
                TrackBlock(ex.id, if (ex.isSuperset) "${ex.name} (SS)" else ex.name, ex.muscleId, ex.repRange, ex.restSeconds, ex.defaultWeightKg, rows)
            }
        }

        if (blocks.isEmpty()) {
            val restCard = UiKit.card(this)
            restCard.addView(UiKit.text(this, "Scheduled Active Recovery Day", 15f, UiKit.COL_TEXT_DARK, bold = true))
            restCard.addView(UiKit.text(this, "No lifting prescribed today. Hit 8,000–10,000 walking steps and log protein & carbs on the Calories tab.", 12f, UiKit.COL_TEXT_MUTED))
            pageContent.addView(restCard)
            return
        }

        var completedTotal = 0
        var tonnageKg = 0.0

        blocks.forEach { block ->
            val mName = landmarks[block.muscleId]?.shortName ?: block.muscleId
            val exCard = UiKit.card(this, padDp = 12)

            val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val hLeft = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            hLeft.addView(UiKit.text(this, block.name, 15f, UiKit.COL_TEXT_DARK, bold = true))
            hLeft.addView(UiKit.text(this, "$mName · Target ${block.repRange} reps · Default rest ${block.restSec}s", 11f, UiKit.COL_TEXT_MUTED))
            head.addView(hLeft)
            head.addView(UiKit.outlineButton(this, "Rest ${block.restSec}s", UiKit.COL_ACCENT) {
                startRestTimer(block.restSec, block.name)
            })
            exCard.addView(head)
            exCard.addView(UiKit.spacerV(this, 8))

            // Crisp Mobile Column Headers
            val colHead = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                val px = UiKit.dp(this@MainActivity, 6)
                setPadding(px, 0, px, UiKit.dp(this@MainActivity, 4))
            }
            colHead.addView(UiKit.text(this, "SET", 10f, UiKit.COL_TEXT_MUTED, bold = true).apply {
                width = UiKit.dp(this@MainActivity, 30)
            })
            colHead.addView(UiKit.text(this, weightUnit.uppercase(), 10f, UiKit.COL_TEXT_MUTED, bold = true).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.95f)
            })
            colHead.addView(UiKit.spacerH(this, 5))
            colHead.addView(UiKit.text(this, "REPS", 10f, UiKit.COL_TEXT_MUTED, bold = true).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.75f)
            })
            colHead.addView(UiKit.spacerH(this, 5))
            colHead.addView(UiKit.text(this, "RIR (PROXIMITY)", 10f, UiKit.COL_TEXT_MUTED, bold = true).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.35f)
            })
            colHead.addView(UiKit.text(this, "DONE", 10f, UiKit.COL_TEXT_MUTED, bold = true).apply {
                gravity = Gravity.END
                width = UiKit.dp(this@MainActivity, 40)
            })
            exCard.addView(colHead)

            block.sets.forEach { setRow ->
                if (setRow.completed) {
                    completedTotal += 1
                    tonnageKg += setRow.weightKg * setRow.reps
                }

                val rowLayout = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    background = UiKit.roundedBg(
                        if (setRow.completed) UiKit.COL_ROW_COMPLETED else UiKit.COL_SUBTLE,
                        10f,
                        this@MainActivity,
                        if (setRow.completed) 0xFF10B981.toInt() else UiKit.COL_BORDER,
                        1f
                    )
                    val p = UiKit.dp(this@MainActivity, 6)
                    setPadding(p, p, p, p)
                    layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                        bottomMargin = UiKit.dp(this@MainActivity, 6)
                    }
                }

                rowLayout.addView(UiKit.text(this, "#${setRow.setIndex}", 12f, UiKit.COL_TEXT_DARK, bold = true, tabular = true).apply {
                    width = UiKit.dp(this@MainActivity, 30)
                })

                val dispW = if (weightUnit == "lb") ((setRow.weightKg * 2.20462 * 10.0).roundToInt() / 10.0).toString()
                else setRow.weightKg.toString().removeSuffix(".0")

                val wInput = UiKit.inputBox(this, dispW, weightUnit, InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL).apply {
                    background = UiKit.roundedBg(UiKit.COL_CARD, 8f, this@MainActivity, UiKit.COL_BORDER, 1f)
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.95f)
                }
                wInput.addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                    override fun afterTextChanged(s: Editable?) {
                        val v = s?.toString()?.toDoubleOrNull() ?: return
                        val kg = if (weightUnit == "lb") v / 2.20462 else v
                        db.saveSetLog(setRow.copy(weightKg = (kg * 100.0).roundToInt() / 100.0))
                    }
                })
                rowLayout.addView(wInput)
                rowLayout.addView(UiKit.spacerH(this, 5))

                val rInput = UiKit.inputBox(this, setRow.reps.toString(), "Reps", InputType.TYPE_CLASS_NUMBER).apply {
                    background = UiKit.roundedBg(UiKit.COL_CARD, 8f, this@MainActivity, UiKit.COL_BORDER, 1f)
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.75f)
                }
                rInput.addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                    override fun afterTextChanged(s: Editable?) {
                        val r = s?.toString()?.toIntOrNull() ?: return
                        db.saveSetLog(setRow.copy(reps = r.coerceAtLeast(0)))
                    }
                })
                rowLayout.addView(rInput)
                rowLayout.addView(UiKit.spacerH(this, 5))

                // Native Color-Coded RIR Dropdown Spinner (Green for 1–3 RIR, Yellow for <1 RIR)
                var latestRir = setRow.rir
                val rirSpinner = UiKit.rirDropdownSpinner(this, setRow.rir) { chosenRir ->
                    latestRir = chosenRir
                    val curW = wInput.text.toString().toDoubleOrNull()?.let { if (weightUnit == "lb") it / 2.20462 else it } ?: setRow.weightKg
                    val curR = rInput.text.toString().toIntOrNull() ?: setRow.reps
                    db.saveSetLog(setRow.copy(weightKg = curW, reps = curR, rir = chosenRir))
                    if (hapticEnabled) NativeHardwareBridge.hapticTick(this@MainActivity)
                }.apply {
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.35f)
                }
                rowLayout.addView(rirSpinner)
                rowLayout.addView(UiKit.spacerH(this, 4))

                val cb = CheckBox(this).apply {
                    isChecked = setRow.completed
                    setOnCheckedChangeListener { _, checked ->
                        val curW = wInput.text.toString().toDoubleOrNull()?.let { if (weightUnit == "lb") it / 2.20462 else it } ?: setRow.weightKg
                        val curR = rInput.text.toString().toIntOrNull() ?: setRow.reps
                        db.saveSetLog(setRow.copy(weightKg = curW, reps = curR, rir = latestRir, completed = checked))
                        if (checked) {
                            if (hapticEnabled) NativeHardwareBridge.hapticTick(this@MainActivity)
                            startRestTimer(customRestDurationSec, block.name)
                        }
                        renderActivePage()
                    }
                }
                rowLayout.addView(cb)
                exCard.addView(rowLayout)
            }

            // Footer: + Add Set | - Remove Set | Pump Biofeedback
            val foot = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            foot.addView(UiKit.outlineButton(this, "+ Set") {
                val last = block.sets.lastOrNull()
                val weekMeta = MESOCYCLE_WEEKS.find { it.week == activeWeek } ?: MESOCYCLE_WEEKS[2]
                db.saveSetLog(SetLog(
                    id = "set_${System.currentTimeMillis()}",
                    week = activeWeek,
                    dayNumber = if (currentStandalone != null) 0 else activeDay,
                    templateSessionId = currentStandalone?.sessionId,
                    exerciseId = block.exId,
                    exerciseName = block.name,
                    muscleId = block.muscleId,
                    setIndex = (last?.setIndex ?: 0) + 1,
                    weightKg = last?.weightKg ?: block.defaultW,
                    reps = last?.reps ?: 10,
                    rir = last?.rir ?: weekMeta.defaultRirNumber,
                    restSeconds = block.restSec,
                    completed = false
                ))
                renderActivePage()
            })
            if (block.sets.size > 1) {
                foot.addView(UiKit.spacerH(this, 6))
                foot.addView(UiKit.outlineButton(this, "- Set", UiKit.COL_TEXT_MUTED) {
                    block.sets.lastOrNull()?.let {
                        db.deleteSetLog(it.id)
                        renderActivePage()
                    }
                })
            }
            foot.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(0, 1, 1f) })

            val fbKey = "w${activeWeek}_${block.muscleId}"
            val curPump = feedbackMap[fbKey]?.pumpScore ?: 2
            foot.addView(UiKit.text(this, "Pump: ", 11f, UiKit.COL_TEXT_MUTED))
            listOf(1 to "Low", 2 to "Good", 3 to "Max").forEachIndexed { idx, (sc, lbl) ->
                foot.addView(UiKit.chip(this, lbl, curPump == sc) {
                    db.saveFeedback(MuscleFeedback(fbKey, activeWeek, block.muscleId, sc, 1))
                    renderActivePage()
                })
                if (idx < 2) foot.addView(UiKit.spacerH(this, 4))
            }
            exCard.addView(foot)
            pageContent.addView(exCard)
        }

        pageContent.addView(UiKit.primaryButton(
            this,
            "Sync Workout ($completedTotal sets · ${tonnageKg.roundToInt()} kg) to Health Connect"
        ) {
            val msg = NativeHardwareBridge.openHealthConnectOrReportOffline(this, "Week $activeWeek Session ($completedTotal sets)")
            showBanner(msg)
        })
    }

    private fun showCustomRestSecondsDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = UiKit.dp(this@MainActivity, 16)
            setPadding(p, p, p, p)
        }
        box.addView(UiKit.text(this, "Enter Rest Time in Seconds (10 – 600s)", 12f, UiKit.COL_TEXT_MUTED, bold = true))
        box.addView(UiKit.spacerV(this, 6))
        val secIn = UiKit.inputBox(this, customRestDurationSec.toString(), "Seconds (e.g. 75, 105, 150)", InputType.TYPE_CLASS_NUMBER)
        box.addView(secIn)

        AlertDialog.Builder(this, UiKit.dialogTheme())
            .setTitle("Custom Vibration Rest Timer")
            .setView(box)
            .setPositiveButton("Start Timer") { _, _ ->
                val v = secIn.text.toString().toIntOrNull()?.coerceIn(10, 600) ?: customRestDurationSec
                startRestTimer(v, restExerciseLabel)
                renderActivePage()
            }
            .setNeutralButton("Save Default") { _, _ ->
                val v = secIn.text.toString().toIntOrNull()?.coerceIn(10, 600) ?: customRestDurationSec
                setPresetRestSeconds(v)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // =========================================================================
    // PAGE 3: WORKOUT TEMPLATES STUDIO + 7-DAY SCHEDULE
    // =========================================================================
    private fun renderWorkoutsPage() {
        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = UiKit.dp(this@MainActivity, 12)
            }
        }
        val templates = db.getTemplates()
        topRow.addView(UiKit.chip(this, "Templates (${templates.size})", workoutsSubTab == "templates") {
            workoutsSubTab = "templates"; renderActivePage()
        })
        topRow.addView(UiKit.spacerH(this, 6))
        topRow.addView(UiKit.chip(this, "7-Day Schedule", workoutsSubTab == "schedule") {
            workoutsSubTab = "schedule"; renderActivePage()
        })
        topRow.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(0, 1, 1f) })
        if (workoutsSubTab == "templates") {
            topRow.addView(UiKit.primaryButton(this, "+ New", UiKit.COL_ACCENT) {
                showTemplateStudioDialog(WorkoutTemplate(
                    "tpl_custom_${System.currentTimeMillis()}",
                    "Custom Hypertrophy Workout",
                    "Custom",
                    "Custom Split",
                    "Personalized offline hypertrophy template",
                    "[]",
                    System.currentTimeMillis()
                ))
            })
        }
        pageContent.addView(topRow)

        if (workoutsSubTab == "templates") {
            templates.forEach { tpl ->
                val items = tpl.parsedExercises()
                val tCard = UiKit.card(this)
                val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                val hLeft = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                hLeft.addView(UiKit.text(this, "${tpl.category.uppercase()} · ${tpl.splitType}", 10f, UiKit.COL_ACCENT, bold = true))
                hLeft.addView(UiKit.text(this, tpl.name, 16f, UiKit.COL_TEXT_DARK, bold = true))
                head.addView(hLeft)
                if (tpl.category == "Custom") {
                    head.addView(UiKit.outlineButton(this, "Delete", 0xFFEF4444.toInt()) {
                        db.deleteTemplate(tpl.id)
                        showBanner("Deleted template '${tpl.name}'")
                        renderActivePage()
                    })
                }
                tCard.addView(head)
                tCard.addView(UiKit.text(this, tpl.description, 12f, UiKit.COL_TEXT_MUTED))
                tCard.addView(UiKit.spacerV(this, 6))

                items.forEachIndexed { idx, ex ->
                    tCard.addView(UiKit.text(this, "${idx + 1}. ${ex.name} — ${ex.sets} sets × ${ex.reps} (${ex.restSeconds}s rest)", 12f, UiKit.COL_TEXT_MID, tabular = true))
                }

                tCard.addView(UiKit.spacerV(this, 10))
                val actRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                actRow.addView(UiKit.primaryButton(this, "Start Now") {
                    if (items.isNotEmpty()) {
                        standaloneSession = db.startStandaloneTemplate(tpl, activeWeek)
                        activeTab = 1
                        rebuildBottomNav()
                        renderActivePage()
                    }
                })
                actRow.addView(UiKit.spacerH(this, 8))
                actRow.addView(UiKit.outlineButton(this, "Assign Day") {
                    showAssignTemplateDialog(tpl)
                })
                actRow.addView(UiKit.spacerH(this, 8))
                actRow.addView(UiKit.outlineButton(this, "Edit") {
                    showTemplateStudioDialog(tpl)
                })
                tCard.addView(actRow)
                pageContent.addView(tCard)
            }
        } else {
            val allDayEx = db.getDayExercises()
            db.getWorkoutDays().forEach { day ->
                val dCard = UiKit.card(this)
                val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                val left = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                left.addView(UiKit.text(this, day.title, 15f, UiKit.COL_TEXT_DARK, bold = true))
                left.addView(UiKit.text(this, day.focusSummary, 12f, UiKit.COL_TEXT_MUTED))
                head.addView(left)
                if (!day.isRestDay) {
                    head.addView(UiKit.primaryButton(this, "Track", UiKit.COL_ACCENT) {
                        standaloneSession = null
                        activeDay = day.dayNumber
                        savePrefs()
                        db.ensureDaySetRowsMaterialized(activeWeek, activeDay)
                        activeTab = 1
                        rebuildBottomNav()
                        renderActivePage()
                    })
                }
                dCard.addView(head)
                dCard.addView(UiKit.spacerV(this, 6))

                allDayEx.filter { it.dayNumber == day.dayNumber }.forEach { ex ->
                    val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                    r.addView(UiKit.text(this, "• ${ex.name} (${ex.setsForWeek(activeWeek)}×${ex.repRange}, ${ex.restSeconds}s)", 12f, UiKit.COL_TEXT_MID, tabular = true).apply {
                        layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    })
                    r.addView(UiKit.text(this, "✕", 13f, UiKit.COL_TEXT_MUTED, bold = true).apply {
                        val px = UiKit.dp(this@MainActivity, 6)
                        setPadding(px, px, px, px)
                        setOnClickListener {
                            db.removeDayExercise(ex.id)
                            renderActivePage()
                        }
                    })
                    dCard.addView(r)
                }

                dCard.addView(UiKit.spacerV(this, 6))
                dCard.addView(UiKit.outlineButton(this, "+ Add Exercise from Library") {
                    showExercisePickerDialog { picked ->
                        db.appendExerciseToScheduleDay(day.dayNumber, picked, activeWeek)
                        showBanner("Added '${picked.name}' to Day ${day.dayNumber}")
                        renderActivePage()
                    }
                })
                pageContent.addView(dCard)
            }
        }
    }

    private fun showAssignTemplateDialog(tpl: WorkoutTemplate) {
        val labels = (1..7).map { "Assign to Day $it" }.toTypedArray()
        AlertDialog.Builder(this, UiKit.dialogTheme())
            .setTitle("Assign '${tpl.name}' to Schedule")
            .setItems(labels) { _, which ->
                val dayNum = which + 1
                db.assignTemplateToDay(tpl, dayNum, activeWeek)
                showBanner("Assigned '${tpl.name}' to Day $dayNum")
                renderActivePage()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showTemplateStudioDialog(initial: WorkoutTemplate) {
        val items = initial.parsedExercises().toMutableList()
        val scroll = ScrollView(this)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = UiKit.dp(this@MainActivity, 16)
            setPadding(p, p, p, p)
        }
        scroll.addView(container)

        val nameIn = UiKit.inputBox(this, initial.name, "Template Name", InputType.TYPE_CLASS_TEXT)
        val splitIn = UiKit.inputBox(this, initial.splitType, "Split Tag (e.g. PPL, Upper/Lower)", InputType.TYPE_CLASS_TEXT)
        val itemsWrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        fun refreshItemsUi() {
            itemsWrap.removeAllViews()
            items.forEachIndexed { idx, it ->
                val box = UiKit.card(this, padDp = 10)
                val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                top.addView(UiKit.text(this, "${idx + 1}. ${it.name}", 13f, UiKit.COL_TEXT_DARK, bold = true).apply {
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                })
                top.addView(UiKit.text(this, "Remove", 11f, 0xFFEF4444.toInt(), bold = true).apply {
                    setOnClickListener { items.removeAt(idx); refreshItemsUi() }
                })
                box.addView(top)
                box.addView(UiKit.spacerV(this, 4))

                val editsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                val setsEd = UiKit.inputBox(this, it.sets.toString(), "Sets", InputType.TYPE_CLASS_NUMBER).apply {
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                val repsEd = UiKit.inputBox(this, it.reps, "Reps", InputType.TYPE_CLASS_TEXT).apply {
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                val restEd = UiKit.inputBox(this, it.restSeconds.toString(), "Rest(s)", InputType.TYPE_CLASS_NUMBER).apply {
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                setsEd.addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                    override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                    override fun afterTextChanged(s: Editable?) {
                        s?.toString()?.toIntOrNull()?.let { v -> items[idx] = items[idx].copy(sets = v.coerceIn(1, 15)) }
                    }
                })
                repsEd.addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                    override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                    override fun afterTextChanged(s: Editable?) {
                        val v = s?.toString() ?: return
                        if (v.isNotBlank()) items[idx] = items[idx].copy(reps = v)
                    }
                })
                restEd.addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                    override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                    override fun afterTextChanged(s: Editable?) {
                        s?.toString()?.toIntOrNull()?.let { v -> items[idx] = items[idx].copy(restSeconds = v.coerceIn(15, 600)) }
                    }
                })

                editsRow.addView(setsEd); editsRow.addView(UiKit.spacerH(this, 6))
                editsRow.addView(repsEd); editsRow.addView(UiKit.spacerH(this, 6))
                editsRow.addView(restEd)
                box.addView(editsRow)
                itemsWrap.addView(box)
            }
        }

        container.addView(UiKit.text(this, "Template Name", 11f, UiKit.COL_TEXT_MUTED, bold = true))
        container.addView(nameIn)
        container.addView(UiKit.spacerV(this, 6))
        container.addView(UiKit.text(this, "Split Type", 11f, UiKit.COL_TEXT_MUTED, bold = true))
        container.addView(splitIn)
        container.addView(UiKit.spacerV(this, 10))
        container.addView(itemsWrap)
        container.addView(UiKit.outlineButton(this, "+ Add Exercise from Library", UiKit.COL_ACCENT) {
            showExercisePickerDialog { picked ->
                items.add(TemplateExerciseItem(
                    "ti_${System.currentTimeMillis()}", picked.id, picked.name, picked.primaryMuscle,
                    3, picked.defaultRepRange, picked.defaultRestSeconds, picked.defaultWeightKg
                ))
                refreshItemsUi()
            }
        })
        refreshItemsUi()

        AlertDialog.Builder(this, UiKit.dialogTheme())
            .setTitle("Workout Template Studio")
            .setView(scroll)
            .setPositiveButton("Save Template") { _, _ ->
                val savedId = if (initial.category == "Starter") "tpl_custom_${System.currentTimeMillis()}" else initial.id
                db.saveTemplate(WorkoutTemplate(
                    id = savedId,
                    name = nameIn.text.toString().ifBlank { "Custom Template" },
                    category = "Custom",
                    splitType = splitIn.text.toString().ifBlank { "Custom Split" },
                    description = initial.description,
                    exercisesJson = serializeTemplateItems(items),
                    updatedAtEpochMs = System.currentTimeMillis()
                ))
                showBanner("Saved workout template to offline SQLite")
                renderActivePage()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showExercisePickerDialog(onPicked: (LibraryExercise) -> Unit) {
        val lib = db.getLibraryExercises()
        val labels = lib.map { "${it.name} (${it.equipment} · ${it.majorGroup})" }.toTypedArray()
        AlertDialog.Builder(this, UiKit.dialogTheme())
            .setTitle("Select Exercise from Library")
            .setItems(labels) { _, which -> onPicked(lib[which]) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // =========================================================================
    // PAGE 4: OFFLINE EXERCISE LIBRARY + SEARCH & FILTERS + VIDEO DEMO LINKS
    // =========================================================================
    private fun renderLibraryPage() {
        val landmarks = db.getLandmarks()
        val allLib = db.getLibraryExercises()
        val filtered = allLib.filter { ex ->
            val qOk = libraryQuery.isBlank() ||
                ex.name.contains(libraryQuery, ignoreCase = true) ||
                ex.description.contains(libraryQuery, ignoreCase = true) ||
                ex.primaryMuscle.contains(libraryQuery, ignoreCase = true)
            val gOk = libraryGroupFilter == MajorMuscleGroup.ALL || ex.majorGroup.equals(libraryGroupFilter.name, ignoreCase = true)
            val eOk = libraryEquipFilter == "All" || ex.equipment.equals(libraryEquipFilter, ignoreCase = true)
            qOk && gOk && eOk
        }

        val filterCard = UiKit.card(this)
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(UiKit.text(this, "Exercise Library (${filtered.size})", 16f, UiKit.COL_TEXT_DARK, bold = true).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        head.addView(UiKit.outlineButton(this, "+ Custom", UiKit.COL_ACCENT) { showCreateExerciseDialog() })
        filterCard.addView(head)
        filterCard.addView(UiKit.spacerV(this, 8))

        val searchBox = UiKit.inputBox(this, libraryQuery, "Search exercise, muscle, or cue...", InputType.TYPE_CLASS_TEXT)
        val searchRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        searchBox.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        searchRow.addView(searchBox)
        searchRow.addView(UiKit.spacerH(this, 6))
        searchRow.addView(UiKit.primaryButton(this, "Search") {
            libraryQuery = searchBox.text.toString().trim()
            renderActivePage()
        })
        if (libraryQuery.isNotBlank()) {
            searchRow.addView(UiKit.spacerH(this, 4))
            searchRow.addView(UiKit.outlineButton(this, "Clear") {
                libraryQuery = ""; renderActivePage()
            })
        }
        filterCard.addView(searchRow)
        filterCard.addView(UiKit.spacerV(this, 8))

        val (gScroll, gRow) = UiKit.hScrollRow(this)
        MajorMuscleGroup.entries.forEach { grp ->
            gRow.addView(UiKit.chip(this, grp.label, libraryGroupFilter == grp) {
                libraryGroupFilter = grp; renderActivePage()
            })
            gRow.addView(UiKit.spacerH(this, 6))
        }
        filterCard.addView(gScroll)
        filterCard.addView(UiKit.spacerV(this, 6))

        val (eScroll, eRow) = UiKit.hScrollRow(this)
        listOf("All", "Barbell", "Dumbbell", "Cable", "Machine", "Smith Machine", "Bodyweight", "EZ Bar").forEach { eq ->
            eRow.addView(UiKit.chip(this, eq, libraryEquipFilter == eq) {
                libraryEquipFilter = eq; renderActivePage()
            })
            eRow.addView(UiKit.spacerH(this, 6))
        }
        filterCard.addView(eScroll)
        pageContent.addView(filterCard)

        filtered.forEach { ex ->
            val pName = landmarks[ex.primaryMuscle]?.shortName ?: ex.primaryMuscle
            val sNames = ex.secondaryList().map { landmarks[it]?.shortName ?: it }
            val c = UiKit.card(this, padDp = 13)
            c.setOnClickListener { showExerciseDetailDialog(ex, landmarks) }

            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            r.addView(UiKit.text(this, ex.name, 15f, UiKit.COL_TEXT_DARK, bold = true).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            r.addView(UiKit.text(this, "${ex.equipment} · ${ex.defaultRepRange}", 11f, UiKit.COL_ACCENT, bold = true))
            c.addView(r)
            c.addView(UiKit.spacerV(this, 4))
            c.addView(UiKit.text(this, ex.description, 12f, UiKit.COL_TEXT_MID))
            c.addView(UiKit.spacerV(this, 4))
            val muscleLine = if (sNames.isNotEmpty()) "Primary: $pName · Secondary: ${sNames.joinToString(", ")}" else "Primary: $pName"
            c.addView(UiKit.text(this, "$muscleLine  (Tap for steps & video)", 11f, UiKit.COL_TEXT_MUTED))
            pageContent.addView(c)
        }
    }

    private fun showExerciseDetailDialog(ex: LibraryExercise, landmarks: Map<String, MuscleLandmark>) {
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = UiKit.dp(this@MainActivity, 16)
            setPadding(p, p, p, p)
        }
        scroll.addView(box)

        val pName = landmarks[ex.primaryMuscle]?.name ?: ex.primaryMuscle
        val sNames = ex.secondaryList().map { landmarks[it]?.shortName ?: it }

        box.addView(UiKit.text(this, "${ex.equipment} · Default ${ex.defaultRepRange} reps · ${ex.defaultRestSeconds}s rest", 12f, UiKit.COL_ACCENT, bold = true))
        box.addView(UiKit.spacerV(this, 6))
        box.addView(UiKit.text(this, ex.description, 13f, UiKit.COL_TEXT_DARK))
        box.addView(UiKit.spacerV(this, 10))
        box.addView(UiKit.text(this, "Muscles Targeted", 13f, UiKit.COL_TEXT_DARK, bold = true))
        box.addView(UiKit.text(this, "• Primary: $pName", 12f, UiKit.COL_TEXT_MID))
        if (sNames.isNotEmpty()) {
            box.addView(UiKit.text(this, "• Secondary: ${sNames.joinToString(", ")}", 12f, UiKit.COL_TEXT_MID))
        }
        box.addView(UiKit.spacerV(this, 10))
        box.addView(UiKit.text(this, "Step-by-Step Instructions", 13f, UiKit.COL_TEXT_DARK, bold = true))
        ex.instructionSteps().forEachIndexed { idx, step ->
            box.addView(UiKit.spacerV(this, 4))
            box.addView(UiKit.text(this, "${idx + 1}. $step", 12f, UiKit.COL_TEXT_MID))
        }

        if (ex.videoUrl.isNotBlank()) {
            box.addView(UiKit.spacerV(this, 12))
            box.addView(UiKit.outlineButton(this, "Watch Technique Video Demo ↗", UiKit.COL_ACCENT) {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(ex.videoUrl)))
                } catch (_: Exception) {
                    showBanner("No browser installed on this device to open external video link.")
                }
            })
        }

        AlertDialog.Builder(this, UiKit.dialogTheme())
            .setTitle(ex.name)
            .setView(scroll)
            .setPositiveButton("Done", null)
            .show()
    }

    private fun showCreateExerciseDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = UiKit.dp(this@MainActivity, 16)
            setPadding(p, p, p, p)
        }
        val nameIn = UiKit.inputBox(this, "", "Exercise Name", InputType.TYPE_CLASS_TEXT)
        val equipIn = UiKit.inputBox(this, "Dumbbell", "Equipment (Barbell, Cable, Machine...)", InputType.TYPE_CLASS_TEXT)
        val muscleIn = UiKit.inputBox(this, "chest", "Primary muscle ID (chest, back, quads, biceps...)", InputType.TYPE_CLASS_TEXT)
        val descIn = UiKit.inputBox(this, "", "Biomechanical description", InputType.TYPE_CLASS_TEXT)
        val stepsIn = UiKit.inputBox(this, "Brace core and set stable posture.\nControl 2–3s eccentric stretch.\nDrive smoothly to peak contraction.", "Instructions (1 step per line)", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE)

        listOf("Name" to nameIn, "Equipment" to equipIn, "Primary Muscle ID" to muscleIn, "Description" to descIn, "Instructions" to stepsIn).forEach { (l, v) ->
            box.addView(UiKit.text(this, l, 11f, UiKit.COL_TEXT_MUTED, bold = true))
            box.addView(v)
            box.addView(UiKit.spacerV(this, 6))
        }

        AlertDialog.Builder(this, UiKit.dialogTheme())
            .setTitle("Create Custom Library Exercise")
            .setView(box)
            .setPositiveButton("Save") { _, _ ->
                val nm = nameIn.text.toString().trim()
                if (nm.isNotEmpty()) {
                    val mId = muscleIn.text.toString().trim().ifBlank { "chest" }
                    val grp = MajorMuscleGroup.entries.firstOrNull { it != MajorMuscleGroup.ALL && it.matchesMuscle(mId) }?.name ?: "CHEST"
                    db.saveLibraryExercise(LibraryExercise(
                        "lib_custom_${System.currentTimeMillis()}", nm, grp, mId, "",
                        equipIn.text.toString().ifBlank { "Dumbbell" },
                        descIn.text.toString().ifBlank { "Custom offline hypertrophy exercise." },
                        stepsIn.text.toString(), "8–12", 90, 20.0, ""
                    ))
                    showBanner("Saved '$nm' to offline Exercise Library")
                    renderActivePage()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // =========================================================================
    // PAGE 5: CALORIES & MACROS + SAF BACKUP/RESTORE + HEALTH CONNECT
    // =========================================================================
    private fun renderCaloriesPage() {
        val metrics = db.getDailyMetrics(selectedDateIso)
        val meals = db.getMealsForDate(selectedDateIso)
        val weeklySets = db.getSetLogs().count { it.week == activeWeek && it.completed }

        val phaseDelta = when (metrics.phase) {
            "Massing" -> 300; "Mini-Cut" -> -500; else -> 0
        }
        val stepBonus = ((metrics.steps - 6000).coerceAtLeast(0) * 0.035).roundToInt()
        val liftBonus = ((weeklySets * 16.5) / 7.0).roundToInt()
        val targetKcal = metrics.baseTdee + phaseDelta + stepBonus + liftBonus
        val targetP = (metrics.bodyweightKg * metrics.proteinPerKg).roundToInt().coerceAtLeast(100)
        val targetF = (metrics.bodyweightKg * 0.85).roundToInt().coerceAtLeast(45)
        val targetC = ((targetKcal - targetP * 4 - targetF * 9) / 4).coerceAtLeast(80)

        val eatenKcal = meals.sumOf { it.calories }
        val eatenP = meals.sumOf { it.proteinG }
        val eatenC = meals.sumOf { it.carbsG }
        val eatenF = meals.sumOf { it.fatG }

        val calCard = UiKit.card(this)
        calCard.addView(UiKit.text(this, "Daily Energy & Macros ($selectedDateIso)", 15f, UiKit.COL_TEXT_DARK, bold = true))
        calCard.addView(UiKit.text(this, "$eatenKcal / $targetKcal kcal  (${targetKcal - eatenKcal} remaining)", 13f, UiKit.COL_ACCENT, bold = true, tabular = true))
        calCard.addView(UiKit.spacerV(this, 8))

        val (phScroll, phRow) = UiKit.hScrollRow(this)
        listOf("Massing", "Maintenance", "Mini-Cut").forEach { ph ->
            phRow.addView(UiKit.chip(this, ph, metrics.phase == ph) {
                db.saveDailyMetrics(metrics.copy(phase = ph))
                renderActivePage()
            })
            phRow.addView(UiKit.spacerH(this, 8))
        }
        calCard.addView(phScroll)
        calCard.addView(UiKit.spacerV(this, 8))

        listOf(
            Triple("Protein", "$eatenP / ${targetP}g", eatenP.toFloat() / targetP.toFloat() to 0xFF3B82F6.toInt()),
            Triple("Carbohydrates", "$eatenC / ${targetC}g", eatenC.toFloat() / targetC.toFloat() to 0xFF10B981.toInt()),
            Triple("Dietary Fat", "$eatenF / ${targetF}g", eatenF.toFloat() / targetF.toFloat() to 0xFFF59E0B.toInt())
        ).forEach { (lbl, valStr, pair) ->
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            r.addView(UiKit.text(this, lbl, 12f, UiKit.COL_TEXT_MID, bold = true).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            r.addView(UiKit.text(this, valStr, 12f, UiKit.COL_TEXT_DARK, bold = true, tabular = true))
            calCard.addView(r)
            calCard.addView(UiKit.progressBar(this, pair.first, pair.second))
        }

        // Scale Weight & Steps Row
        val bwRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val bwIn = UiKit.inputBox(this, metrics.bodyweightKg.toString(), "Weight (kg)", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val stIn = UiKit.inputBox(this, metrics.steps.toString(), "Daily Steps", InputType.TYPE_CLASS_NUMBER).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        bwRow.addView(bwIn); bwRow.addView(UiKit.spacerH(this, 6))
        bwRow.addView(stIn); bwRow.addView(UiKit.spacerH(this, 6))
        bwRow.addView(UiKit.outlineButton(this, "Update") {
            db.saveDailyMetrics(metrics.copy(
                bodyweightKg = bwIn.text.toString().toDoubleOrNull() ?: metrics.bodyweightKg,
                steps = stIn.text.toString().toIntOrNull() ?: metrics.steps
            ))
            showBanner("Updated bodyweight & step count TDEE")
            renderActivePage()
        })
        calCard.addView(UiKit.spacerV(this, 6))
        calCard.addView(bwRow)
        pageContent.addView(calCard)

        // 1-Tap Meal Presets & Custom Meal Card
        val mealCard = UiKit.card(this)
        mealCard.addView(UiKit.text(this, "1-Tap Hypertrophy Meal Presets", 14f, UiKit.COL_TEXT_DARK, bold = true))
        mealCard.addView(UiKit.spacerV(this, 6))
        val (pScroll, pRow) = UiKit.hScrollRow(this)
        listOf(
            arrayOf("Breakfast", "Whey Oats & Banana", "640", "52", "86", "10"),
            arrayOf("Post-Workout", "Chicken & Jasmine Rice", "590", "48", "84", "6"),
            arrayOf("Dinner", "Lean Beef & Sweet Potato", "720", "54", "78", "20"),
            arrayOf("Snack", "0% Greek Yogurt & Berries", "340", "32", "28", "11")
        ).forEach { p ->
            pRow.addView(UiKit.outlineButton(this, "+ ${p[1]} (${p[2]})") {
                db.saveMeal(MealLog("meal_${System.currentTimeMillis()}", selectedDateIso, p[0], p[1], p[2].toInt(), p[3].toInt(), p[4].toInt(), p[5].toInt(), System.currentTimeMillis()))
                if (hapticEnabled) NativeHardwareBridge.hapticTick(this)
                renderActivePage()
            })
            pRow.addView(UiKit.spacerH(this, 6))
        }
        mealCard.addView(pScroll)
        mealCard.addView(UiKit.spacerV(this, 10))
        mealCard.addView(UiKit.primaryButton(this, "+ Log Custom Meal", UiKit.COL_ACCENT) { showCustomMealDialog() })
        pageContent.addView(mealCard)

        // Logged Meals List
        meals.forEach { m ->
            val mc = UiKit.card(this, padDp = 12)
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val left = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            left.addView(UiKit.text(this, "${m.mealType} · ${m.name}", 13f, UiKit.COL_TEXT_DARK, bold = true))
            left.addView(UiKit.text(this, "${m.calories} kcal · P ${m.proteinG}g · C ${m.carbsG}g · F ${m.fatG}g", 11f, UiKit.COL_TEXT_MUTED, tabular = true))
            r.addView(left)
            r.addView(UiKit.outlineButton(this, "Delete", 0xFFEF4444.toInt()) {
                db.deleteMeal(m.id); renderActivePage()
            })
            mc.addView(r)
            pageContent.addView(mc)
        }

        // Offline Backup & Health Connect Sync Card
        val syncCard = UiKit.card(this)
        syncCard.addView(UiKit.text(this, "Offline SQLite Backup & Health Connect", 14f, UiKit.COL_TEXT_DARK, bold = true))
        val hcPresent = NativeHardwareBridge.isHealthConnectInstalled(this)
        syncCard.addView(UiKit.text(
            this,
            if (hcPresent) "Health Connect detected on device — ready for Google Fit sync."
            else "Running 100% Offline via on-device SQLite (Health Connect provider absent on this device).",
            12f, UiKit.COL_TEXT_MUTED
        ))
        syncCard.addView(UiKit.spacerV(this, 8))
        syncCard.addView(UiKit.primaryButton(this, "Sync Daily Macros & Weight to Health Connect") {
            showBanner(NativeHardwareBridge.openHealthConnectOrReportOffline(this, "$eatenKcal kcal & ${metrics.bodyweightKg} kg"))
        })
        syncCard.addView(UiKit.spacerV(this, 8))
        val bRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        bRow.addView(UiKit.outlineButton(this, "Export Local JSON") { triggerExportJson() }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        bRow.addView(UiKit.spacerH(this, 8))
        bRow.addView(UiKit.outlineButton(this, "Import Local JSON") { triggerImportJson() }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        syncCard.addView(bRow)
        syncCard.addView(UiKit.spacerV(this, 8))
        syncCard.addView(UiKit.outlineButton(this, "Reset Offline SQLite to Defaults", 0xFFEF4444.toInt()) {
            db.resetToDefaults()
            showBanner("Reset offline SQLite database to defaults")
            renderActivePage()
        })
        pageContent.addView(syncCard)
    }

    private fun showCustomMealDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = UiKit.dp(this@MainActivity, 16)
            setPadding(p, p, p, p)
        }
        val nameIn = UiKit.inputBox(this, "", "Meal Name", InputType.TYPE_CLASS_TEXT)
        val kcalIn = UiKit.inputBox(this, "", "Calories (kcal)", InputType.TYPE_CLASS_NUMBER)
        val pIn = UiKit.inputBox(this, "", "Protein (g)", InputType.TYPE_CLASS_NUMBER)
        val cIn = UiKit.inputBox(this, "", "Carbs (g)", InputType.TYPE_CLASS_NUMBER)
        val fIn = UiKit.inputBox(this, "", "Fat (g)", InputType.TYPE_CLASS_NUMBER)

        listOf("Meal Name" to nameIn, "Calories" to kcalIn, "Protein (g)" to pIn, "Carbs (g)" to cIn, "Fat (g)" to fIn).forEach { (l, ed) ->
            box.addView(UiKit.text(this, l, 11f, UiKit.COL_TEXT_MUTED, bold = true))
            box.addView(ed)
            box.addView(UiKit.spacerV(this, 6))
        }
        AlertDialog.Builder(this, UiKit.dialogTheme())
            .setTitle("Log Custom Meal Offline")
            .setView(box)
            .setPositiveButton("Log Meal") { _, _ ->
                val nm = nameIn.text.toString().trim()
                val kc = kcalIn.text.toString().toIntOrNull() ?: 0
                if (nm.isNotEmpty() && kc > 0) {
                    db.saveMeal(MealLog(
                        "meal_${System.currentTimeMillis()}", selectedDateIso, "Meal", nm, kc,
                        pIn.text.toString().toIntOrNull() ?: 0,
                        cIn.text.toString().toIntOrNull() ?: 0,
                        fIn.text.toString().toIntOrNull() ?: 0,
                        System.currentTimeMillis()
                    ))
                    if (hapticEnabled) NativeHardwareBridge.hapticTick(this)
                    renderActivePage()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showBackupDialog() {
        AlertDialog.Builder(this, UiKit.dialogTheme())
            .setTitle("HyperLog Offline Backup & Appearance")
            .setItems(arrayOf(
                "Switch Theme (Current: ${UiKit.themeMode.label})",
                "Export Local .JSON Backup",
                "Import Local .JSON Backup"
            )) { _, which ->
                when (which) {
                    0 -> showThemePickerDialog()
                    1 -> triggerExportJson()
                    2 -> triggerImportJson()
                }
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun triggerExportJson() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/json"
            putExtra(Intent.EXTRA_TITLE, "hyperlog-backup-${LocalDate.now()}.json")
        }
        try {
            startActivityForResult(intent, REQ_EXPORT_JSON)
        } catch (e: Exception) {
            showBanner("File picker unavailable: ${e.message}")
        }
    }

    private fun triggerImportJson() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        try {
            startActivityForResult(intent, REQ_IMPORT_JSON)
        } catch (e: Exception) {
            showBanner("File picker unavailable: ${e.message}")
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        if (requestCode == REQ_EXPORT_JSON) {
            try {
                val json = db.exportFullJsonBackup()
                contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray(Charsets.UTF_8)) }
                showBanner("Saved offline JSON backup to device storage!")
            } catch (e: Exception) {
                showBanner("Export failed: ${e.message}")
            }
        } else if (requestCode == REQ_IMPORT_JSON) {
            try {
                val json = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                if (!json.isNullOrBlank()) {
                    db.importFullJsonBackup(json)
                    showBanner("Restored offline JSON backup into SQLite!")
                    renderActivePage()
                }
            } catch (e: Exception) {
                showBanner("Import failed: ${e.message}")
            }
        }
    }
}
