# HyperLog Standalone Android App — v3.0.0 (Build 12)

**Package ID:** `com.hyperlog.rp`  
**Version:** `3.0.0` (`versionCode = 12`)  
**Minimum Android:** Android 8.0 Oreo (`API 26`)  
**Target Android:** Android 15 (`API 35`)  
**Signing Schemes:** APK Signature Scheme `v1 (JAR)` + `v2` + `v3` (`4-byte zipaligned`, uncompressed `resources.arsc`)

---

## What's New in v3.0.0 (Build 12)

1. **Strict User-Specific Data Isolation (100% Fresh Clean Slate per Profile)**
   - Every user profile now owns both an isolated SQLite database (`hyperlog_user_<uid>.db`) **and** isolated per-user `SharedPreferences` (`hyperlog_prefs_u_<uid>`) plus namespaced JSON snapshots (`user_database_snapshot_<uid>.json`).
   - Creating or switching to **User B** guarantees **0 prior workouts, 0d streak, 0 logged meals, stopped workout/rest timers, and a neutral 70.0 kg baseline**—User A's or Guest's data is never visible.
   - Includes a quick **Profile** switcher pill in the top header and a **Clear My Personal Logs (Fresh Slate)** action in Settings.

2. **Workout History Analytics & Visual Streak Tracking**
   - Dedicated **History & Streaks** view under **Workouts** tracking total sessions, weekly training frequency (`workouts/wk`), 7-day & 30-day session counts, average workout duration (`min`), total tonnage, and exercises performed.
   - **14-Day Visual Consistency Strip** + live per-user Home Screen `AppWidgetProvider` streak synchronization.

3. **Offline Demo Video Downloads & Dedicated Offline Videos Vault**
   - Download exercise and template demo videos directly to internal offline storage (`filesDir/HyperLogData/videos/offline_saved/`).
   - Browse, filter, watch, and manage all saved demos inside **Library → Offline Videos (`Offline (N)`)** completely offline in Airplane Mode via the 60fps biomechanical animated form player (`0.5× / 1× / 1.5×` speed, interactive scrubber, rep counter, and step-by-step coaching cues).

4. **Phone-Free Manual Workout Entry & Mistaken Data Deletion**
   - Forgot your phone at the gym? Tap **+ Log Past / Missed Workout** (in **Workouts → History & Streaks** or **Calendar**) to log any date, title, duration (`min`), notes, and **multiple exercises** (`sets × weight × reps`).
   - Made a mistake? Delete an entire date's workout (**Delete** / **Delete Session**) or delete a single exercise's sets on a date (**✕ Delete**) with confirmation and automatic streak recalculation.

5. **UI Optimization, Instant Touch Feedback & Pastel Glass (`FROST_GLASS`) Theme**
   - Zero-delay tactile press feedback (`attachInstantPressFeedback`) across buttons, chips, and navigation tabs, responsive `dp`/`sp` scaling across compact and large phones, and the new **Pastel Glass** Glassmorphism theme (`AppThemeMode.FROST_GLASS`).

---

## Installation Instructions (Physical Android Phone)

1. Download **`HyperLog-v3.0-workout-tracker-release.apk`** directly onto your Android phone (or extract **`HyperLog-v3.0-Phone-Install-Bundle.zip`**, which also includes this guide and `GLASSMORPHISM_UI_DESIGN_GUIDE.md`).
2. Open your phone's **Files** or **Downloads** app and tap `HyperLog-v3.0-workout-tracker-release.apk`.
3. If Android prompts to allow installation from your browser/Files app, tap **Settings → Allow from this source**, then tap **Install** (or **Update** if upgrading from `v2.9.0`).
4. Tap **Open** to launch HyperLog 100% offline.

---

## Quality Assurance & Verification Checklist

1. **User-Specific Clean Slate:** Tap the top-bar **Profile** button, create `User B`, and verify `0d` streak, `0` workout sessions, and neutral `70.0 kg` weight with zero bleed from `Guest` or `User A`.
2. **Manual Multi-Exercise Entry & Deletion:** Open **Workouts → History & Streaks**, tap **+ Log Past / Missed Workout**, add 2+ exercises with duration, save, verify the 14-day streak strip updates, then tap **Delete** on a test entry and confirm streak recalculates cleanly.
3. **Offline Video Vault (Airplane Mode):** Open **Library → Offline Videos**, tap **Download Starter Pack (8 Demos)**, enable **Airplane Mode**, and tap **▶ Watch Offline** to verify smooth 60fps animated form playback, speed controls, and scrubbing.
4. **Pastel Glass Theme & Touch Responsiveness:** Open **Settings → Appearance**, select **Pastel Glass**, and verify high-contrast readability and instant press feedback across all 5 bottom navigation tabs.
