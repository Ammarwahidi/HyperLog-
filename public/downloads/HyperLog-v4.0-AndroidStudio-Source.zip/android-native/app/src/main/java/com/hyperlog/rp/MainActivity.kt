package com.hyperlog.rp

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import java.io.File
import java.io.FileInputStream
import android.os.Build
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale
import kotlin.math.roundToInt

/**
 * ============================================================================
 * MainActivity.kt — The Main Screen Controller of HyperLog (v4.0.0 · Build 13)
 *
 * How to Think About This Class (Beginner Friendly!):
 * Imagine a notebook with 6 tabs at the bottom:
 *   0 = Track     (Pick a workout, check off sets with a 'pop' + buzz, or run a cardio timer)
 *   1 = Anatomy   (Tap muscles on the body map to see if they need more or less work)
 *   2 = Workouts  (Calendar, History & Streaks, Manual Entry, Delete Mistakes & Templates)
 *   3 = Library   (Search exercises, download & watch Offline Demo Videos, and view charts)
 *   4 = Wellness  (Circular calorie/protein/water rings, Indian recipes, weight chart & breathing audio)
 *   5 = Settings  (Isolated User Vaults, Pastel Glass theme, storage folders, PDF/JSON backups & Feedback)
 *
 * Whenever you tap a button or finish a set, `renderActivePage()` redraws the current tab
 * cleanly from our fast per-user offline SQLite database (`db`).
 * ============================================================================
 */
class MainActivity : Activity() {

    private lateinit var db: HyperLogDatabase
    private lateinit var rootColumn: LinearLayout
    private lateinit var topBar: LinearLayout
    private lateinit var topDivider: View
    private lateinit var bottomDivider: View
    private lateinit var headerTitleView: TextView
    private lateinit var headerSubtitle: TextView
    private lateinit var settingsTabBtn: LinearLayout
    private lateinit var bannerView: TextView
    private lateinit var timerBar: LinearLayout
    private lateinit var timerText: TextView
    private lateinit var mainScroll: ScrollView
    private lateinit var pageContent: LinearLayout
    private lateinit var minimizedWorkoutBar: LinearLayout
    private lateinit var minimizedWorkoutTitleView: TextView
    private lateinit var minimizedWorkoutClockView: TextView
    private lateinit var bottomNavRow: LinearLayout

    private var currentInsets = SafeScreenInsets(0, 0, 0, 0)

    // Optional live references inside Track tab's inline Rest Timer & Global Timer bars
    private var inlineTimerClockView: TextView? = null
    private var inlineTimerStatusView: TextView? = null
    private var inlineTimerPlayPauseBtn: TextView? = null
    private var inlineGlobalClockView: TextView? = null
    private var inlineGlobalPlayPauseBtn: TextView? = null
    private var inlineTrackFinishBtn: TextView? = null
    private var inlineTrackHealthBtn: TextView? = null

    // UI State: 0=Track (Default), 1=Anatomy, 2=Workouts, 3=Library, 4=Wellness, 5=Settings
    // Day-Zero Clean-Slate Defaults: Week 1 · Day 1 across all profiles
    private var activeTab: Int = 0
    private var activeWeek: Int = 1
    private var activeDay: Int = 1
    private var activeMajorGroup: MajorMuscleGroup = MajorMuscleGroup.ALL
    private var planeMode: String = "dual"
    private var userChosePlaneManually: Boolean = false
    private var selectedMuscleId: String = "chest"
    private var weightUnit: String = "kg"
    private var keepScreenOn: Boolean = true
    private var hapticEnabled: Boolean = true
    private var soundOnTimer: Boolean = true
    private var customRestDurationSec: Int = 90
    private var workoutsSubTab: String = "templates"
    private var wellnessSubTab: String = "wellbeing"
    private var isSyncingOnlineCatalog: Boolean = false
    private var calendarYear: Int = LocalDate.now().year
    private var calendarMonth: Int = LocalDate.now().monthValue
    private var calendarSelectedDateIso: String = LocalDate.now().toString()
    private var librarySubTab: String = "catalog" // "catalog" or "offline"
    private var offlineVideoMuscleFilter: String = "All"
    private var libraryQuery: String = ""
    private var libraryGroupFilter: MajorMuscleGroup = MajorMuscleGroup.ALL
    private var libraryEquipFilter: String = "All"
    private var libraryModalityFilter: String = "All"
    private var libraryLevelFilter: String = "All"
    private var libraryVisibleLimit: Int = 10
    private var loginHydratedFirst10Only: Boolean = true
    private var cachedFirst10Library: List<LibraryExercise> = emptyList()
    private var cachedTotalLibraryCount: Int = 0
    private var lastFilteredLibraryList: List<LibraryExercise> = emptyList()
    private var lastRenderedLibraryCardCount: Int = 0
    private var libraryCardsContainer: LinearLayout? = null
    private var libraryFooterWrap: LinearLayout? = null
    private var libraryChartMetric: String = "top"
    private var selectedDateIso: String = LocalDate.now().toString()
    private var standaloneSession: StandaloneSession? = null
    private var hasSelectedScheduleDay: Boolean = false
    private var activeHomeDropdownKey: String? = null
    private var inlineCustomExName: String = ""
    private var inlineCustomExMuscle: String = "chest"
    private var inlineCustomExEquip: String = "Dumbbell"
    private var inlineCustomExSets: String = "3"
    private var inlineCustomExReps: String = "8–12"
    private var launchpadFilterCategory: String = "All"
    private var launchpadQuery: String = ""
    private var indianDietFilter: String = "All"
    private var indianRecipeQuery: String = ""
    private var weightInputDateIso: String = LocalDate.now().toString()

    // Progressive-Disclosure UI Drawers (Defaulted to Calm Collapsed State)
    private var showTrackerCustomComposer: Boolean = false
    private var showTrackerDeepAnalytics: Boolean = false
    private var showActiveDayStrip: Boolean = false
    private var showOptionalRpeCol: Boolean = false
    private var showTrackOptionsDrawer: Boolean = false
    private var showAnatomyDetailsDrawer: Boolean = false
    private var showAllAnatomyList: Boolean = false
    private var showLibraryFilters: Boolean = false
    private var showWellnessMacroDetails: Boolean = false
    private val expandedWorkoutCardIds = mutableSetOf<String>()
    private var showBodyMetricsDrawer: Boolean = false
    private var showAllHistoryInSettings: Boolean = false
    private var showTestingGuideDrawer: Boolean = false
    private var showTriagePlanDrawer: Boolean = false
    private var focusedTrackerExId: String = "all"
    private val expandedWellnessDropdownKeys = mutableSetOf("indian_videos")
    private var feedbackRating: Int = 5
    private var feedbackCategory: String = "Workout Tracker"
    private var feedbackDraftText: String = ""
    private var pendingExportSourceFile: File? = null

    // Calories & Wellness Tab State
    private var showCalculatorPanel: Boolean = false
    private var calcSex: String = "male"
    private var calcAgeYears: Int = 28
    private var calcWeightKg: Double = 70.0
    private var calcHeightCm: Double = 178.0
    private var calcActivityId: String = "moderate"
    private var calcGoalId: String = "maintenance"

    private var mealBuilderExpanded: Boolean = false
    private var builderMealType: String = "Post-Workout"
    private var builderMealName: String = ""
    private var builderFoodCategory: String = "All"
    private var builderFoodQuery: String = ""
    private val builderIngredients = mutableListOf<MealIngredientPick>()
    private var builderProteinG: Int = 0
    private var builderCarbsG: Int = 0
    private var builderFatG: Int = 0
    private var builderManualKcalOverride: Boolean = false
    private var builderManualKcal: Int = 0
    private var widgetPreviewTier: String = "auto"

    // Guided Yoga/Stretching/Cardio Studio + Breathwork + HIIT/Tools State
    private var selectedFlowId: String = "flow_yoga_morning"
    private var studioStepIdx: Int = 0
    private var studioSecondsLeft: Int = 45
    private var studioTimerRunning: Boolean = false
    private var studioClockView: TextView? = null

    private var breathPattern: String = "box" // "box", "478", "coherent", "pranayama"
    private var breathSecondsLeft: Int = 120
    private var breathTimerRunning: Boolean = false
    private var breathAudioTrackId: String = "tibetan_bowl"
    private var breathAudioVolume: Float = 0.65f
    private var breathAudioMuted: Boolean = false
    private var lastBreathPhaseKey: String = ""
    private var breathClockView: TextView? = null
    private var breathCueView: TextView? = null

    private var tool1RmWeightInput: Double = 100.0
    private var tool1RmRepsInput: Int = 5
    private var toolPlateTargetInput: Double = 100.0
    private var hiitWorkSec: Int = 20
    private var hiitRestSec: Int = 10
    private var hiitTotalRounds: Int = 8
    private var hiitCurrentRound: Int = 1
    private var hiitInWorkPhase: Boolean = true
    private var hiitSecondsLeft: Int = 20
    private var hiitTimerRunning: Boolean = false
    private var hiitClockView: TextView? = null

    // Global Elapsed Workout Timer (runs from workout start until Finish Workout)
    private var globalWorkoutActive: Boolean = false
    private var globalWorkoutPaused: Boolean = false
    private var globalWorkoutAccumulatedSec: Int = 0
    private var globalWorkoutStartedEpochMs: Long = 0L
    private var globalWorkoutTitle: String = ""

    // Cardio Exercise Timer State (tracks cardio in timer instead of sets)
    private val cardioTargetSecMap = mutableMapOf<String, Int>()
    private val cardioRemainingSecMap = mutableMapOf<String, Int>()
    private val cardioCompletedMap = mutableMapOf<String, Int>()
    private val cardioZoneMap = mutableMapOf<String, String>()
    private var activeCardioExId: String? = null
    private var activeCardioClockView: TextView? = null
    private var nutritionChartDays: Int = 10

    // Workout Completion & Google Sync Screen State
    private data class CompletedWorkoutViewState(
        val title: String,
        val dateIso: String,
        val setsCount: Int,
        val tonnageKg: Double,
        val durationMinutes: Int,
        val cardioMinutes: Int,
        var googleSyncStatus: String
    )
    private var completedWorkoutState: CompletedWorkoutViewState? = null

    // Rest Countdown Timer & Background SQLite Parity Monitor
    private val mainHandler = Handler(Looper.getMainLooper())
    private var lastRenderedParitySignature: String = ""
    private var restSecondsRemaining: Int = 0
    private var restSecondsTotal: Int = 90
    private var restTimerRunning: Boolean = false
    private var restTimerEndEpochMs: Long = 0L
    private var restTimerFinishedAlert: Boolean = false
    private var restExerciseLabel: String = "Set Rest"

    private val cardioTickRunnable = object : Runnable {
        override fun run() {
            val exId = activeCardioExId ?: return
            val rem = cardioRemainingSecMap[exId] ?: return
            if (rem > 0) {
                val next = rem - 1
                cardioRemainingSecMap[exId] = next
                activeCardioClockView?.text = formatClock(next)
                if (next == 0) {
                    activeCardioExId = null
                    NativeHardwareBridge.playTimerCompleteTone(this@MainActivity, soundOnTimer)
                    if (hapticEnabled) NativeHardwareBridge.hapticRestComplete(this@MainActivity)
                    showBanner("Cardio timer complete! Tap 'Complete Cardio' to log session.")
                    if (activeTab == 0) renderActivePage()
                } else {
                    mainHandler.postDelayed(this, 1000L)
                }
            }
        }
    }

    private val sqliteParityMonitorRunnable = object : Runnable {
        override fun run() {
            try {
                if (currentFocus !is android.widget.EditText) {
                    val liveSig = db.computeSetLogsParitySignature()
                    if (lastRenderedParitySignature.isNotEmpty() && liveSig != lastRenderedParitySignature) {
                        db.verifyAndRepairSqliteParity(activeWeek, activeDay, standaloneSession)
                        renderActivePage()
                    }
                }
            } catch (_: Exception) {
                // Keep background parity check resilient
            }
            mainHandler.postDelayed(this, 12000L)
        }
    }

    private val globalWorkoutTickRunnable = object : Runnable {
        override fun run() {
            if (!globalWorkoutActive || globalWorkoutPaused) return
            updateGlobalWorkoutUiLive()
            mainHandler.postDelayed(this, 1000L)
        }
    }

    private val studioTickRunnable = object : Runnable {
        override fun run() {
            if (!studioTimerRunning) return
            if (studioSecondsLeft > 0) {
                studioSecondsLeft -= 1
                studioClockView?.text = formatClock(studioSecondsLeft)
                if (studioSecondsLeft == 0) {
                    val flow = SeedCatalog.offlineGuidedFlows().find { it.id == selectedFlowId }
                        ?: SeedCatalog.offlineGuidedFlows().first()
                    if (studioStepIdx < flow.steps.lastIndex) {
                        studioStepIdx += 1
                        studioSecondsLeft = flow.steps[studioStepIdx].durationSec
                        NativeHardwareBridge.playTimerStepTone(this@MainActivity, soundOnTimer)
                        if (activeTab == 4 && wellnessSubTab == "studio") renderActivePage()
                        mainHandler.postDelayed(this, 1000L)
                    } else {
                        studioTimerRunning = false
                        NativeHardwareBridge.playTimerCompleteTone(this@MainActivity, soundOnTimer)
                        if (hapticEnabled) NativeHardwareBridge.hapticRestComplete(this@MainActivity)
                        showBanner("Guided ${flow.title} complete! Tap 'Log Guided Session' to save.")
                        if (activeTab == 4 && wellnessSubTab == "studio") renderActivePage()
                    }
                } else {
                    mainHandler.postDelayed(this, 1000L)
                }
            }
        }
    }

    private val breathTickRunnable = object : Runnable {
        override fun run() {
            if (!breathTimerRunning) return
            if (breathSecondsLeft > 0) {
                breathSecondsLeft -= 1
                val elapsed = (180 - breathSecondsLeft).coerceAtLeast(0)
                val (phaseKey, cue) = when (breathPattern) {
                    "478" -> {
                        val c = elapsed % 19
                        when {
                            c < 4 -> "inhale" to "Inhale slowly through nose (4s)..."
                            c < 11 -> "hold_full" to "Hold gently (7s)..."
                            else -> "exhale" to "Long calming exhale (8s)..."
                        }
                    }
                    "coherent" -> {
                        val c = elapsed % 10
                        if (c < 5) "inhale" to "Smooth belly inhale (5s)..."
                        else "exhale" to "Smooth unhurried exhale (5s)..."
                    }
                    "pranayama" -> {
                        val c = elapsed % 16
                        when {
                            c < 4 -> "inhale" to "Puraka · Deep inhale (4s)..."
                            c < 8 -> "hold_full" to "Antar Kumbhaka · Hold full (4s)..."
                            c < 14 -> "exhale" to "Rechaka · Slow exhale (6s)..."
                            else -> "hold_empty" to "Bahya · Rest empty (2s)..."
                        }
                    }
                    else -> {
                        val c = elapsed % 16
                        when {
                            c < 4 -> "inhale" to "Inhale steadily (4s)..."
                            c < 8 -> "hold_full" to "Hold full (4s)..."
                            c < 12 -> "exhale" to "Exhale smoothly (4s)..."
                            else -> "hold_empty" to "Hold empty (4s)..."
                        }
                    }
                }
                if (phaseKey != lastBreathPhaseKey) {
                    lastBreathPhaseKey = phaseKey
                    BreathingSoundscapeEngine.onPhaseChange(phaseKey)
                }
                breathClockView?.text = formatClock(breathSecondsLeft)
                breathCueView?.text = cue
                if (breathSecondsLeft == 0) {
                    breathTimerRunning = false
                    lastBreathPhaseKey = ""
                    BreathingSoundscapeEngine.stop()
                    NativeHardwareBridge.playTimerCompleteTone(this@MainActivity, soundOnTimer)
                    if (hapticEnabled) NativeHardwareBridge.hapticTick(this@MainActivity)
                    val curWb = db.getWellbeingForDate(selectedDateIso)
                    db.saveWellbeingRecord(curWb.copy(breathMinutes = curWb.breathMinutes + 2))
                    HyperLogStorageManager.saveDatabaseSnapshotAsync(this@MainActivity, db)
                    showBanner("Breathwork complete! +2 min logged to Daily Wellbeing.")
                    if (activeTab == 4 && wellnessSubTab == "wellbeing") renderActivePage()
                } else {
                    mainHandler.postDelayed(this, 1000L)
                }
            }
        }
    }

    private val hiitTickRunnable = object : Runnable {
        override fun run() {
            if (!hiitTimerRunning) return
            if (hiitSecondsLeft > 0) {
                hiitSecondsLeft -= 1
                hiitClockView?.text = "${if (hiitInWorkPhase) "WORK" else "REST"} · ${formatClock(hiitSecondsLeft)} (Rd $hiitCurrentRound/$hiitTotalRounds)"
                if (hiitSecondsLeft == 0) {
                    if (hiitInWorkPhase) {
                        hiitInWorkPhase = false
                        hiitSecondsLeft = hiitRestSec
                        NativeHardwareBridge.playTimerStepTone(this@MainActivity, soundOnTimer)
                        mainHandler.postDelayed(this, 1000L)
                    } else if (hiitCurrentRound < hiitTotalRounds) {
                        hiitCurrentRound += 1
                        hiitInWorkPhase = true
                        hiitSecondsLeft = hiitWorkSec
                        NativeHardwareBridge.playTimerSetTone(this@MainActivity, soundOnTimer)
                        mainHandler.postDelayed(this, 1000L)
                    } else {
                        hiitTimerRunning = false
                        NativeHardwareBridge.playTimerCompleteTone(this@MainActivity, soundOnTimer)
                        if (hapticEnabled) NativeHardwareBridge.hapticRestComplete(this@MainActivity)
                        showBanner("HIIT Interval Session ($hiitTotalRounds rounds) complete!")
                        if (activeTab == 4 && wellnessSubTab == "tools") renderActivePage()
                    }
                } else {
                    mainHandler.postDelayed(this, 1000L)
                }
            }
        }
    }

    private val timerTickRunnable = object : Runnable {
        override fun run() {
            if (!restTimerRunning) return
            val nextRem = if (restTimerEndEpochMs > 0L) {
                ((restTimerEndEpochMs - System.currentTimeMillis() + 999L) / 1000L).toInt().coerceAtLeast(0)
            } else {
                (restSecondsRemaining - 1).coerceAtLeast(0)
            }
            restSecondsRemaining = nextRem
            if (restSecondsRemaining <= 0) {
                restSecondsRemaining = 0
                restTimerRunning = false
                restTimerEndEpochMs = 0L
                restTimerFinishedAlert = true
                savePrefs()
                NativeHardwareBridge.playTimerCompleteTone(this@MainActivity, soundOnTimer)
                if (hapticEnabled) {
                    NativeHardwareBridge.hapticRestComplete(this@MainActivity)
                }
                showBanner("Rest complete ($restExerciseLabel)!")
                updateTimerUiLive()
            } else {
                updateTimerUiLive()
                mainHandler.postDelayed(this, 1000L)
            }
        }
    }

    companion object {
        private const val REQ_EXPORT_JSON = 1001
        private const val REQ_IMPORT_JSON = 1002
        private const val REQ_SAVE_PDF = 1003
        private const val REQ_EXPORT_CSV = 1004
    }

    private fun loadUserPrefsIntoState() {
        val prefs = HyperLogDatabase.getPrefsForActiveUser(this)
        UiKit.themeMode = AppThemeMode.fromId(prefs.getString("themeModeV4", "clay"))
        UiKit.clayHighContrast = prefs.getBoolean("clayHighContrast", false)
        UiKit.clayFlatDepth = prefs.getBoolean("clayFlatDepth", false)
        activeWeek = prefs.getInt("activeWeekV4", 1)
        activeDay = prefs.getInt("activeDayV4", 1)
        weightUnit = prefs.getString("weightUnit", "kg") ?: "kg"
        keepScreenOn = prefs.getBoolean("keepScreenOn", true)
        hapticEnabled = prefs.getBoolean("hapticEnabled", true)
        soundOnTimer = prefs.getBoolean("soundOnTimer", true)
        customRestDurationSec = prefs.getInt("customRestDurationSec", 90).coerceIn(10, 600)
        restSecondsTotal = customRestDurationSec

        calcSex = prefs.getString("calcSex", "male") ?: "male"
        calcAgeYears = prefs.getInt("calcAgeYears", 28)
        calcWeightKg = prefs.getFloat("calcWeightKgV4", 70.0f).toDouble()
        calcHeightCm = prefs.getFloat("calcHeightCm", 178.0f).toDouble()
        calcActivityId = prefs.getString("calcActivityId", "moderate") ?: "moderate"
        calcGoalId = prefs.getString("calcGoalIdV4", "maintenance") ?: "maintenance"
        standaloneSession = parseStandaloneSession(prefs.getString("standaloneSessionJson", null))
        hasSelectedScheduleDay = prefs.getBoolean("hasSelectedScheduleDay", false)
        breathAudioTrackId = prefs.getString("breathAudioTrackId", "tibetan_bowl") ?: "tibetan_bowl"
        breathAudioVolume = prefs.getFloat("breathAudioVolume", 0.65f).coerceIn(0.05f, 1.0f)
        breathAudioMuted = prefs.getBoolean("breathAudioMuted", false)

        globalWorkoutActive = prefs.getBoolean("globalWorkoutActive", false)
        globalWorkoutPaused = prefs.getBoolean("globalWorkoutPaused", false)
        globalWorkoutAccumulatedSec = prefs.getInt("globalWorkoutAccumulatedSec", 0)
        globalWorkoutStartedEpochMs = prefs.getLong("globalWorkoutStartedEpochMs", 0L)
        globalWorkoutTitle = prefs.getString("globalWorkoutTitle", "") ?: ""

        restTimerRunning = prefs.getBoolean("restTimerRunning", false)
        restTimerEndEpochMs = prefs.getLong("restTimerEndEpochMs", 0L)
        restSecondsTotal = prefs.getInt("restSecondsTotal", customRestDurationSec).coerceAtLeast(10)
        restExerciseLabel = prefs.getString("restExerciseLabel", "Set Rest") ?: "Set Rest"
        restTimerFinishedAlert = false
        if (restTimerRunning && restTimerEndEpochMs > 0L) {
            val rem = ((restTimerEndEpochMs - System.currentTimeMillis() + 999L) / 1000L).toInt()
            if (rem > 0) {
                restSecondsRemaining = rem
            } else {
                restTimerRunning = false
                restTimerEndEpochMs = 0L
                restSecondsRemaining = 0
            }
        } else {
            restSecondsRemaining = 0
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = HyperLogDatabase.getInstance(this)
        loadUserPrefsIntoState()

        // Auto-select single-plane anatomy view on compact portrait phones (< 380dp) for crisp tap precision
        planeMode = if (UiKit.isCompactPhone(this)) "anterior" else "dual"

        NativeHardwareBridge.setKeepScreenOn(this, keepScreenOn)

        // Phase 1 Login Optimization + Day-Zero Telemetry Measurement:
        // Hydrate ONLY the First-10 prioritized exercises on critical startup frame!
        HyperLogTelemetryLogger.getOrInitDayZeroEpochMs(this)
        cachedFirst10Library = HyperLogTelemetryLogger.measureOperation(
            context = this,
            db = db,
            category = "lifecycle",
            event = "phase1_first10_sqlite_hydration",
            metadata = mapOf("theme" to UiKit.themeMode.id, "week" to activeWeek, "day" to activeDay)
        ) {
            db.getLibraryExercisesPrioritized(limit = 10, offset = 0)
        }
        cachedTotalLibraryCount = cachedFirst10Library.size
        loginHydratedFirst10Only = true
        libraryVisibleLimit = 10

        buildShellLayout()
        UiKit.configureSystemBarsAndInsets(this, rootColumn) { safe ->
            currentInsets = safe
            applySafeInsetsToShell(safe)
        }

        handleDeepLinkIntent(intent)
        rebuildTopSettingsButton()
        rebuildBottomNav()
        renderActivePage()
        if (globalWorkoutActive && !globalWorkoutPaused) {
            mainHandler.removeCallbacks(globalWorkoutTickRunnable)
            mainHandler.post(globalWorkoutTickRunnable)
        }
        if (restTimerRunning && restSecondsRemaining > 0) {
            mainHandler.removeCallbacks(timerTickRunnable)
            mainHandler.postDelayed(timerTickRunnable, 1000L)
        }

        // Phase 2 Idle Hydration: Defer full library count, schedule materialization & startup package verification
        mainHandler.postDelayed({
            runCatching {
                db.ensureDaySetRowsMaterialized(activeWeek, activeDay)
                cachedTotalLibraryCount = db.getTotalLibraryExerciseCount()
                loginHydratedFirst10Only = false
                HyperLogStreakWidgetProvider.refreshAllWidgets(this)
                HyperLogTelemetryLogger.logEvent(
                    context = this,
                    db = db,
                    level = "METRIC",
                    category = "lifecycle",
                    event = "phase2_idle_catalog_ready",
                    metadata = mapOf("totalExercises" to cachedTotalLibraryCount)
                )
                if (activeTab == 3) {
                    renderActivePage()
                }
            }
            HyperLogStorageManager.ensureDirectories(this)
            HyperLogStorageManager.downloadStartupTrainingPackageIfNeeded(
                context = this,
                db = db,
                forceRedownload = false,
                onProgress = { pct, label ->
                    mainHandler.post {
                        showBanner("Package $pct% · $label")
                    }
                },
                onComplete = { overview ->
                    mainHandler.post {
                        cachedTotalLibraryCount = db.getTotalLibraryExerciseCount()
                        if (overview.exerciseCount > 0) {
                            renderActivePage()
                        }
                    }
                }
            )
        }, 180L)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (handleDeepLinkIntent(intent)) {
            rebuildTopSettingsButton()
            rebuildBottomNav()
            mainScroll.scrollTo(0, 0)
            renderActivePage()
        }
    }

    private fun handleDeepLinkIntent(intent: Intent?): Boolean {
        val target = intent?.getStringExtra(HyperLogStreakWidgetProvider.EXTRA_TARGET_TAB) ?: return false
        activeTab = when (target) {
            "track" -> 0
            "anatomy" -> 1
            "workouts" -> 2
            "library" -> 3
            "calories" -> 4
            "settings" -> 5
            else -> activeTab
        }
        return true
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (!userChosePlaneManually) {
            planeMode = if (UiKit.isCompactPhone(this)) "anterior" else "dual"
        }
        applySafeInsetsToShell(currentInsets)
        rebuildTopSettingsButton()
        rebuildBottomNav()
        renderActivePage()
    }

    override fun onResume() {
        super.onResume()
        if (restTimerRunning && restTimerEndEpochMs > 0L) {
            val rem = ((restTimerEndEpochMs - System.currentTimeMillis() + 999L) / 1000L).toInt()
            if (rem <= 0) {
                restSecondsRemaining = 0
                restTimerRunning = false
                restTimerEndEpochMs = 0L
                restTimerFinishedAlert = true
                savePrefs()
                updateTimerUiLive()
            } else {
                restSecondsRemaining = rem
                updateTimerUiLive()
                mainHandler.removeCallbacks(timerTickRunnable)
                mainHandler.postDelayed(timerTickRunnable, 1000L)
            }
        }
        val liveSig = db.computeSetLogsParitySignature()
        if (lastRenderedParitySignature.isNotEmpty() && liveSig != lastRenderedParitySignature) {
            db.verifyAndRepairSqliteParity(activeWeek, activeDay, standaloneSession)
            renderActivePage()
        }
        mainHandler.removeCallbacks(sqliteParityMonitorRunnable)
        mainHandler.postDelayed(sqliteParityMonitorRunnable, 12000L)
    }

    override fun onPause() {
        mainHandler.removeCallbacks(sqliteParityMonitorRunnable)
        super.onPause()
    }

    override fun onDestroy() {
        BreathingSoundscapeEngine.stop()
        mainHandler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun savePrefs() {
        HyperLogDatabase.getPrefsForActiveUser(this).edit()
            .putString("themeModeV4", UiKit.themeMode.id)
            .putBoolean("clayHighContrast", UiKit.clayHighContrast)
            .putBoolean("clayFlatDepth", UiKit.clayFlatDepth)
            .putInt("activeWeekV4", activeWeek)
            .putInt("activeDayV4", activeDay)
            .putString("weightUnit", weightUnit)
            .putBoolean("keepScreenOn", keepScreenOn)
            .putBoolean("hapticEnabled", hapticEnabled)
            .putBoolean("soundOnTimer", soundOnTimer)
            .putInt("customRestDurationSec", customRestDurationSec)
            .putString("calcSex", calcSex)
            .putInt("calcAgeYears", calcAgeYears)
            .putFloat("calcWeightKgV4", calcWeightKg.toFloat())
            .putFloat("calcHeightCm", calcHeightCm.toFloat())
            .putString("calcActivityId", calcActivityId)
            .putString("calcGoalIdV4", calcGoalId)
            .putString("standaloneSessionJson", serializeStandaloneSession(standaloneSession))
            .putBoolean("hasSelectedScheduleDay", hasSelectedScheduleDay)
            .putString("breathAudioTrackId", breathAudioTrackId)
            .putFloat("breathAudioVolume", breathAudioVolume)
            .putBoolean("breathAudioMuted", breathAudioMuted)
            .putBoolean("globalWorkoutActive", globalWorkoutActive)
            .putBoolean("globalWorkoutPaused", globalWorkoutPaused)
            .putInt("globalWorkoutAccumulatedSec", globalWorkoutAccumulatedSec)
            .putLong("globalWorkoutStartedEpochMs", globalWorkoutStartedEpochMs)
            .putString("globalWorkoutTitle", globalWorkoutTitle)
            .putBoolean("restTimerRunning", restTimerRunning)
            .putLong("restTimerEndEpochMs", restTimerEndEpochMs)
            .putInt("restSecondsTotal", restSecondsTotal)
            .putString("restExerciseLabel", restExerciseLabel)
            .apply()
    }

    private fun applySafeInsetsToShell(safe: SafeScreenInsets) {
        val topSafe = safe.topPx.coerceAtLeast(UiKit.fallbackStatusBarHeightPx(this))
        val hPad = UiKit.rdp(this, 14)
        topBar.setPadding(
            safe.leftPx + hPad,
            topSafe + UiKit.dp(this, 8),
            safe.rightPx + hPad,
            UiKit.dp(this, 10)
        )

        val pagePad = UiKit.rdp(this, 12)
        pageContent.setPadding(
            safe.leftPx + pagePad,
            pagePad,
            safe.rightPx + pagePad,
            UiKit.dp(this, 24)
        )

        val navBottomSafe = safe.bottomPx.coerceAtLeast(UiKit.dp(this, 6))
        bottomNavRow.setPadding(
            safe.leftPx + UiKit.dp(this, 6),
            UiKit.dp(this, 6),
            safe.rightPx + UiKit.dp(this, 6),
            navBottomSafe + UiKit.dp(this, 4)
        )
    }

    private fun buildShellLayout() {
        rootColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(UiKit.COL_BG)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
            )
        }

        // Top Bar: Crest + Wordmark + Streak Subtitle on Left | Single Clean Settings Tab Button on Right
        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(UiKit.COL_CARD)
        }

        val crestIcon = ImageView(this).apply {
            setImageResource(R.drawable.ic_hyperlog_crest)
            scaleType = ImageView.ScaleType.FIT_CENTER
            val sz = UiKit.rdp(this@MainActivity, 32)
            layoutParams = LinearLayout.LayoutParams(sz, sz).apply {
                rightMargin = UiKit.rdp(this@MainActivity, 9)
            }
            setOnClickListener {
                activeTab = 0
                rebuildTopSettingsButton()
                rebuildBottomNav()
                mainScroll.scrollTo(0, 0)
                renderActivePage()
            }
        }
        topBar.addView(crestIcon)

        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                if (hapticEnabled) NativeHardwareBridge.hapticTick(this@MainActivity)
                showStreakSummaryDialog()
            }
        }
        headerTitleView = UiKit.text(this, "HyperLog", 18f, UiKit.COL_TEXT_DARK, bold = true).apply {
            isSingleLine = true
        }
        headerSubtitle = UiKit.text(this, "🔥 Training Streak", 11.5f, UiKit.COL_ACCENT, bold = true).apply {
            isSingleLine = true
        }
        titleCol.addView(headerTitleView)
        titleCol.addView(headerSubtitle)
        topBar.addView(titleCol)

        val profileQuickBtn = UiKit.chip(this, "Profile", false) {
            if (hapticEnabled) NativeHardwareBridge.hapticTick(this@MainActivity)
            showAccountVaultDialog()
        }.apply {
            val px = UiKit.rdp(this@MainActivity, 9)
            val py = UiKit.rdp(this@MainActivity, 7)
            setPadding(px, py, px, py)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                rightMargin = UiKit.rdp(this@MainActivity, 6)
            }
        }
        topBar.addView(profileQuickBtn)

        settingsTabBtn = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            minimumHeight = UiKit.dp(this@MainActivity, 40)
            UiKit.attachInstantPressFeedback(this)
            setOnClickListener {
                activeTab = 5
                if (hapticEnabled) NativeHardwareBridge.hapticTick(this@MainActivity)
                rebuildTopSettingsButton()
                rebuildBottomNav()
                mainScroll.scrollTo(0, 0)
                renderActivePage()
            }
        }
        topBar.addView(settingsTabBtn)
        rootColumn.addView(topBar)

        // Hairline Divider
        topDivider = View(this).apply {
            setBackgroundColor(UiKit.COL_BORDER)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, UiKit.dp(this@MainActivity, 1))
        }
        rootColumn.addView(topDivider)

        // Status Toast Banner
        bannerView = UiKit.text(this, "", 12f, UiKit.COL_PURE_WHITE, bold = true).apply {
            setBackgroundColor(0xFF1E293B.toInt())
            val px = UiKit.rdp(this@MainActivity, 14)
            val py = UiKit.rdp(this@MainActivity, 9)
            setPadding(px, py, px, py)
            visibility = View.GONE
            setOnClickListener { visibility = View.GONE }
        }
        rootColumn.addView(bannerView)

        // Sticky Rest Countdown Bar (visible across tabs when timer is active)
        timerBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0xFF0F172A.toInt())
            val px = UiKit.rdp(this@MainActivity, 12)
            val py = UiKit.rdp(this@MainActivity, 8)
            setPadding(px, py, px, py)
            visibility = View.GONE
        }
        timerText = UiKit.text(this, "Rest 0:00", 12.5f, UiKit.COL_PURE_WHITE, bold = true, tabular = true).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            isSingleLine = true
        }
        timerBar.addView(timerText)
        timerBar.addView(UiKit.chip(this, "-15s", false) { adjustRestTimer(-15) })
        timerBar.addView(UiKit.spacerH(this, 4))
        timerBar.addView(UiKit.chip(this, "+15s", false) { adjustRestTimer(15) })
        timerBar.addView(UiKit.spacerH(this, 4))
        timerBar.addView(UiKit.chip(this, "Stop", true) { stopRestTimer() })
        rootColumn.addView(timerBar)

        // Main Scrollable Viewport with Scroll-to-Load (+10 batch) listener for Exercise Library
        pageContent = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        mainScroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
            isFillViewport = true
            addView(pageContent)
            viewTreeObserver.addOnScrollChangedListener {
                if (activeTab == 3 && libraryCardsContainer != null && lastRenderedLibraryCardCount < lastFilteredLibraryList.size) {
                    val contentHeight = pageContent.height
                    val scrollBottom = scrollY + height
                    val thresholdPx = UiKit.dp(this@MainActivity, 220)
                    if (contentHeight > 0 && contentHeight - scrollBottom <= thresholdPx) {
                        appendNextLibraryBatch()
                    }
                }
            }
        }
        rootColumn.addView(mainScroll)

        // Cross-Page Minimized Active Workout Bar (visible on any non-Track tab while workout is active)
        minimizedWorkoutBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0xFF0F172A.toInt())
            val px = UiKit.rdp(this@MainActivity, 14)
            val py = UiKit.rdp(this@MainActivity, 9)
            setPadding(px, py, px, py)
            visibility = View.GONE
            setOnClickListener {
                activeTab = 0
                if (hapticEnabled) NativeHardwareBridge.hapticTick(this@MainActivity)
                rebuildTopSettingsButton()
                rebuildBottomNav()
                mainScroll.scrollTo(0, 0)
                renderActivePage()
            }
        }
        val pulseDot = View(this).apply {
            background = UiKit.roundedBg(0xFF10B981.toInt(), 5f, this@MainActivity)
            val sz = UiKit.dp(this@MainActivity, 9)
            layoutParams = LinearLayout.LayoutParams(sz, sz).apply {
                rightMargin = UiKit.rdp(this@MainActivity, 8)
            }
        }
        minimizedWorkoutBar.addView(pulseDot)
        minimizedWorkoutTitleView = UiKit.text(this, "Active Workout", 12f, UiKit.COL_PURE_WHITE, bold = true).apply {
            isSingleLine = true
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        minimizedWorkoutBar.addView(minimizedWorkoutTitleView)
        minimizedWorkoutClockView = UiKit.text(this, "0:00", 12.5f, 0xFF6EE7B7.toInt(), bold = true, tabular = true).apply {
            val px = UiKit.rdp(this@MainActivity, 8)
            setPadding(px, 0, px, 0)
        }
        minimizedWorkoutBar.addView(minimizedWorkoutClockView)
        minimizedWorkoutBar.addView(UiKit.chip(this, "Tracker →", true) {
            activeTab = 0
            if (hapticEnabled) NativeHardwareBridge.hapticTick(this@MainActivity)
            rebuildTopSettingsButton()
            rebuildBottomNav()
            mainScroll.scrollTo(0, 0)
            renderActivePage()
        })
        rootColumn.addView(minimizedWorkoutBar)

        // Bottom Divider
        bottomDivider = View(this).apply {
            setBackgroundColor(UiKit.COL_BORDER)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, UiKit.dp(this@MainActivity, 1))
        }
        rootColumn.addView(bottomDivider)

        // 5-Tab Bottom Navigation Bar
        bottomNavRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(UiKit.COL_CARD)
        }
        rootColumn.addView(bottomNavRow)

        applySafeInsetsToShell(SafeScreenInsets(UiKit.fallbackStatusBarHeightPx(this), UiKit.dp(this, 8), 0, 0))
        setContentView(rootColumn)
    }

    private fun createCrispNavIconView(iconKind: String, tintColor: Int, sizePx: Int): View {
        return object : View(this) {
            private val strokePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                style = android.graphics.Paint.Style.STROKE
                strokeCap = android.graphics.Paint.Cap.ROUND
                strokeJoin = android.graphics.Paint.Join.ROUND
                color = tintColor
            }

            init {
                if (android.os.Build.VERSION.SDK_INT >= 29) {
                    isForceDarkAllowed = false
                }
            }

            override fun onDraw(canvas: android.graphics.Canvas) {
                super.onDraw(canvas)
                val w = width.toFloat().coerceAtLeast(1f)
                val h = height.toFloat().coerceAtLeast(1f)
                val s = kotlin.math.min(w, h)
                val ox = (w - s) * 0.5f
                val oy = (h - s) * 0.5f
                fun sx(v: Float) = ox + (v / 24f) * s
                fun sy(v: Float) = oy + (v / 24f) * s
                strokePaint.color = tintColor
                strokePaint.strokeWidth = (s * 0.092f).coerceAtLeast(2.2f)

                when (iconKind) {
                    "track" -> {
                        // Angled gym dumbbell
                        canvas.drawLine(sx(6.8f), sy(6.8f), sx(17.2f), sy(17.2f), strokePaint)
                        canvas.drawLine(sx(3.5f), sy(10.1f), sx(10.1f), sy(3.5f), strokePaint)
                        canvas.drawLine(sx(13.9f), sy(20.5f), sx(20.5f), sy(13.9f), strokePaint)
                        canvas.drawLine(sx(2.5f), sy(6.3f), sx(6.3f), sy(2.5f), strokePaint)
                        canvas.drawLine(sx(17.7f), sy(21.5f), sx(21.5f), sy(17.7f), strokePaint)
                    }
                    "anatomy" -> {
                        // Clean athletic silhouette / vitals figure
                        canvas.drawCircle(sx(12f), sy(4.6f), (2.2f / 24f) * s, strokePaint)
                        canvas.drawLine(sx(5.5f), sy(9.2f), sx(18.5f), sy(9.2f), strokePaint)
                        canvas.drawLine(sx(9.6f), sy(9.2f), sx(9.6f), sy(14.5f), strokePaint)
                        canvas.drawLine(sx(14.4f), sy(9.2f), sx(14.4f), sy(14.5f), strokePaint)
                        canvas.drawLine(sx(9.6f), sy(13.6f), sx(14.4f), sy(13.6f), strokePaint)
                        canvas.drawLine(sx(9.6f), sy(14.5f), sx(8.0f), sy(20.6f), strokePaint)
                        canvas.drawLine(sx(14.4f), sy(14.5f), sx(16.0f), sy(20.6f), strokePaint)
                    }
                    "workouts" -> {
                        // Calendar schedule with checkmark
                        val r = (2.2f / 24f) * s
                        canvas.drawRoundRect(sx(3.8f), sy(4.8f), sx(20.2f), sy(20.6f), r, r, strokePaint)
                        canvas.drawLine(sx(8f), sy(2.8f), sx(8f), sy(6.2f), strokePaint)
                        canvas.drawLine(sx(16f), sy(2.8f), sx(16f), sy(6.2f), strokePaint)
                        canvas.drawLine(sx(3.8f), sy(9.5f), sx(20.2f), sy(9.5f), strokePaint)
                        val checkPath = android.graphics.Path().apply {
                            moveTo(sx(8.6f), sy(14.6f))
                            lineTo(sx(11.1f), sy(17.0f))
                            lineTo(sx(15.6f), sy(12.4f))
                        }
                        canvas.drawPath(checkPath, strokePaint)
                    }
                    "library" -> {
                        // Open exercise handbook
                        val bookPath = android.graphics.Path().apply {
                            moveTo(sx(12f), sy(5.2f))
                            quadTo(sx(8f), sy(3.8f), sx(3.8f), sy(5.0f))
                            lineTo(sx(3.8f), sy(19.4f))
                            quadTo(sx(8f), sy(18.2f), sx(12f), sy(19.6f))
                            quadTo(sx(16f), sy(18.2f), sx(20.2f), sy(19.4f))
                            lineTo(sx(20.2f), sy(5.0f))
                            quadTo(sx(16f), sy(3.8f), sx(12f), sy(5.2f))
                        }
                        canvas.drawPath(bookPath, strokePaint)
                        canvas.drawLine(sx(12f), sy(5.2f), sx(12f), sy(19.6f), strokePaint)
                    }
                    "calories" -> {
                        // Metabolic flame
                        val flame = android.graphics.Path().apply {
                            moveTo(sx(12f), sy(2.8f))
                            cubicTo(sx(15.5f), sy(6.4f), sx(18.8f), sy(9.6f), sx(18.8f), sy(14.0f))
                            cubicTo(sx(18.8f), sy(18.0f), sx(15.8f), sy(21.0f), sx(12f), sy(21.0f))
                            cubicTo(sx(8.2f), sy(21.0f), sx(5.2f), sy(18.0f), sx(5.2f), sy(14.0f))
                            cubicTo(sx(5.2f), sy(10.8f), sx(6.9f), sy(8.2f), sx(9.0f), sy(6.2f))
                            cubicTo(sx(8.9f), sy(8.2f), sx(9.8f), sy(9.6f), sx(10.8f), sy(10.2f))
                            cubicTo(sx(10.5f), sy(7.4f), sx(11.1f), sy(5.0f), sx(12f), sy(2.8f))
                            close()
                        }
                        canvas.drawPath(flame, strokePaint)
                        canvas.drawCircle(sx(12f), sy(16.6f), (2.1f / 24f) * s, strokePaint)
                    }
                    else -> {
                        // Settings sliders / gear controls
                        canvas.drawLine(sx(4f), sy(6.5f), sx(20f), sy(6.5f), strokePaint)
                        canvas.drawLine(sx(4f), sy(12f), sx(20f), sy(12f), strokePaint)
                        canvas.drawLine(sx(4f), sy(17.5f), sx(20f), sy(17.5f), strokePaint)
                        val knobPaint = android.graphics.Paint(strokePaint).apply {
                            style = android.graphics.Paint.Style.FILL
                            color = UiKit.COL_CARD
                        }
                        val kr = (2.2f / 24f) * s
                        canvas.drawCircle(sx(9f), sy(6.5f), kr, knobPaint)
                        canvas.drawCircle(sx(9f), sy(6.5f), kr, strokePaint)
                        canvas.drawCircle(sx(15.5f), sy(12f), kr, knobPaint)
                        canvas.drawCircle(sx(15.5f), sy(12f), kr, strokePaint)
                        canvas.drawCircle(sx(10.5f), sy(17.5f), kr, knobPaint)
                        canvas.drawCircle(sx(10.5f), sy(17.5f), kr, strokePaint)
                    }
                }
            }
        }.apply {
            layoutParams = LinearLayout.LayoutParams(sizePx, sizePx)
        }
    }

    private fun rebuildTopSettingsButton() {
        val selected = activeTab == 5
        settingsTabBtn.removeAllViews()
        val fgColor = if (selected) UiKit.COL_PURE_WHITE else UiKit.COL_TEXT_DARK
        val sz = UiKit.rdp(this@MainActivity, 16)
        val gearIcon = createCrispNavIconView("settings", fgColor, sz).apply {
            layoutParams = LinearLayout.LayoutParams(sz, sz).apply {
                rightMargin = UiKit.rdp(this@MainActivity, 5)
            }
        }
        settingsTabBtn.addView(gearIcon)
        settingsTabBtn.addView(UiKit.text(this, "Settings", 12f, fgColor, bold = true).apply {
            isSingleLine = true
        })
        settingsTabBtn.background = UiKit.roundedBg(
            fillColor = if (selected) UiKit.COL_ACCENT else UiKit.COL_SUBTLE,
            radiusDp = 11f,
            ctx = this,
            strokeColor = if (selected) UiKit.COL_ACCENT else UiKit.COL_BORDER,
            strokeWidthDp = 1f
        )
        val px = UiKit.rdp(this, 11)
        val py = UiKit.rdp(this, 8)
        settingsTabBtn.setPadding(px, py, px, py)
    }

    private fun refreshShellTheme() {
        UiKit.refreshSystemBarIconLuminance(this)
        if (UiKit.isPastelGlass) {
            rootColumn.background = UiKit.pastelGlassRootDrawable()
            topBar.background = UiKit.pastelGlassSurfaceDrawable(this, radiusDp = 0f, subtle = false)
            bottomNavRow.background = UiKit.pastelGlassSurfaceDrawable(this, radiusDp = 0f, subtle = false)
        } else {
            rootColumn.setBackgroundColor(UiKit.COL_BG)
            topBar.setBackgroundColor(UiKit.COL_CARD)
            bottomNavRow.setBackgroundColor(UiKit.COL_CARD)
        }
        topDivider.setBackgroundColor(UiKit.COL_BORDER)
        bottomDivider.setBackgroundColor(UiKit.COL_BORDER)
        headerTitleView.setTextColor(UiKit.COL_TEXT_DARK)
        headerSubtitle.setTextColor(UiKit.COL_ACCENT)
        rebuildTopSettingsButton()
        rebuildBottomNav()
        renderActivePage()
    }

    private fun rebuildBottomNav() {
        bottomNavRow.removeAllViews()
        // Tracker is Tab 0 (first tab); Tab 4 unites Nutrition, Yoga/Cardio Studio, Wellbeing & Tools
        val tabs = listOf(
            Triple(0, "Tracker", "track"),
            Triple(1, "Anatomy", "anatomy"),
            Triple(2, "Workouts", "workouts"),
            Triple(3, "Library", "library"),
            Triple(4, "Wellness", "calories")
        )
        val compact = UiKit.isCompactPhone(this)
        val iconSizePx = UiKit.rdp(this, if (compact) 21 else 23)

        tabs.forEachIndexed { pos, (tabIdx, label, iconKind) ->
            val selected = activeTab == tabIdx
            val tintColor = if (selected) UiKit.COL_ACCENT else UiKit.COL_TEXT_MUTED
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                minimumHeight = UiKit.dp(this@MainActivity, 54)
                val py = UiKit.dp(this@MainActivity, 5)
                setPadding(UiKit.dp(this@MainActivity, 2), py, UiKit.dp(this@MainActivity, 2), py)
                background = if (selected) {
                    when {
                        UiKit.isClay -> {
                            val topC = if (UiKit.isDark) 0xFF2B315A.toInt() else 0xFFFFFFFF.toInt()
                            val botC = if (UiKit.isDark) 0xFF202546.toInt() else 0xFFECE9FA.toInt()
                            val rimC = if (UiKit.isDark) 0xFF101326.toInt() else 0xFFD4D0EE.toInt()
                            UiKit.claySurfaceDrawable(topC, botC, rimC, UiKit.COL_BORDER, 15f, this@MainActivity)
                        }
                        UiKit.isPastelGlass -> UiKit.pastelGlassSurfaceDrawable(this@MainActivity, radiusDp = 14f, subtle = false)
                        else -> UiKit.roundedBg(UiKit.COL_SUBTLE, 12f, this@MainActivity)
                    }
                } else null
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    if (pos < tabs.lastIndex) rightMargin = UiKit.dp(this@MainActivity, 3)
                }
                UiKit.attachInstantPressFeedback(this)
                setOnClickListener {
                    activeTab = tabIdx
                    if (hapticEnabled) NativeHardwareBridge.hapticTick(this@MainActivity)
                    HyperLogTelemetryLogger.logEvent(
                        context = this@MainActivity,
                        db = db,
                        level = "ACTION",
                        category = "navigation",
                        event = "bottom_nav_selected",
                        metadata = mapOf("tab" to label.lowercase(Locale.US))
                    )
                    rebuildTopSettingsButton()
                    rebuildBottomNav()
                    mainScroll.scrollTo(0, 0)
                    renderActivePage()
                }
            }
            val indicator = View(this).apply {
                background = UiKit.roundedBg(if (selected) UiKit.COL_ACCENT else 0x00000000, 3f, this@MainActivity)
                layoutParams = LinearLayout.LayoutParams(UiKit.rdp(this@MainActivity, 18), UiKit.dp(this@MainActivity, 2)).apply {
                    bottomMargin = UiKit.dp(this@MainActivity, 3)
                }
            }
            item.addView(indicator)

            val navIcon = createCrispNavIconView(iconKind, tintColor, iconSizePx).apply {
                layoutParams = LinearLayout.LayoutParams(iconSizePx, iconSizePx).apply {
                    bottomMargin = UiKit.dp(this@MainActivity, 3)
                }
            }
            item.addView(navIcon)

            item.addView(UiKit.text(
                this,
                label,
                if (compact) 10.2f else 10.8f,
                tintColor,
                bold = selected
            ).apply {
                isSingleLine = true
                gravity = Gravity.CENTER
            })
            bottomNavRow.addView(item)
        }
    }

    private fun showStreakSummaryDialog() {
        val snap = db.getWidgetProgressSnapshot(activeWeek)
        val loggedToday = snap.last7Days.lastOrNull()?.second == true

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = UiKit.dp(this@MainActivity, 18)
            setPadding(p, p, p, p)
        }

        val heroRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        heroRow.addView(UiKit.metricBox(this, "Current Streak", "🔥 ${snap.streakDays}d", UiKit.COL_FLAME_ORANGE).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                rightMargin = UiKit.dp(this@MainActivity, 6)
            }
        })
        heroRow.addView(UiKit.metricBox(this, "Best Streak", "${snap.bestStreakDays}d", UiKit.COL_ACCENT).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        box.addView(heroRow)
        box.addView(UiKit.spacerV(this, 12))

        val statusMsg = if (loggedToday) {
            "✓ Logged today! Your streak is active and synced to your Android Home Screen widget."
        } else {
            "Not logged today yet. Check off 1 workout set or log 1 meal today to advance your streak to ${snap.streakDays + 1} days!"
        }
        box.addView(UiKit.text(this, statusMsg, 12.5f, if (loggedToday) 0xFF10B981.toInt() else UiKit.COL_TEXT_DARK, bold = loggedToday))
        box.addView(UiKit.spacerV(this, 12))

        box.addView(UiKit.text(this, "Last 7 Days Consistency", 11.5f, UiKit.COL_TEXT_MUTED, bold = true))
        box.addView(UiKit.spacerV(this, 6))
        val daysRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        snap.last7Days.forEachIndexed { idx, (letter, active) ->
            val isToday = idx == snap.last7Days.lastIndex
            val fg = if (active) UiKit.COL_PURE_WHITE else UiKit.COL_TEXT_MUTED
            val bg = when {
                active && isToday -> UiKit.COL_FLAME_ORANGE
                active -> UiKit.COL_ACCENT
                else -> UiKit.COL_SUBTLE
            }
            daysRow.addView(UiKit.text(this, if (active) "$letter\n✓" else "$letter\n·", 11f, fg, bold = true).apply {
                gravity = Gravity.CENTER
                background = UiKit.roundedBg(bg, 8f, this@MainActivity, if (isToday && !active) UiKit.COL_ACCENT else UiKit.COL_BORDER, 1f)
                val py = UiKit.dp(this@MainActivity, 6)
                setPadding(0, py, 0, py)
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    if (idx < 6) rightMargin = UiKit.dp(this@MainActivity, 4)
                }
            })
        }
        box.addView(daysRow)

        AlertDialog.Builder(this, UiKit.dialogTheme())
            .setTitle("Consistency Streak")
            .setView(box)
            .setPositiveButton(if (loggedToday) "Done" else "Log Workout Set") { _, _ ->
                if (!loggedToday) {
                    activeTab = 0
                    rebuildTopSettingsButton()
                    rebuildBottomNav()
                    renderActivePage()
                }
            }
            .setNeutralButton("Log Meal") { _, _ ->
                activeTab = 4
                rebuildTopSettingsButton()
                rebuildBottomNav()
                renderActivePage()
            }
            .show()
    }

    private fun showBanner(msg: String) {
        bannerView.text = "$msg  (Tap to dismiss)"
        bannerView.visibility = View.VISIBLE
    }

    // =========================================================================
    // PRECISION NUMERIC FORMATTING & OFFLINE SQLITE PARITY REFRESH
    // =========================================================================
    private val LB_PER_KG = 2.2046226218

    private fun formatCleanDecimal(v: Double): String {
        if (!v.isFinite()) return "0"
        val rounded2 = (v * 100.0).roundToInt() / 100.0
        val asInt = rounded2.roundToInt()
        if (kotlin.math.abs(rounded2 - asInt.toDouble()) < 1e-6) {
            return asInt.toString()
        }
        val rounded1 = (rounded2 * 10.0).roundToInt() / 10.0
        if (kotlin.math.abs(rounded2 - rounded1) < 1e-6) {
            return String.format(Locale.US, "%.1f", rounded1)
        }
        return String.format(Locale.US, "%.2f", rounded2).trimEnd('0').trimEnd('.')
    }

    private fun formatWeightForInput(weightKg: Double): String {
        if (!weightKg.isFinite() || weightKg <= 0.0) return "0"
        val raw = if (weightUnit == "lb") weightKg * LB_PER_KG else weightKg
        val quarterSnapped = (raw * 4.0).roundToInt() / 4.0
        if (kotlin.math.abs(raw - quarterSnapped) < 0.03) {
            return formatCleanDecimal(quarterSnapped)
        }
        val tenthSnapped = (raw * 10.0).roundToInt() / 10.0
        if (kotlin.math.abs(raw - tenthSnapped) < 0.02) {
            return formatCleanDecimal(tenthSnapped)
        }
        return formatCleanDecimal(raw)
    }

    private fun parseInputToWeightKg(typedVal: Double): Double {
        if (!typedVal.isFinite() || typedVal <= 0.0) return 0.0
        val kg = if (weightUnit == "lb") typedVal / LB_PER_KG else typedVal
        val quarterKg = (kg * 4.0).roundToInt() / 4.0
        if (weightUnit == "lb" && kotlin.math.abs(kg - quarterKg) < 0.008) {
            return quarterKg
        }
        return ((kg.coerceAtMost(2500.0)) * 10000.0).roundToInt() / 10000.0
    }

    private fun forceRefreshTrackerFromSqlite() {
        val (repairedCount, activeSetCount) = db.verifyAndRepairSqliteParity(
            activeWeek = activeWeek,
            activeDay = activeDay,
            standalone = standaloneSession
        )
        val totalSets = db.getSetLogs().size
        HyperLogStreakWidgetProvider.refreshAllWidgets(this)
        if (hapticEnabled) NativeHardwareBridge.hapticTick(this)
        renderActivePage()
        val repairSuffix = if (repairedCount > 0) " · $repairedCount rows normalized" else ""
        showBanner("Tracker refreshed from SQLite ($activeSetCount active sets · $totalSets total$repairSuffix)")
    }

    // =========================================================================
    // VIBRATION & AUDIO TONE REST TIMER + GLOBAL WORKOUT TIMER ENGINE
    // =========================================================================
    private fun formatClock(sec: Int): String {
        val clamped = sec.coerceAtLeast(0)
        val hrs = clamped / 3600
        val mins = (clamped % 3600) / 60
        val rem = clamped % 60
        return if (hrs > 0) String.format(Locale.US, "%d:%02d:%02d", hrs, mins, rem)
        else String.format(Locale.US, "%d:%02d", mins, rem)
    }

    private fun currentGlobalElapsedSec(): Int {
        if (!globalWorkoutActive) return 0
        val liveDelta = if (!globalWorkoutPaused && globalWorkoutStartedEpochMs > 0L) {
            ((System.currentTimeMillis() - globalWorkoutStartedEpochMs) / 1000L).toInt().coerceAtLeast(0)
        } else 0
        return (globalWorkoutAccumulatedSec + liveDelta).coerceAtLeast(0)
    }

    private fun startOrEnsureGlobalWorkoutTimer(workoutTitle: String, playTone: Boolean = true) {
        if (workoutTitle.isNotBlank()) {
            globalWorkoutTitle = workoutTitle
        }
        if (!globalWorkoutActive) {
            globalWorkoutActive = true
            globalWorkoutPaused = false
            globalWorkoutAccumulatedSec = 0
            globalWorkoutStartedEpochMs = System.currentTimeMillis()
            savePrefs()
            if (playTone) NativeHardwareBridge.playTimerSetTone(this, soundOnTimer)
            mainHandler.removeCallbacks(globalWorkoutTickRunnable)
            mainHandler.post(globalWorkoutTickRunnable)
        } else if (globalWorkoutPaused) {
            globalWorkoutPaused = false
            globalWorkoutStartedEpochMs = System.currentTimeMillis()
            savePrefs()
            if (playTone) NativeHardwareBridge.playTimerSetTone(this, soundOnTimer)
            mainHandler.removeCallbacks(globalWorkoutTickRunnable)
            mainHandler.post(globalWorkoutTickRunnable)
        }
        updateGlobalWorkoutUiLive()
    }

    private fun togglePauseGlobalWorkoutTimer(defaultTitle: String) {
        if (!globalWorkoutActive) {
            startOrEnsureGlobalWorkoutTimer(defaultTitle, playTone = true)
            return
        }
        if (globalWorkoutPaused) {
            globalWorkoutPaused = false
            globalWorkoutStartedEpochMs = System.currentTimeMillis()
            NativeHardwareBridge.playTimerSetTone(this, soundOnTimer)
            savePrefs()
            mainHandler.removeCallbacks(globalWorkoutTickRunnable)
            mainHandler.post(globalWorkoutTickRunnable)
        } else {
            globalWorkoutAccumulatedSec = currentGlobalElapsedSec()
            globalWorkoutPaused = true
            globalWorkoutStartedEpochMs = 0L
            savePrefs()
            mainHandler.removeCallbacks(globalWorkoutTickRunnable)
        }
        updateGlobalWorkoutUiLive()
    }

    private fun stopAndResetGlobalWorkoutTimer() {
        mainHandler.removeCallbacks(globalWorkoutTickRunnable)
        globalWorkoutActive = false
        globalWorkoutPaused = false
        globalWorkoutAccumulatedSec = 0
        globalWorkoutStartedEpochMs = 0L
        globalWorkoutTitle = ""
        savePrefs()
        updateGlobalWorkoutUiLive()
    }

    private fun updateGlobalWorkoutUiLive() {
        val elapsed = currentGlobalElapsedSec()
        inlineGlobalClockView?.text = "⏱ ${formatClock(elapsed)}"
        inlineGlobalClockView?.setTextColor(
            when {
                !globalWorkoutActive -> UiKit.COL_TEXT_MUTED
                globalWorkoutPaused -> 0xFFF59E0B.toInt()
                else -> 0xFF059669.toInt()
            }
        )
        inlineGlobalPlayPauseBtn?.text = when {
            !globalWorkoutActive -> "Start Timer"
            globalWorkoutPaused -> "Resume"
            else -> "Pause"
        }

        if (globalWorkoutActive && activeTab != 0) {
            val title = globalWorkoutTitle.ifBlank {
                standaloneSession?.templateName ?: "Active Workout"
            }
            minimizedWorkoutTitleView.text = if (globalWorkoutPaused) "Paused · $title" else title
            minimizedWorkoutClockView.text = formatClock(elapsed)
            minimizedWorkoutBar.visibility = View.VISIBLE
        } else {
            minimizedWorkoutBar.visibility = View.GONE
        }
    }

    private fun startRestTimer(seconds: Int, exerciseName: String) {
        mainHandler.removeCallbacks(timerTickRunnable)
        val target = seconds.coerceIn(5, 900)
        customRestDurationSec = target
        restSecondsTotal = target
        restSecondsRemaining = target
        restExerciseLabel = exerciseName
        restTimerFinishedAlert = false
        restTimerRunning = true
        restTimerEndEpochMs = System.currentTimeMillis() + target * 1000L
        NativeHardwareBridge.playTimerSetTone(this, soundOnTimer)
        savePrefs()
        updateTimerUiLive()
        mainHandler.postDelayed(timerTickRunnable, 1000L)
    }

    private fun togglePauseResumeRestTimer() {
        if (restTimerRunning) {
            if (restTimerEndEpochMs > 0L) {
                restSecondsRemaining = ((restTimerEndEpochMs - System.currentTimeMillis() + 999L) / 1000L).toInt().coerceAtLeast(0)
            }
            restTimerRunning = false
            restTimerEndEpochMs = 0L
            savePrefs()
            mainHandler.removeCallbacks(timerTickRunnable)
            updateTimerUiLive()
        } else {
            val startFrom = if (restSecondsRemaining > 0) restSecondsRemaining else customRestDurationSec
            restSecondsRemaining = startFrom
            restSecondsTotal = restSecondsTotal.coerceAtLeast(startFrom)
            restTimerFinishedAlert = false
            restTimerRunning = true
            restTimerEndEpochMs = System.currentTimeMillis() + startFrom * 1000L
            savePrefs()
            NativeHardwareBridge.playTimerSetTone(this, soundOnTimer)
            updateTimerUiLive()
            mainHandler.removeCallbacks(timerTickRunnable)
            mainHandler.postDelayed(timerTickRunnable, 1000L)
        }
    }

    private fun adjustRestTimer(delta: Int) {
        if (restTimerRunning || restSecondsRemaining > 0) {
            val baseRem = if (restTimerRunning && restTimerEndEpochMs > 0L) {
                ((restTimerEndEpochMs - System.currentTimeMillis() + 999L) / 1000L).toInt().coerceAtLeast(0)
            } else {
                restSecondsRemaining
            }
            val next = (baseRem + delta).coerceIn(5, 900)
            restSecondsRemaining = next
            customRestDurationSec = next
            restSecondsTotal = maxOf(restSecondsTotal, next)
            if (restTimerRunning) {
                restTimerEndEpochMs = System.currentTimeMillis() + next * 1000L
            }
        } else {
            customRestDurationSec = (customRestDurationSec + delta).coerceIn(10, 900)
            restSecondsTotal = customRestDurationSec
        }
        restTimerFinishedAlert = false
        NativeHardwareBridge.playTimerSetTone(this, soundOnTimer)
        savePrefs()
        updateTimerUiLive()
    }

    private fun setPresetRestSeconds(sec: Int) {
        val clean = sec.coerceIn(10, 900)
        customRestDurationSec = clean
        restSecondsTotal = clean
        restTimerFinishedAlert = false
        savePrefs()
        if (restTimerRunning) {
            startRestTimer(clean, restExerciseLabel)
        } else {
            NativeHardwareBridge.playTimerSetTone(this, soundOnTimer)
            restSecondsRemaining = 0
            updateTimerUiLive()
            if (activeTab == 0 || activeTab == 5) renderActivePage()
        }
    }

    private fun stopRestTimer() {
        mainHandler.removeCallbacks(timerTickRunnable)
        restTimerRunning = false
        restTimerEndEpochMs = 0L
        restSecondsRemaining = 0
        restTimerFinishedAlert = false
        savePrefs()
        updateTimerUiLive()
    }

    private fun updateTimerUiLive() {
        if (restSecondsRemaining > 0 && (restTimerRunning || activeTab != 0)) {
            timerText.text = "Rest ${formatClock(restSecondsRemaining)} · $restExerciseLabel"
            timerBar.visibility = View.VISIBLE
        } else {
            timerBar.visibility = View.GONE
        }

        val shownClock = if (restSecondsRemaining > 0 || restTimerRunning) restSecondsRemaining else customRestDurationSec
        inlineTimerClockView?.text = if (restTimerFinishedAlert && restSecondsRemaining == 0) "0:00" else formatClock(shownClock)
        inlineTimerClockView?.setTextColor(
            when {
                restTimerFinishedAlert -> 0xFF10B981.toInt()
                restTimerRunning -> UiKit.COL_ACCENT
                else -> UiKit.COL_TEXT_DARK
            }
        )
        inlineTimerStatusView?.text = when {
            restTimerFinishedAlert -> "Rest done!"
            restTimerRunning -> "Resting · $restExerciseLabel"
            restSecondsRemaining > 0 -> "Paused"
            else -> "Rest Timer"
        }
        inlineTimerPlayPauseBtn?.text = when {
            restTimerRunning -> "Pause"
            restSecondsRemaining > 0 -> "Resume"
            else -> "Start"
        }
    }

    private fun triggerOnlineCatalogSync(onDone: (() -> Unit)? = null) {
        if (isSyncingOnlineCatalog) {
            showBanner("Already syncing online exercise catalog...")
            return
        }
        val (_, transportLabel) = NativeHardwareBridge.getNetworkStatus(this)
        isSyncingOnlineCatalog = true
        showBanner("Pulling 870+ exercises & 13 workouts via $transportLabel...")
        renderActivePage()

        Thread {
            try {
                val (totalAfter, newlyAdded, tplCount) = db.syncOnlineCatalogOverNetwork()
                mainHandler.post {
                    isSyncingOnlineCatalog = false
                    NativeHardwareBridge.playTimerSetTone(this@MainActivity, soundOnTimer)
                    if (hapticEnabled) NativeHardwareBridge.hapticTick(this@MainActivity)
                    showBanner("✓ Synced $totalAfter exercises (+$newlyAdded new) & $tplCount workouts into Offline SQLite!")
                    onDone?.invoke()
                    renderActivePage()
                }
            } catch (e: Exception) {
                mainHandler.post {
                    isSyncingOnlineCatalog = false
                    showBanner("Offline mode active (${e.message ?: "no network"}) — using local SQLite exercise catalog.")
                    renderActivePage()
                }
            }
        }.start()
    }

    private fun showWorkoutHelpDialog(
        workoutTitle: String,
        subtitleSummary: String,
        exerciseSpecs: List<Triple<String, String, String>> // (name, primaryMuscleId, prescriptionSummary)
    ) {
        val landmarks = db.getLandmarks()
        // Optimization: Fetch the exercise library ONCE from SQLite instead of inside the loop below!
        val libraryList = db.getLibraryExercises()
        val libraryMap = libraryList.associateBy { it.name.lowercase(Locale.US) }
        val weekMeta = MESOCYCLE_WEEKS.find { it.week == activeWeek } ?: MESOCYCLE_WEEKS[2]

        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = UiKit.dp(this@MainActivity, 16)
            setPadding(p, p, p, p)
        }
        scroll.addView(box)

        box.addView(UiKit.text(this, subtitleSummary, 12.5f, UiKit.COL_ACCENT, bold = true))
        box.addView(UiKit.spacerV(this, 8))

        val guideCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = UiKit.roundedBg(UiKit.COL_SUBTLE, 11f, this@MainActivity, UiKit.COL_BORDER, 1f)
            val p = UiKit.rdp(this@MainActivity, 11)
            setPadding(p, p, p, p)
        }
        guideCard.addView(UiKit.text(this, "How to Execute This Workout", 13f, UiKit.COL_TEXT_DARK, bold = true))
        guideCard.addView(UiKit.spacerV(this, 4))
        guideCard.addView(UiKit.text(this, "1. Warm up 3–5 min + 2 lighter ramp sets on your first compound lift.", 11.5f, UiKit.COL_TEXT_MID))
        guideCard.addView(UiKit.text(this, "2. Target Effort: ${weekMeta.targetRir} (${weekMeta.focusNote}).", 11.5f, UiKit.COL_TEXT_MID))
        guideCard.addView(UiKit.text(this, "3. Control a 2–3s eccentric stretch on every rep, check off each set to auto-trigger your Rest Timer, and tap Finish Workout when done.", 11.5f, UiKit.COL_TEXT_MID))
        box.addView(guideCard)
        box.addView(UiKit.spacerV(this, 10))

        box.addView(UiKit.text(this, "Exercise-by-Exercise Guide (${exerciseSpecs.size})", 13f, UiKit.COL_TEXT_DARK, bold = true))
        box.addView(UiKit.spacerV(this, 6))

        exerciseSpecs.forEachIndexed { idx, (rawName, mId, presc) ->
            val cleanName = rawName.removeSuffix(" (SS)").replace(Regex("\\s+\\d+$"), "").trim()
            val libMatch = libraryMap[rawName.lowercase(Locale.US)]
                ?: libraryMap[cleanName.lowercase(Locale.US)]
                ?: libraryList.firstOrNull { it.name.contains(cleanName, ignoreCase = true) }
            val mLabel = landmarks[mId]?.shortName ?: mId

            val exBox = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = UiKit.roundedBg(UiKit.COL_SUBTLE, 10f, this@MainActivity, UiKit.COL_BORDER, 1f)
                val p = UiKit.rdp(this@MainActivity, 10)
                setPadding(p, p, p, p)
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = UiKit.rdp(this@MainActivity, 7)
                }
            }
            exBox.addView(UiKit.text(this, "${idx + 1}. $rawName", 13.5f, UiKit.COL_TEXT_DARK, bold = true))
            exBox.addView(UiKit.text(this, "Target: $mLabel · $presc", 11.5f, UiKit.COL_ACCENT, bold = true, tabular = true))
            val steps = libMatch?.instructionSteps()?.take(3) ?: listOf(
                "Brace torso and establish stable joint alignment.",
                "Lower with a controlled 2–3 second eccentric into full stretch.",
                "Drive smoothly to peak contraction while maintaining target RIR."
            )
            steps.forEach { st ->
                exBox.addView(UiKit.spacerV(this, 2))
                exBox.addView(UiKit.text(this, "• $st", 11.5f, UiKit.COL_TEXT_MID))
            }
            box.addView(exBox)
        }

        AlertDialog.Builder(this, UiKit.dialogTheme())
            .setTitle("Workout Guide · $workoutTitle")
            .setView(scroll)
            .setPositiveButton("Got It", null)
            .show()
    }

    private fun renderActivePage() {
        inlineTimerClockView = null
        inlineTimerStatusView = null
        inlineTimerPlayPauseBtn = null
        inlineGlobalClockView = null
        inlineGlobalPlayPauseBtn = null
        inlineTrackFinishBtn = null
        inlineTrackHealthBtn = null
        studioClockView = null
        breathClockView = null
        breathCueView = null
        hiitClockView = null
        activeCardioClockView = null
        if (activeTab != 3) {
            libraryCardsContainer = null
            libraryFooterWrap = null
        }

        val activeAcc = HyperLogDatabase.getActiveAccount(this)
        val accTag = if (activeAcc.uid == "guest") "Guest Vault" else activeAcc.displayName.take(14)
        val snap = db.getWidgetProgressSnapshot(activeWeek)
        val loggedToday = snap.last7Days.lastOrNull()?.second == true
        headerSubtitle.text = if (loggedToday) {
            "🔥 ${snap.streakDays}d Streak ✓ · $accTag"
        } else {
            "🔥 ${snap.streakDays}d Streak · $accTag"
        }
        if (breathTimerRunning && !(activeTab == 4 && wellnessSubTab == "wellbeing")) {
            breathTimerRunning = false
            lastBreathPhaseKey = ""
            mainHandler.removeCallbacks(breathTickRunnable)
            BreathingSoundscapeEngine.stop()
        }
        pageContent.removeAllViews()
        when (activeTab) {
            0 -> {
                val doneView = completedWorkoutState
                if (doneView != null) {
                    renderWorkoutCompletePage(doneView)
                } else {
                    renderTrackSetsPage()
                }
            }
            1 -> renderAnatomyPage()
            2 -> renderWorkoutsPage()
            3 -> renderLibraryPage()
            4 -> renderCaloriesPage()
            5 -> renderSettingsPage()
        }
        updateTimerUiLive()
        updateGlobalWorkoutUiLive()
        lastRenderedParitySignature = db.computeSetLogsParitySignature()
    }

    // =========================================================================
    // PAGE 1: ANATOMY & HYPERTROPHY LANDMARKS (ADAPTIVE ACROSS ALL PHONES)
    // =========================================================================
    private fun renderAnatomyPage() {
        val landmarks = db.getLandmarks()
        val allSets = db.getSetLogs()
        val dayExercises = db.getDayExercises()

        val completedWeekSets = allSets.filter { it.week == activeWeek && it.completed }
        val setsByMuscle = completedWeekSets
            .groupBy { it.muscleId }
            .mapValues { it.value.size }

        val freqByMuscle = dayExercises
            .groupBy { it.muscleId }
            .mapValues { (_, exs) -> exs.map { it.dayNumber }.distinct().sorted() }

        val weekCard = UiKit.card(this, padDp = 14)
        val musclesActiveCount = landmarks.values.count { (setsByMuscle[it.id] ?: 0) > 0 }
        weekCard.addView(UiKit.text(this, "Muscle Balance Map", 17.5f, UiKit.COL_TEXT_DARK, bold = true))
        weekCard.addView(UiKit.spacerV(this, 3))
        weekCard.addView(UiKit.text(
            this,
            if (musclesActiveCount == 0) "Tap any muscle below to see gentle weekly guidance — raw landmarks stay tucked away until you want them."
            else "$musclesActiveCount of ${landmarks.size} muscle groups trained this week · Tap any region to inspect.",
            12f,
            UiKit.COL_TEXT_MUTED
        ))
        pageContent.addView(weekCard)

        // Major Muscle Group Filter + Human Body Canvas Card
        val diagramCard = UiKit.card(this, padDp = 13)
        val topHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        topHeader.addView(UiKit.text(this, "Body View", 14.5f, UiKit.COL_TEXT_DARK, bold = true).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        listOf("anterior" to "Front", "posterior" to "Back", "dual" to "Both").forEachIndexed { idx, (id, lbl) ->
            topHeader.addView(UiKit.chip(this, lbl, planeMode == id) {
                planeMode = id
                userChosePlaneManually = true
                renderActivePage()
            }.apply {
                val px = UiKit.rdp(this@MainActivity, 10)
                val py = UiKit.rdp(this@MainActivity, 6)
                setPadding(px, py, px, py)
            })
            if (idx < 2) topHeader.addView(UiKit.spacerH(this, 4))
        }
        diagramCard.addView(topHeader)
        diagramCard.addView(UiKit.spacerV(this, 8))

        val (grpScroll, grpRow) = UiKit.hScrollRow(this)
        MajorMuscleGroup.entries.forEach { grp ->
            grpRow.addView(UiKit.chip(this, grp.label, activeMajorGroup == grp) {
                activeMajorGroup = grp
                if (!grp.matchesMuscle(selectedMuscleId)) {
                    val fallback = landmarks.values.firstOrNull { grp.matchesMuscle(it.id) }
                    if (fallback != null) {
                        selectedMuscleId = fallback.id
                        if (planeMode != "dual" && fallback.plane in setOf("anterior", "posterior")) {
                            planeMode = fallback.plane
                        }
                    }
                }
                renderActivePage()
            })
            grpRow.addView(UiKit.spacerH(this, 6))
        }
        diagramCard.addView(grpScroll)
        diagramCard.addView(UiKit.spacerV(this, 8))

        val bodyView = HumanBodyDiagramView(this) { tappedMuscle ->
            selectedMuscleId = tappedMuscle
            if (hapticEnabled) NativeHardwareBridge.hapticTick(this)
            renderActivePage()
        }.apply {
            this.planeMode = this@MainActivity.planeMode
            this.activeMajorGroup = this@MainActivity.activeMajorGroup
            this.selectedMuscleId = this@MainActivity.selectedMuscleId
            this.setsByMuscle = setsByMuscle
            this.landmarks = landmarks
        }
        diagramCard.addView(bodyView)
        diagramCard.addView(UiKit.spacerV(this, 8))

        // Quick-Select Region Strip
        diagramCard.addView(UiKit.text(this, "Tap a Muscle Group", 11f, UiKit.COL_TEXT_MUTED, bold = true))
        diagramCard.addView(UiKit.spacerV(this, 5))
        val (quickScroll, quickRow) = UiKit.hScrollRow(this)
        val filteredList = landmarks.values.filter { activeMajorGroup.matchesMuscle(it.id) }
        filteredList.forEach { lm ->
            val mSets = setsByMuscle[lm.id] ?: 0
            quickRow.addView(UiKit.chip(this, "${lm.shortName} ($mSets)", selectedMuscleId == lm.id) {
                selectedMuscleId = lm.id
                if (planeMode != "dual" && lm.plane in setOf("anterior", "posterior")) {
                    planeMode = lm.plane
                }
                if (hapticEnabled) NativeHardwareBridge.hapticTick(this)
                renderActivePage()
            })
            quickRow.addView(UiKit.spacerH(this, 6))
        }
        diagramCard.addView(quickScroll)
        pageContent.addView(diagramCard)

        // Selected Muscle Inspector Card (Plain English First, Landmarks Behind Disclosure)
        val selectedLm = landmarks[selectedMuscleId] ?: landmarks.values.firstOrNull()
        if (selectedLm != null) {
            val logged = setsByMuscle[selectedLm.id] ?: 0
            val zone = evaluateVolumeZone(logged, selectedLm)
            val daysHitting = freqByMuscle[selectedLm.id] ?: emptyList()
            val muscleSetRows = completedWeekSets.filter { it.muscleId == selectedLm.id }
            val avgRirStr = if (muscleSetRows.isNotEmpty()) {
                String.format(Locale.US, "%.1f left", muscleSetRows.map { it.rir }.average())
            } else "—"
            val loadVal = if (weightUnit == "lb") {
                "${(muscleSetRows.sumOf { it.weightKg * it.reps } * 2.20462).roundToInt()} lb"
            } else {
                "${muscleSetRows.sumOf { it.weightKg * it.reps }.roundToInt()} kg"
            }

            val friendlyZoneLine = when {
                logged == 0 -> "Fresh & rested · Comfortable weekly goal: ${selectedLm.mavMin}–${selectedLm.mavMax} sets"
                logged < selectedLm.mev -> "$logged sets logged · Building up toward ${selectedLm.mavMin}–${selectedLm.mavMax} sets"
                logged <= selectedLm.mavMax -> "$logged sets logged · Right in the sweet spot (${selectedLm.mavMin}–${selectedLm.mavMax} sets)"
                logged <= selectedLm.mrv -> "$logged sets logged · Strong week — prioritize sleep & recovery"
                else -> "$logged sets logged · Ready for extra rest this week"
            }

            val inspCard = UiKit.card(this, borderColor = UiKit.COL_ACCENT, borderDp = 1.4f, padDp = 14)
            val titleRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val titleLeft = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            titleLeft.addView(UiKit.text(this, selectedLm.name, 16f, UiKit.COL_TEXT_DARK, bold = true))
            titleLeft.addView(UiKit.text(
                this,
                friendlyZoneLine,
                12f,
                zone.strokeColor,
                bold = true,
                tabular = true
            ))
            titleRow.addView(titleLeft)
            titleRow.addView(UiKit.chip(
                this,
                if (showAnatomyDetailsDrawer) "Hide Landmarks ▴" else "Landmarks & Targets ▾",
                showAnatomyDetailsDrawer
            ) {
                showAnatomyDetailsDrawer = !showAnatomyDetailsDrawer
                renderActivePage()
            })
            inspCard.addView(titleRow)
            inspCard.addView(UiKit.spacerV(this, 6))
            inspCard.addView(UiKit.progressBar(this, logged.toFloat() / selectedLm.mrv.coerceAtLeast(1).toFloat(), zone.fillColor))

            if (showAnatomyDetailsDrawer) {
                inspCard.addView(UiKit.spacerV(this, 10))
                val lmHeader = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                }
                lmHeader.addView(UiKit.text(
                    this,
                    "MV ${selectedLm.mv} · MEV ${selectedLm.mev} · Sweet Spot ${selectedLm.mavMin}–${selectedLm.mavMax} · Cap ${selectedLm.mrv}",
                    11.5f,
                    UiKit.COL_TEXT_MUTED,
                    tabular = true
                ).apply {
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                })
                lmHeader.addView(UiKit.outlineButton(this, "Customize Targets") { showEditLandmarkDialog(selectedLm) })
                inspCard.addView(lmHeader)
                inspCard.addView(UiKit.spacerV(this, 8))

                val freqTargetClean = formatFreqRange(selectedLm.freqMin, selectedLm.freqMax)
                val freqDisplay = "${daysHitting.size}x (${freqTargetClean.removeSuffix("/wk")})"
                val statRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                listOf(
                    "Weekly Sessions" to freqDisplay,
                    "Avg Effort" to avgRirStr,
                    "Total Lifted" to loadVal
                ).forEachIndexed { idx, (lbl, v) ->
                    statRow.addView(UiKit.metricBox(this, lbl, v).apply {
                        layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                            if (idx < 2) rightMargin = UiKit.rdp(this@MainActivity, 5)
                        }
                    })
                }
                inspCard.addView(statRow)
                inspCard.addView(UiKit.spacerV(this, 8))
                inspCard.addView(UiKit.text(this, selectedLm.guidance, 12f, UiKit.COL_TEXT_MUTED))
            }

            if (daysHitting.isNotEmpty()) {
                inspCard.addView(UiKit.spacerV(this, 10))
                val (dScroll, dRow) = UiKit.hScrollRow(this)
                daysHitting.forEach { dNum ->
                    dRow.addView(UiKit.outlineButton(this, "Open Day $dNum Workout →", UiKit.COL_ACCENT) {
                        standaloneSession = null
                        hasSelectedScheduleDay = true
                        activeDay = dNum
                        savePrefs()
                        db.ensureDaySetRowsMaterialized(activeWeek, activeDay)
                        activeTab = 0
                        rebuildTopSettingsButton()
                        rebuildBottomNav()
                        renderActivePage()
                    })
                    dRow.addView(UiKit.spacerH(this, 8))
                }
                inspCard.addView(dScroll)
            }
            pageContent.addView(inspCard)
        }

        // Collapsible Full Muscle List (keeps Anatomy calm by default)
        val listToggleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = UiKit.rdp(this@MainActivity, 8)
            }
        }
        listToggleRow.addView(UiKit.text(this, "${activeMajorGroup.label} Muscles", 14f, UiKit.COL_TEXT_DARK, bold = true).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        listToggleRow.addView(UiKit.outlineButton(this, if (showAllAnatomyList) "Hide Muscle List ▴" else "Compare All ${filteredList.size} Muscles ▾", UiKit.COL_ACCENT) {
            showAllAnatomyList = !showAllAnatomyList
            renderActivePage()
        })
        pageContent.addView(listToggleRow)

        if (showAllAnatomyList) {
            filteredList.forEach { lm ->
                val logged = setsByMuscle[lm.id] ?: 0
                val zone = evaluateVolumeZone(logged, lm)
                val freq = freqByMuscle[lm.id]?.size ?: 0
                val freqTarget = formatFreqRange(lm.freqMin, lm.freqMax)
                val isSel = lm.id == selectedMuscleId

                val mCard = UiKit.card(this, borderColor = if (isSel) UiKit.COL_ACCENT else UiKit.COL_BORDER, borderDp = if (isSel) 1.5f else 1f, padDp = 12)
                mCard.setOnClickListener {
                    selectedMuscleId = lm.id
                    renderActivePage()
                }
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                row.addView(UiKit.text(this, lm.name, 14f, UiKit.COL_TEXT_DARK, bold = true).apply {
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                })
                row.addView(UiKit.text(this, "$logged/${lm.mavMin}–${lm.mavMax} · ${zone.shortLabel}", 11.5f, zone.strokeColor, bold = true, tabular = true))
                mCard.addView(row)
                mCard.addView(UiKit.progressBar(this, logged.toFloat() / lm.mrv.coerceAtLeast(1).toFloat(), zone.fillColor))

                val metaBottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                metaBottom.addView(UiKit.text(this, "MV ${lm.mv} · MEV ${lm.mev} · MAV ${lm.mavMin}–${lm.mavMax} · MRV ${lm.mrv}", 11f, UiKit.COL_TEXT_MUTED, tabular = true).apply {
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                })
                metaBottom.addView(UiKit.text(this, "Freq ${freq}x ($freqTarget)", 11f, UiKit.COL_TEXT_MID, bold = true, tabular = true))
                mCard.addView(metaBottom)
                pageContent.addView(mCard)
            }
        }
    }

    private fun showEditLandmarkDialog(lm: MuscleLandmark) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = UiKit.dp(this@MainActivity, 16)
            setPadding(p, p, p, p)
        }
        val mvIn = UiKit.inputBox(this, lm.mv.toString(), "MV", InputType.TYPE_CLASS_NUMBER)
        val mevIn = UiKit.inputBox(this, lm.mev.toString(), "MEV", InputType.TYPE_CLASS_NUMBER)
        val mavMinIn = UiKit.inputBox(this, lm.mavMin.toString(), "MAV Min", InputType.TYPE_CLASS_NUMBER)
        val mavMaxIn = UiKit.inputBox(this, lm.mavMax.toString(), "MAV Max", InputType.TYPE_CLASS_NUMBER)
        val mrvIn = UiKit.inputBox(this, lm.mrv.toString(), "MRV", InputType.TYPE_CLASS_NUMBER)

        listOf("MV (Maintenance)" to mvIn, "MEV (Minimum Effective)" to mevIn, "MAV Min" to mavMinIn, "MAV Max" to mavMaxIn, "MRV (Max Recoverable)" to mrvIn).forEach { (lbl, ed) ->
            box.addView(UiKit.text(this, lbl, 11f, UiKit.COL_TEXT_MUTED, bold = true))
            box.addView(ed)
            box.addView(UiKit.spacerV(this, 6))
        }

        AlertDialog.Builder(this, UiKit.dialogTheme())
            .setTitle("Tune ${lm.shortName} Landmarks")
            .setView(box)
            .setPositiveButton("Save") { _, _ ->
                db.saveLandmark(lm.copy(
                    mv = mvIn.text.toString().toIntOrNull() ?: lm.mv,
                    mev = mevIn.text.toString().toIntOrNull() ?: lm.mev,
                    mavMin = mavMinIn.text.toString().toIntOrNull() ?: lm.mavMin,
                    mavMax = mavMaxIn.text.toString().toIntOrNull() ?: lm.mavMax,
                    mrv = mrvIn.text.toString().toIntOrNull() ?: lm.mrv
                ))
                showBanner("Updated volume landmarks for ${lm.shortName}")
                renderActivePage()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // =========================================================================
    // PAGE 1 (TAB 0): CUSTOM-EXERCISE-FIRST HOMEPAGE + CONSOLIDATED DROPDOWNS
    // =========================================================================
    private fun startSingleCustomExerciseWorkout(ex: LibraryExercise) {
        val baseSession = db.startQuickEmptySession(ex.name)
        standaloneSession = db.appendExerciseToStandaloneSession(baseSession, ex, activeWeek)
        hasSelectedScheduleDay = false
        startOrEnsureGlobalWorkoutTimer(ex.name, playTone = true)
        savePrefs()
        mainScroll.scrollTo(0, 0)
        renderActivePage()
    }

    private fun renderTrackerWorkoutLaunchpad() {
        val templates = db.getTemplates()
        val days = db.getWorkoutDays()
        val dayExercises = db.getDayExercises()
        val landmarks = db.getLandmarks()
        val allLibForCustom = if (loginHydratedFirst10Only) cachedFirst10Library else db.getLibraryExercisesPrioritized(limit = 60, offset = 0)
        val customExercises = allLibForCustom.filter { it.isCustom }
        val customTemplates = templates.filter { it.category.equals("Custom", ignoreCase = true) }
        val activeAcc = HyperLogDatabase.getActiveAccount(this)

        val todayIso = LocalDate.now().toString()
        val allLogs = db.getSetLogs()
        val activeDayPlan = days.find { it.dayNumber == activeDay } ?: days.firstOrNull { !it.isRestDay }
        val plannedDayNum = activeDayPlan?.dayNumber ?: activeDay
        val plannedExercises = dayExercises.filter { it.dayNumber == plannedDayNum }
        val todayCompletedSets = allLogs.filter { it.completed && it.completedDateIso == todayIso }
        val weekCompletedSets = allLogs.filter { it.week == activeWeek && it.completed }
        val targetSetsToday = plannedExercises.sumOf { it.setsForWeek(activeWeek).coerceAtLeast(1) }.coerceAtLeast(12)
        val completionPct = ((todayCompletedSets.size.toFloat() / targetSetsToday.toFloat()) * 100f).roundToInt().coerceIn(0, 100)
        val snap = db.getWidgetProgressSnapshot(activeWeek)

        val hourOfDay = java.time.LocalTime.now().hour
        val greeting = when {
            hourOfDay < 12 -> "Good morning"
            hourOfDay < 17 -> "Good afternoon"
            else -> "Good evening"
        }
        val firstName = activeAcc.displayName.trim().substringBefore(" ").ifBlank { "Friend" }

        // 1. Warm Greeting Header + Account Vault Switcher
        val greetCard = UiKit.card(this, padDp = 15)
        val greetTop = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val greetLeft = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        greetLeft.addView(UiKit.text(this, "$greeting, $firstName", 20f, UiKit.COL_TEXT_DARK, bold = true))
        greetLeft.addView(UiKit.text(
            this,
            "Move at a steady, comfortable pace today — everything else stays tucked away until you want it.",
            12f,
            UiKit.COL_TEXT_MUTED
        ))
        greetTop.addView(greetLeft)
        greetTop.addView(UiKit.spacerH(this, 6))
        greetTop.addView(UiKit.chip(this, "${activeAcc.displayName.take(12)} ▾", activeAcc.uid != "guest") {
            showAccountVaultDialog()
        })
        greetCard.addView(greetTop)
        pageContent.addView(greetCard)

        // 2. Single Calm Daily Workout Completion Card (Progressive Disclosure)
        val progCard = UiKit.card(this, borderColor = UiKit.COL_ACCENT, borderDp = 1.4f, padDp = 16)
        val statusHeadline = when {
            completionPct >= 100 -> "Today's workout is complete — nice work."
            todayCompletedSets.isNotEmpty() -> "${todayCompletedSets.size} sets logged so far — pick up right where you left off."
            activeDayPlan?.isRestDay == true -> "Rest & recovery day — take it easy or start a light session."
            else -> activeDayPlan?.title ?: "Ready when you are for Day $plannedDayNum"
        }

        val pctRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val pctLeft = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        pctLeft.addView(UiKit.text(this, "Today's Workout Progress", 12f, UiKit.COL_ACCENT, bold = true))
        pctLeft.addView(UiKit.spacerV(this, 2))
        pctLeft.addView(UiKit.text(this, statusHeadline, 15.5f, UiKit.COL_TEXT_DARK, bold = true))
        pctLeft.addView(UiKit.spacerV(this, 2))
        pctLeft.addView(UiKit.text(
            this,
            if (plannedExercises.isNotEmpty()) "${plannedExercises.size} movements planned · ${todayCompletedSets.size} of $targetSetsToday sets logged"
            else "${todayCompletedSets.size} sets logged today",
            11.5f,
            UiKit.COL_TEXT_MUTED,
            tabular = true
        ))
        pctRow.addView(pctLeft)
        pctRow.addView(UiKit.spacerH(this, 10))
        pctRow.addView(UiKit.text(
            this,
            "$completionPct%",
            28f,
            if (completionPct >= 100) 0xFF059669.toInt() else UiKit.COL_ACCENT,
            bold = true,
            tabular = true
        ))
        progCard.addView(pctRow)
        progCard.addView(UiKit.spacerV(this, 10))
        progCard.addView(UiKit.progressBar(
            this,
            completionPct / 100f,
            if (completionPct >= 100) 0xFF10B981.toInt() else UiKit.COL_ACCENT
        ))
        progCard.addView(UiKit.spacerV(this, 12))

        val primaryBtnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val startLabel = if (todayCompletedSets.isNotEmpty()) "Continue Workout →" else "Start Today's Workout →"
        primaryBtnRow.addView(UiKit.primaryButton(this, startLabel, UiKit.COL_ACCENT) {
            standaloneSession = null
            hasSelectedScheduleDay = true
            activeDay = plannedDayNum
            savePrefs()
            db.ensureDaySetRowsMaterialized(activeWeek, activeDay)
            startOrEnsureGlobalWorkoutTimer(activeDayPlan?.title ?: "Day $activeDay Workout", playTone = true)
            mainScroll.scrollTo(0, 0)
            renderActivePage()
        }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.35f).apply {
                rightMargin = UiKit.rdp(this@MainActivity, 6)
            }
        })
        primaryBtnRow.addView(UiKit.outlineButton(
            this,
            if (showTrackerCustomComposer) "Hide Custom ▴" else "Custom Session ▾",
            UiKit.COL_ACCENT
        ) {
            showTrackerCustomComposer = !showTrackerCustomComposer
            renderActivePage()
        }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.9f)
        })
        progCard.addView(primaryBtnRow)
        pageContent.addView(progCard)

        // 3. Optional Custom Exercise & Open Session Drawer (Collapsed by Default)
        if (showTrackerCustomComposer) {
            val customHub = UiKit.card(this, padDp = 14)
            customHub.addView(UiKit.text(this, "Custom Exercise & Open Workout", 15f, UiKit.COL_TEXT_DARK, bold = true))
            customHub.addView(UiKit.text(
                this,
                "Start an open session from scratch or add your own exercise to the library.",
                11.5f,
                UiKit.COL_TEXT_MUTED
            ))
            customHub.addView(UiKit.spacerV(this, 10))

            val customActionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            customActionRow.addView(UiKit.primaryButton(this, "+ Start Open Workout", UiKit.COL_ACCENT) {
                standaloneSession = db.startQuickEmptySession("Custom Workout")
                hasSelectedScheduleDay = false
                startOrEnsureGlobalWorkoutTimer("Custom Workout", playTone = true)
                savePrefs()
                renderActivePage()
            }.apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.3f).apply {
                    rightMargin = UiKit.rdp(this@MainActivity, 6)
                }
            })
            customActionRow.addView(UiKit.outlineButton(this, "+ Routine", UiKit.COL_ACCENT) {
                showTemplateStudioDialog(
                    WorkoutTemplate(
                        id = "tpl_custom_${System.currentTimeMillis()}",
                        name = "My Custom Routine",
                        category = "Custom",
                        splitType = "Custom Split",
                        description = "User-designed custom hypertrophy routine",
                        exercisesJson = "[]",
                        updatedAtEpochMs = System.currentTimeMillis()
                    )
                )
            }.apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.7f)
            })
            customHub.addView(customActionRow)
            customHub.addView(UiKit.spacerV(this, 10))

            val composerBox = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = UiKit.roundedBg(UiKit.COL_SUBTLE, 11f, this@MainActivity, UiKit.COL_BORDER, 1f)
                val p = UiKit.rdp(this@MainActivity, 11)
                setPadding(p, p, p, p)
            }
            composerBox.addView(UiKit.text(this, "Create Custom Movement", 13f, UiKit.COL_TEXT_DARK, bold = true))
            composerBox.addView(UiKit.spacerV(this, 6))

            val exNameEd = UiKit.inputBox(this, inlineCustomExName, "Movement name (e.g. Cable Wrist Curl)", InputType.TYPE_CLASS_TEXT)
            exNameEd.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) { inlineCustomExName = s?.toString() ?: "" }
            })
            composerBox.addView(exNameEd)
            composerBox.addView(UiKit.spacerV(this, 6))

            val (mScroll, mRow) = UiKit.hScrollRow(this)
            listOf(
                "chest" to "Chest", "back" to "Back", "front_delts" to "Front Delts",
                "rear_side_delts" to "Side/Rear Delts", "biceps" to "Biceps", "triceps" to "Triceps",
                "forearms" to "Forearms", "quads" to "Quads", "hamstrings" to "Hamstrings",
                "glutes" to "Glutes", "calves" to "Calves", "abs" to "Core"
            ).forEach { (mId, mLbl) ->
                mRow.addView(UiKit.chip(this, mLbl, inlineCustomExMuscle == mId) {
                    inlineCustomExMuscle = mId
                    renderActivePage()
                })
                mRow.addView(UiKit.spacerH(this, 5))
            }
            composerBox.addView(mScroll)
            composerBox.addView(UiKit.spacerV(this, 6))

            val (eqScroll, eqRow) = UiKit.hScrollRow(this)
            listOf("Dumbbell", "Barbell", "Cable", "Machine", "Bodyweight", "Kettlebells", "Bands", "Cardio").forEach { eq ->
                eqRow.addView(UiKit.chip(this, eq, inlineCustomExEquip == eq) {
                    inlineCustomExEquip = eq
                    renderActivePage()
                })
                eqRow.addView(UiKit.spacerH(this, 5))
            }
            composerBox.addView(eqScroll)
            composerBox.addView(UiKit.spacerV(this, 8))

            fun buildAndSaveInlineCustomExercise(): LibraryExercise? {
                val cleanName = exNameEd.text.toString().trim()
                if (cleanName.length < 2) {
                    showBanner("Enter a movement name (2+ characters) first.")
                    return null
                }
                val grp = MajorMuscleGroup.entries.firstOrNull {
                    it != MajorMuscleGroup.ALL && it.matchesMuscle(inlineCustomExMuscle)
                }?.name ?: "CHEST"
                val created = LibraryExercise(
                    id = "lib_custom_${System.currentTimeMillis()}",
                    name = cleanName,
                    majorGroup = grp,
                    primaryMuscle = inlineCustomExMuscle,
                    secondaryMusclesCsv = "",
                    equipment = inlineCustomExEquip,
                    description = "Custom exercise targeting ${landmarks[inlineCustomExMuscle]?.name ?: inlineCustomExMuscle}.",
                    instructionsText = "Brace torso and set stable joint alignment.\nControl a 2–3 second eccentric stretch.\nDrive smoothly to full contraction.",
                    defaultRepRange = inlineCustomExReps.ifBlank { "8–12" },
                    defaultRestSeconds = customRestDurationSec,
                    defaultWeightKg = 20.0,
                    videoUrl = ""
                )
                db.saveLibraryExercise(created)
                cachedFirst10Library = db.getLibraryExercisesPrioritized(limit = 10, offset = 0)
                cachedTotalLibraryCount = db.getTotalLibraryExerciseCount()
                HyperLogStorageManager.saveDatabaseSnapshotAsync(this, db)
                inlineCustomExName = ""
                if (hapticEnabled) NativeHardwareBridge.hapticTick(this)
                return created
            }

            val saveBtnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            saveBtnRow.addView(UiKit.outlineButton(this, "+ Save Movement", UiKit.COL_ACCENT) {
                val saved = buildAndSaveInlineCustomExercise() ?: return@outlineButton
                showBanner("Saved '${saved.name}' to your Library")
                renderActivePage()
            }.apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.95f).apply {
                    rightMargin = UiKit.rdp(this@MainActivity, 6)
                }
            })
            saveBtnRow.addView(UiKit.primaryButton(this, "Save & Start →", UiKit.COL_ACCENT) {
                val saved = buildAndSaveInlineCustomExercise() ?: return@primaryButton
                startSingleCustomExerciseWorkout(saved)
            }.apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.15f)
            })
            composerBox.addView(saveBtnRow)
            customHub.addView(composerBox)

            if (customExercises.isNotEmpty() || customTemplates.isNotEmpty()) {
                customHub.addView(UiKit.spacerV(this, 8))
                customExercises.take(5).forEach { ex ->
                    val mLbl = landmarks[ex.primaryMuscle]?.shortName ?: ex.primaryMuscle
                    val row = LinearLayout(this).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        background = UiKit.roundedBg(UiKit.COL_SUBTLE, 10f, this@MainActivity, UiKit.COL_BORDER, 1f)
                        val p = UiKit.rdp(this@MainActivity, 9)
                        setPadding(p, p, p, p)
                        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                            bottomMargin = UiKit.rdp(this@MainActivity, 5)
                        }
                        setOnClickListener { startSingleCustomExerciseWorkout(ex) }
                    }
                    val info = LinearLayout(this).apply {
                        orientation = LinearLayout.VERTICAL
                        layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    }
                    info.addView(UiKit.text(this, ex.name, 13f, UiKit.COL_TEXT_DARK, bold = true))
                    info.addView(UiKit.text(this, "$mLbl · ${ex.equipment}", 11f, UiKit.COL_TEXT_MUTED))
                    row.addView(info)
                    row.addView(UiKit.text(this, "Start →", 12f, UiKit.COL_ACCENT, bold = true))
                    customHub.addView(row)
                }
            }
            pageContent.addView(customHub)
        }

        // 4. Progressive Disclosure Toggle: "View Deep Analytics" (Secondary Metrics Collapsed by Default)
        val analyticsCard = UiKit.card(
            this,
            borderColor = if (showTrackerDeepAnalytics) UiKit.COL_ACCENT else UiKit.COL_BORDER,
            borderDp = if (showTrackerDeepAnalytics) 1.3f else 1f,
            padDp = 14
        )
        val analyticsHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            minimumHeight = UiKit.dp(this@MainActivity, 44)
            setOnClickListener {
                showTrackerDeepAnalytics = !showTrackerDeepAnalytics
                if (hapticEnabled) NativeHardwareBridge.hapticTick(this@MainActivity)
                renderActivePage()
            }
        }
        val analyticsTitleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        analyticsTitleCol.addView(UiKit.text(
            this,
            if (showTrackerDeepAnalytics) "Hide Deep Analytics" else "View Deep Analytics",
            14f,
            UiKit.COL_TEXT_DARK,
            bold = true
        ))
        analyticsTitleCol.addView(UiKit.text(
            this,
            "Active calories, effort zone, sets lifted & 7-day consistency",
            11.5f,
            UiKit.COL_TEXT_MUTED
        ))
        analyticsHeader.addView(analyticsTitleCol)
        analyticsHeader.addView(UiKit.text(
            this,
            if (showTrackerDeepAnalytics) "▴" else "▾",
            14f,
            UiKit.COL_ACCENT,
            bold = true
        ))
        analyticsCard.addView(analyticsHeader)

        if (showTrackerDeepAnalytics) {
            analyticsCard.addView(UiKit.spacerV(this, 10))
            val estActiveKcal = (todayCompletedSets.size * 18).coerceAtLeast(if (todayCompletedSets.isNotEmpty()) 45 else 0)
            val estHeartBpm = if (todayCompletedSets.isEmpty()) 68 else (108 + (todayCompletedSets.size * 3).coerceAtMost(34))
            val kpiRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            listOf(
                "Active Energy" to "$estActiveKcal kcal",
                "Est. Heart Rate" to "$estHeartBpm bpm",
                "Sets Lifted" to "${todayCompletedSets.size} today · ${weekCompletedSets.size} wk"
            ).forEachIndexed { idx, (lbl, v) ->
                kpiRow.addView(UiKit.metricBox(this, lbl, v).apply {
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                        if (idx < 2) rightMargin = UiKit.rdp(this@MainActivity, 5)
                    }
                })
            }
            analyticsCard.addView(kpiRow)
            analyticsCard.addView(UiKit.spacerV(this, 8))
            analyticsCard.addView(UiKit.text(
                this,
                "Consistency streak: ${snap.streakDays} day(s) · Switch to Workouts or Anatomy anytime for full schedules and muscle maps.",
                11.5f,
                UiKit.COL_TEXT_MUTED
            ))
        }
        pageContent.addView(analyticsCard)
    }

    private fun renderTrackSetsPage() {
        val currentStandalone = standaloneSession
        if (currentStandalone == null && !hasSelectedScheduleDay) {
            renderTrackerWorkoutLaunchpad()
            return
        }

        val landmarks = db.getLandmarks()
        val days = db.getWorkoutDays()
        val allSets = db.getSetLogs()
        val feedbackMap = db.getFeedbackMap()

        data class TrackBlock(val exId: String, val name: String, val muscleId: String, val repRange: String, val restSec: Int, val defaultW: Double, val sets: List<SetLog>)

        val blocks: List<TrackBlock> = if (currentStandalone != null) {
            currentStandalone.exercises.map { item ->
                val rows = allSets.filter { it.templateSessionId == currentStandalone.sessionId && it.exerciseId == item.id }.sortedBy { it.setIndex }
                TrackBlock(item.id, item.name, item.primaryMuscle, item.reps, item.restSeconds, item.defaultWeightKg, rows)
            }
        } else {
            db.getDayExercises().filter { it.dayNumber == activeDay }.map { ex ->
                val rows = allSets.filter { it.templateSessionId == null && it.week == activeWeek && it.dayNumber == activeDay && it.exerciseId == ex.id }.sortedBy { it.setIndex }
                TrackBlock(ex.id, if (ex.isSuperset) "${ex.name} (SS)" else ex.name, ex.muscleId, ex.repRange, ex.restSeconds, ex.defaultWeightKg, rows)
            }
        }

        val sessionDoneCount = blocks.sumOf { b -> b.sets.count { it.completed } }
        val sessionTotalCount = blocks.sumOf { b -> b.sets.size }

        // Unified Clean Session & Rest Timer Header Card
        val sessionCard = UiKit.card(
            this,
            borderColor = if (restTimerFinishedAlert) 0xFF10B981.toInt() else if (restTimerRunning) UiKit.COL_ACCENT else UiKit.COL_BORDER,
            borderDp = if (restTimerRunning || restTimerFinishedAlert) 1.5f else 1f,
            padDp = 13
        )

        val activeSessionTitle = currentStandalone?.templateName
            ?: days.find { it.dayNumber == activeDay }?.title
            ?: "Day $activeDay Workout"

        if (currentStandalone != null) {
            val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val left = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            val modeTag = if (currentStandalone.templateId == "quick_custom") "Custom Workout"
            else if (currentStandalone.templateId == "repeat_history") "Repeated Session"
            else "Template Workout"
            left.addView(UiKit.text(this, "$modeTag · $sessionDoneCount/$sessionTotalCount sets", 11.5f, UiKit.COL_ACCENT, bold = true, tabular = true))
            left.addView(UiKit.text(this, currentStandalone.templateName, 16f, UiKit.COL_TEXT_DARK, bold = true))
            top.addView(left)
            top.addView(UiKit.chip(this, "? Help", false) {
                showWorkoutHelpDialog(
                    currentStandalone.templateName,
                    "$modeTag · ${blocks.size} exercises",
                    blocks.map { Triple(it.name, it.muscleId, "${it.sets.size} sets × ${it.repRange} (${it.restSec}s rest)") }
                )
            })
            top.addView(UiKit.spacerH(this, 4))
            top.addView(UiKit.chip(this, "Switch", false) {
                showWorkoutSwitcherDialog()
            })
            top.addView(UiKit.spacerH(this, 4))
            top.addView(UiKit.outlineButton(this, "All Workouts") {
                standaloneSession = null
                hasSelectedScheduleDay = false
                savePrefs()
                renderActivePage()
            })
            sessionCard.addView(top)
        } else {
            val activeDayEnt = days.find { it.dayNumber == activeDay }
            val headRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val headLeft = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            headLeft.addView(UiKit.text(this, activeDayEnt?.title ?: "Day $activeDay Workout", 16f, UiKit.COL_TEXT_DARK, bold = true))
            val subSummary = if (activeDayEnt?.isRestDay == true) "Scheduled recovery day · Tap All Workouts to pick any session"
            else "$sessionDoneCount/$sessionTotalCount sets done · ${activeDayEnt?.focusSummary ?: ""}"
            headLeft.addView(UiKit.text(this, subSummary, 11.5f, UiKit.COL_TEXT_MUTED, tabular = true).apply {
                maxLines = 1
            })
            headRow.addView(headLeft)
            headRow.addView(UiKit.spacerH(this, 4))
            if (blocks.isNotEmpty()) {
                headRow.addView(UiKit.chip(this, "? Help", false) {
                    showWorkoutHelpDialog(
                        activeDayEnt?.title ?: "Day $activeDay Workout",
                        activeDayEnt?.focusSummary ?: "${blocks.size} exercises",
                        blocks.map { Triple(it.name, it.muscleId, "${it.sets.size} sets × ${it.repRange} (${it.restSec}s rest)") }
                    )
                })
                headRow.addView(UiKit.spacerH(this, 4))
            }
            headRow.addView(UiKit.chip(this, if (showActiveDayStrip) "Days ▴" else "Switch Day ▾", showActiveDayStrip) {
                showActiveDayStrip = !showActiveDayStrip
                renderActivePage()
            })
            headRow.addView(UiKit.spacerH(this, 4))
            headRow.addView(UiKit.outlineButton(this, "Overview") {
                standaloneSession = null
                hasSelectedScheduleDay = false
                savePrefs()
                renderActivePage()
            })
            sessionCard.addView(headRow)

            if (showActiveDayStrip) {
                sessionCard.addView(UiKit.spacerV(this, 9))
                val (dayScroll, dayRow) = UiKit.hScrollRow(this)
                (1..7).forEach { d ->
                    val isRest = days.find { it.dayNumber == d }?.isRestDay == true
                    dayRow.addView(UiKit.chip(this, if (isRest) "D$d Rest" else "Day $d", activeDay == d) {
                        standaloneSession = null
                        hasSelectedScheduleDay = true
                        activeDay = d
                        savePrefs()
                        db.ensureDaySetRowsMaterialized(activeWeek, activeDay)
                        renderActivePage()
                    })
                    dayRow.addView(UiKit.spacerH(this, 6))
                }
                dayRow.addView(UiKit.chip(this, "Routine Picker", false) {
                    showWorkoutSwitcherDialog()
                })
                dayRow.addView(UiKit.spacerH(this, 6))
                dayRow.addView(UiKit.chip(this, "Calendar", false) {
                    calendarSelectedDateIso = LocalDate.now().toString()
                    calendarYear = LocalDate.now().year
                    calendarMonth = LocalDate.now().monthValue
                    workoutsSubTab = "calendar"
                    activeTab = 2
                    rebuildTopSettingsButton()
                    rebuildBottomNav()
                    renderActivePage()
                })
                sessionCard.addView(dayScroll)
            }
        }

        // Global Workout Elapsed Timer Strip + Sleek 1-Row Inline Rest Timer Bar
        if (blocks.isNotEmpty()) {
            sessionCard.addView(UiKit.spacerV(this, 8))

            val globalStrip = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = UiKit.roundedBg(
                    if (globalWorkoutActive && !globalWorkoutPaused) UiKit.COL_ROW_COMPLETED else UiKit.COL_SUBTLE,
                    10f,
                    this@MainActivity,
                    if (globalWorkoutActive) 0xFF10B981.toInt() else UiKit.COL_BORDER,
                    1f
                )
                val px = UiKit.rdp(this@MainActivity, 10)
                val py = UiKit.rdp(this@MainActivity, 6)
                setPadding(px, py, px, py)
            }
            globalStrip.addView(UiKit.text(this, "Workout Session", 11.5f, UiKit.COL_TEXT_MID, bold = true).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            val gClockTv = UiKit.text(this, "⏱ ${formatClock(currentGlobalElapsedSec())}", 14f, 0xFF059669.toInt(), bold = true, tabular = true)
            inlineGlobalClockView = gClockTv
            globalStrip.addView(gClockTv)
            globalStrip.addView(UiKit.spacerH(this, 8))
            val gToggleBtn = UiKit.chip(this, if (!globalWorkoutActive) "Start Timer" else if (globalWorkoutPaused) "Resume" else "Pause", globalWorkoutActive && !globalWorkoutPaused) {
                togglePauseGlobalWorkoutTimer(activeSessionTitle)
                renderActivePage()
            }.apply {
                minHeight = UiKit.dp(this@MainActivity, 34)
                val px = UiKit.rdp(this@MainActivity, 10)
                val py = UiKit.rdp(this@MainActivity, 5)
                setPadding(px, py, px, py)
            }
            inlineGlobalPlayPauseBtn = gToggleBtn
            globalStrip.addView(gToggleBtn)
            if (globalWorkoutActive) {
                globalStrip.addView(UiKit.spacerH(this, 4))
                globalStrip.addView(UiKit.outlineButton(this, "End") {
                    stopAndResetGlobalWorkoutTimer()
                    renderActivePage()
                }.apply {
                    minHeight = UiKit.dp(this@MainActivity, 34)
                    val px = UiKit.rdp(this@MainActivity, 8)
                    val py = UiKit.rdp(this@MainActivity, 5)
                    setPadding(px, py, px, py)
                })
            }
            sessionCard.addView(globalStrip)

            sessionCard.addView(UiKit.spacerV(this, 6))
            val timerStrip = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = UiKit.roundedBg(UiKit.COL_SUBTLE, 10f, this@MainActivity, UiKit.COL_BORDER, 1f)
                val px = UiKit.rdp(this@MainActivity, 10)
                val py = UiKit.rdp(this@MainActivity, 7)
                setPadding(px, py, px, py)
            }
            val statusTv = UiKit.text(this, "Rest Timer", 11.5f, UiKit.COL_TEXT_MID, bold = true).apply {
                isSingleLine = true
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            val clockTv = UiKit.text(this, formatClock(customRestDurationSec), 16f, UiKit.COL_TEXT_DARK, bold = true, tabular = true)
            inlineTimerStatusView = statusTv
            inlineTimerClockView = clockTv

            timerStrip.addView(statusTv)
            timerStrip.addView(clockTv)
            timerStrip.addView(UiKit.spacerH(this, 8))

            val playPauseBtn = UiKit.primaryButton(this, "Start", UiKit.COL_ACCENT) {
                togglePauseResumeRestTimer()
            }.apply {
                val px = UiKit.rdp(this@MainActivity, 12)
                val py = UiKit.rdp(this@MainActivity, 6)
                setPadding(px, py, px, py)
                minHeight = UiKit.dp(this@MainActivity, 36)
            }
            inlineTimerPlayPauseBtn = playPauseBtn
            timerStrip.addView(playPauseBtn)

            if (restTimerRunning || restSecondsRemaining > 0) {
                timerStrip.addView(UiKit.spacerH(this, 5))
                timerStrip.addView(UiKit.outlineButton(this, "Reset") {
                    stopRestTimer()
                    renderActivePage()
                }.apply {
                    val px = UiKit.rdp(this@MainActivity, 9)
                    val py = UiKit.rdp(this@MainActivity, 6)
                    setPadding(px, py, px, py)
                    minHeight = UiKit.dp(this@MainActivity, 36)
                })
            }

            timerStrip.addView(UiKit.spacerH(this, 5))
            timerStrip.addView(UiKit.outlineButton(this, if (showTrackOptionsDrawer) "Hide" else "Options") {
                showTrackOptionsDrawer = !showTrackOptionsDrawer
                renderActivePage()
            }.apply {
                val px = UiKit.rdp(this@MainActivity, 9)
                val py = UiKit.rdp(this@MainActivity, 6)
                setPadding(px, py, px, py)
                minHeight = UiKit.dp(this@MainActivity, 36)
            })
            sessionCard.addView(timerStrip)
        }

        // Progressive-Disclosure Options Drawer (Units, Timer Presets, Audio Tone, RIR Color Key)
        if (showTrackOptionsDrawer) {
            sessionCard.addView(UiKit.spacerV(this, 10))
            val unitOptRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            unitOptRow.addView(UiKit.text(this, "Load Unit", 11f, UiKit.COL_TEXT_MUTED, bold = true).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            listOf("kg", "lb").forEachIndexed { idx, u ->
                unitOptRow.addView(UiKit.chip(this, u.uppercase(), weightUnit == u) {
                    weightUnit = u
                    savePrefs()
                    renderActivePage()
                })
                if (idx == 0) unitOptRow.addView(UiKit.spacerH(this, 6))
            }
            sessionCard.addView(unitOptRow)
            sessionCard.addView(UiKit.spacerV(this, 8))

            sessionCard.addView(UiKit.text(this, "Rest Timer Presets & Audio Tone", 11f, UiKit.COL_TEXT_MUTED, bold = true))
            sessionCard.addView(UiKit.spacerV(this, 4))
            val (presetScroll, presetRow) = UiKit.hScrollRow(this)
            presetRow.addView(UiKit.chip(this, "-15s", false) { adjustRestTimer(-15) })
            presetRow.addView(UiKit.spacerH(this, 5))
            listOf(60, 90, 120, 180).forEach { sec ->
                presetRow.addView(UiKit.chip(this, "${sec}s", customRestDurationSec == sec && !restTimerRunning) {
                    setPresetRestSeconds(sec)
                })
                presetRow.addView(UiKit.spacerH(this, 5))
            }
            presetRow.addView(UiKit.chip(this, "+15s", false) { adjustRestTimer(15) })
            presetRow.addView(UiKit.spacerH(this, 5))
            presetRow.addView(UiKit.outlineButton(this, "Custom (${customRestDurationSec}s)", UiKit.COL_ACCENT) {
                showCustomRestSecondsDialog()
            })
            sessionCard.addView(presetScroll)
            sessionCard.addView(UiKit.spacerV(this, 6))

            val toneRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val toneCb = CheckBox(this).apply {
                isChecked = soundOnTimer
                text = "Tone when timers are set & finished"
                textSize = UiKit.rsp(this@MainActivity, 11.5f)
                setTextColor(UiKit.COL_TEXT_DARK)
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setOnCheckedChangeListener { _, checked ->
                    soundOnTimer = checked
                    savePrefs()
                    if (checked) NativeHardwareBridge.playTimerSetTone(this@MainActivity, true)
                }
            }
            toneRow.addView(toneCb)
            toneRow.addView(UiKit.chip(this, "Test Tone", false) {
                NativeHardwareBridge.playTimerSetTone(this, true)
            })
            sessionCard.addView(toneRow)
            sessionCard.addView(UiKit.spacerV(this, 8))

            val rpeToggleCb = CheckBox(this).apply {
                isChecked = showOptionalRpeCol
                text = "Show optional RPE column next to Effort"
                textSize = UiKit.rsp(this@MainActivity, 11.5f)
                setTextColor(UiKit.COL_TEXT_DARK)
                setOnCheckedChangeListener { _, checked ->
                    showOptionalRpeCol = checked
                    renderActivePage()
                }
            }
            sessionCard.addView(rpeToggleCb)
            sessionCard.addView(UiKit.spacerV(this, 6))

            val greenPal = UiKit.rirPalette(2.0)
            val yellowPal = UiKit.rirPalette(0.0)
            val (legScroll, legRow) = UiKit.hScrollRow(this)
            legRow.addView(UiKit.text(this, "Effort Guide: ", 11f, UiKit.COL_TEXT_MUTED, bold = true))
            legRow.addView(UiKit.text(this, " 1–3 left (Sweet Spot) ", 10.5f, greenPal.textColor, bold = true).apply {
                background = UiKit.roundedBg(greenPal.bgColor, 6f, this@MainActivity, greenPal.borderColor, 1f)
                val px = UiKit.rdp(this@MainActivity, 6); val py = UiKit.rdp(this@MainActivity, 2)
                setPadding(px, py, px, py)
            })
            legRow.addView(UiKit.spacerH(this, 6))
            legRow.addView(UiKit.text(this, " 0 left (Max Effort) ", 10.5f, yellowPal.textColor, bold = true).apply {
                background = UiKit.roundedBg(yellowPal.bgColor, 6f, this@MainActivity, yellowPal.borderColor, 1f)
                val px = UiKit.rdp(this@MainActivity, 6); val py = UiKit.rdp(this@MainActivity, 2)
                setPadding(px, py, px, py)
            })
            legRow.addView(UiKit.spacerH(this, 6))
            legRow.addView(UiKit.text(this, "4+ Easy Warm-Up", 10.5f, UiKit.COL_TEXT_MUTED))
            sessionCard.addView(legScroll)
        }

        pageContent.addView(sessionCard)

        if (blocks.isEmpty()) {
            val restCard = UiKit.card(this)
            if (currentStandalone != null) {
                restCard.addView(UiKit.text(this, currentStandalone.templateName, 15.5f, UiKit.COL_TEXT_DARK, bold = true))
                restCard.addView(UiKit.spacerV(this, 4))
                restCard.addView(UiKit.text(this, "Empty custom session ready. Add your first exercise to start logging sets immediately.", 12f, UiKit.COL_TEXT_MUTED))
                restCard.addView(UiKit.spacerV(this, 10))
                val actRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                actRow.addView(UiKit.primaryButton(this, "+ Add First Exercise", UiKit.COL_ACCENT) {
                    showExercisePickerDialog { picked ->
                        standaloneSession = db.appendExerciseToStandaloneSession(currentStandalone, picked, activeWeek)
                        startOrEnsureGlobalWorkoutTimer(currentStandalone.templateName, playTone = true)
                        savePrefs()
                        renderActivePage()
                    }
                }.apply {
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                        rightMargin = UiKit.rdp(this@MainActivity, 6)
                    }
                })
                actRow.addView(UiKit.outlineButton(this, "Switch Workout") {
                    showWorkoutSwitcherDialog()
                })
                restCard.addView(actRow)
            } else {
                restCard.addView(UiKit.text(this, "Scheduled Recovery Day", 15.5f, UiKit.COL_TEXT_DARK, bold = true))
                restCard.addView(UiKit.spacerV(this, 4))
                restCard.addView(UiKit.text(this, "No lifting scheduled on Day $activeDay, or pick any template / empty workout below to train today.", 12f, UiKit.COL_TEXT_MUTED))
                restCard.addView(UiKit.spacerV(this, 10))
                val (rScroll, rRow) = UiKit.hScrollRow(this)
                rRow.addView(UiKit.primaryButton(this, "Choose Workout", UiKit.COL_ACCENT) {
                    showWorkoutSwitcherDialog()
                })
                rRow.addView(UiKit.spacerH(this, 6))
                rRow.addView(UiKit.outlineButton(this, "Start Empty Workout") {
                    standaloneSession = db.startQuickEmptySession("Custom Workout")
                    startOrEnsureGlobalWorkoutTimer("Custom Workout", playTone = true)
                    savePrefs()
                    renderActivePage()
                })
                rRow.addView(UiKit.spacerH(this, 6))
                rRow.addView(UiKit.outlineButton(this, "+ Add Exercise to Day $activeDay") {
                    showExercisePickerDialog { picked ->
                        db.appendExerciseToScheduleDay(activeDay, picked, activeWeek)
                        renderActivePage()
                    }
                })
                restCard.addView(rScroll)
            }
            pageContent.addView(restCard)
            return
        }

        val liveSetsState = mutableMapOf<String, SetLog>()
        blocks.flatMap { it.sets }.forEach { liveSetsState[it.id] = it }

        fun isCardioExerciseBlock(exName: String, repRange: String, muscleId: String): Boolean {
            val n = exName.lowercase(Locale.US)
            val r = repRange.lowercase(Locale.US)
            val m = muscleId.lowercase(Locale.US)
            if (m.contains("cardio")) return true
            if (r.contains("min") || r.contains("sec")) return true
            val keywords = listOf(
                "cardio", "treadmill", "incline walk", "assault bike", "air bike",
                "stationary bike", "cycling", "rowing", "rower", "erg", "stairmaster",
                "elliptical", "jump rope", "sprint", "zone 2", "hiit", "jog", "running"
            )
            return keywords.any { n.contains(it) }
        }

        fun refreshLiveFooterSummaries() {
            val doneRows = liveSetsState.values.filter { it.completed }
            val doneCnt = doneRows.size
            val totalCnt = liveSetsState.size
            val liveTonKg = doneRows.sumOf { it.weightKg * it.reps }
            inlineTrackFinishBtn?.text = if (doneCnt > 0) {
                "Workout Complete ($doneCnt sets)"
            } else {
                "Workout Complete ($totalCnt sets)"
            }
            inlineTrackHealthBtn?.text = "Sync Session ($doneCnt sets · ${liveTonKg.roundToInt()} kg) to Health Connect"
        }

        if (focusedTrackerExId != "all" && blocks.none { it.exId == focusedTrackerExId }) {
            focusedTrackerExId = "all"
        }

        if (blocks.size > 1) {
            val (focusScroll, focusRow) = UiKit.hScrollRow(this)
            focusRow.addView(UiKit.chip(this, "All Exercises (${blocks.size})", focusedTrackerExId == "all") {
                focusedTrackerExId = "all"
                if (hapticEnabled) NativeHardwareBridge.hapticTick(this)
                renderActivePage()
            })
            focusRow.addView(UiKit.spacerH(this, 6))
            blocks.forEachIndexed { bIdx, bItem ->
                val shortName = if (bItem.name.length > 22) "${bItem.name.take(20)}…" else bItem.name
                focusRow.addView(UiKit.chip(this, "${bIdx + 1}. $shortName", focusedTrackerExId == bItem.exId) {
                    focusedTrackerExId = bItem.exId
                    if (hapticEnabled) NativeHardwareBridge.hapticTick(this)
                    renderActivePage()
                })
                focusRow.addView(UiKit.spacerH(this, 6))
            }
            pageContent.addView(focusScroll)
            pageContent.addView(UiKit.spacerV(this, 8))
        }

        val visibleBlocks = if (focusedTrackerExId == "all") blocks else blocks.filter { it.exId == focusedTrackerExId }

        visibleBlocks.forEach { block ->
            val mName = landmarks[block.muscleId]?.shortName ?: block.muscleId
            val isCardioBlock = isCardioExerciseBlock(block.name, block.repRange, block.muscleId)
            val cleanBaseName = block.name.removeSuffix(" (SS)")
            val recentThreeSets = db.getRecentCompletedSetsForExercise(
                block.exId,
                cleanBaseName,
                limit = 3
            )
            val exCard = UiKit.card(this, padDp = 12)

            val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val hLeft = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            val titleRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            titleRow.addView(UiKit.text(this, block.name, 15f, UiKit.COL_TEXT_DARK, bold = true).apply {
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                    rightMargin = UiKit.rdp(this@MainActivity, 6)
                }
            })
            val historyChipLabel = if (recentThreeSets.isNotEmpty()) "↺ History (${recentThreeSets.size})" else "↺ History"
            val historyTooltip = if (recentThreeSets.isNotEmpty()) {
                "Previous ${recentThreeSets.size} sets: " + recentThreeSets.joinToString(" · ") { s ->
                    if (isCardioBlock) "${s.reps}m" else "${formatWeightForInput(s.weightKg)} $weightUnit × ${s.reps}"
                }
            } else {
                "View previous 3 sets for $cleanBaseName"
            }
            val historyBtn = UiKit.chip(this, historyChipLabel, recentThreeSets.isNotEmpty()) {
                if (hapticEnabled) NativeHardwareBridge.hapticTick(this)
                showExerciseHistoryMiniModal(
                    exId = block.exId,
                    exDisplayName = block.name,
                    cleanExName = cleanBaseName,
                    muscleLabel = mName,
                    isCardioBlock = isCardioBlock,
                    currentSets = block.sets
                )
            }.apply {
                contentDescription = "Previous 3 sets for $cleanBaseName"
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    tooltipText = historyTooltip
                }
            }
            titleRow.addView(historyBtn)
            hLeft.addView(titleRow)

            val subtitleText = if (isCardioBlock) {
                "Cardio Timer · Tracked in duration instead of sets"
            } else {
                "$mName · ${block.repRange} reps"
            }
            hLeft.addView(UiKit.text(this, subtitleText, 11.5f, UiKit.COL_TEXT_MUTED, tabular = true))
            head.addView(hLeft)
            if (!isCardioBlock) {
                head.addView(UiKit.chip(this, "${block.restSec}s", false) {
                    startRestTimer(block.restSec, block.name)
                })
                head.addView(UiKit.spacerH(this, 4))
            }
            head.addView(UiKit.text(this, "✕", 13f, UiKit.COL_TEXT_MUTED, bold = true).apply {
                val px = UiKit.dp(this@MainActivity, 6)
                setPadding(px, px, px, px)
                setOnClickListener {
                    if (activeCardioExId == block.exId) {
                        activeCardioExId = null
                        mainHandler.removeCallbacks(cardioTickRunnable)
                    }
                    if (currentStandalone != null) {
                        standaloneSession = db.removeExerciseFromStandaloneSession(currentStandalone, block.exId)
                        savePrefs()
                    } else {
                        db.removeDayExercise(block.exId)
                    }
                    renderActivePage()
                }
            })
            exCard.addView(head)
            exCard.addView(UiKit.spacerV(this, 8))

            if (isCardioBlock) {
                // CARDIO TIMER UI (Tracked via timer instead of sets)
                val targetSec = cardioTargetSecMap.getOrPut(block.exId) { 20 * 60 }
                val remSec = cardioRemainingSecMap.getOrPut(block.exId) { targetSec }
                val zone = cardioZoneMap.getOrPut(block.exId) { "Zone 2" }
                val isRunning = activeCardioExId == block.exId
                val loggedMin = cardioCompletedMap[block.exId] ?: 0

                val timerPanel = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    background = UiKit.roundedBg(
                        if (loggedMin > 0) UiKit.COL_ROW_COMPLETED else UiKit.COL_SUBTLE,
                        10f,
                        this@MainActivity,
                        if (loggedMin > 0) 0xFF10B981.toInt() else UiKit.COL_BORDER,
                        1f
                    )
                    val p = UiKit.rdp(this@MainActivity, 12)
                    setPadding(p, p, p, p)
                }

                val topClockRow = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                }
                val clockTv = UiKit.text(
                    this,
                    formatClock(remSec),
                    26f,
                    if (isRunning) UiKit.COL_ACCENT else UiKit.COL_TEXT_DARK,
                    bold = true,
                    tabular = true
                ).apply {
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                if (isRunning) {
                    activeCardioClockView = clockTv
                }
                topClockRow.addView(clockTv)
                topClockRow.addView(UiKit.chip(this, "-1m", false) {
                    val nextTarget = (targetSec - 60).coerceIn(60, 120 * 60)
                    cardioTargetSecMap[block.exId] = nextTarget
                    cardioRemainingSecMap[block.exId] = (remSec - 60).coerceIn(30, nextTarget)
                    NativeHardwareBridge.playTimerSetTone(this, soundOnTimer)
                    renderActivePage()
                })
                topClockRow.addView(UiKit.spacerH(this, 4))
                topClockRow.addView(UiKit.chip(this, "+1m", false) {
                    val nextTarget = (targetSec + 60).coerceIn(60, 120 * 60)
                    cardioTargetSecMap[block.exId] = nextTarget
                    cardioRemainingSecMap[block.exId] = (remSec + 60).coerceIn(60, nextTarget)
                    NativeHardwareBridge.playTimerSetTone(this, soundOnTimer)
                    renderActivePage()
                })
                timerPanel.addView(topClockRow)
                timerPanel.addView(UiKit.spacerV(this, 6))

                // Duration Presets: 5m, 10m, 15m, 20m, 30m, 45m
                val (durScroll, durRow) = UiKit.hScrollRow(this)
                listOf(5, 10, 15, 20, 30, 45).forEach { mins ->
                    val secVal = mins * 60
                    durRow.addView(UiKit.chip(this, "${mins}m", targetSec == secVal) {
                        cardioTargetSecMap[block.exId] = secVal
                        cardioRemainingSecMap[block.exId] = secVal
                        NativeHardwareBridge.playTimerSetTone(this, soundOnTimer)
                        renderActivePage()
                    })
                    durRow.addView(UiKit.spacerH(this, 5))
                }
                timerPanel.addView(durScroll)
                timerPanel.addView(UiKit.spacerV(this, 6))

                // Intensity Zone Selector
                val (zScroll, zRow) = UiKit.hScrollRow(this)
                listOf("Zone 2", "Tempo", "HIIT").forEach { z ->
                    zRow.addView(UiKit.chip(this, z, zone == z) {
                        cardioZoneMap[block.exId] = z
                        if (hapticEnabled) NativeHardwareBridge.hapticTick(this)
                        renderActivePage()
                    })
                    zRow.addView(UiKit.spacerH(this, 5))
                }
                timerPanel.addView(zScroll)
                timerPanel.addView(UiKit.spacerV(this, 8))

                // Action Row: Start/Pause | Reset | Complete Cardio
                val actRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                actRow.addView(UiKit.primaryButton(
                    this,
                    if (isRunning) "Pause Timer" else "Start Cardio Timer",
                    UiKit.COL_ACCENT
                ) {
                    if (isRunning) {
                        activeCardioExId = null
                        mainHandler.removeCallbacks(cardioTickRunnable)
                    } else {
                        activeCardioExId = block.exId
                        startOrEnsureGlobalWorkoutTimer(activeSessionTitle, playTone = false)
                        NativeHardwareBridge.playTimerSetTone(this, soundOnTimer)
                        mainHandler.removeCallbacks(cardioTickRunnable)
                        mainHandler.postDelayed(cardioTickRunnable, 1000L)
                    }
                    renderActivePage()
                }.apply {
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.1f).apply {
                        rightMargin = UiKit.rdp(this@MainActivity, 5)
                    }
                })

                actRow.addView(UiKit.outlineButton(this, "Reset") {
                    if (activeCardioExId == block.exId) {
                        activeCardioExId = null
                        mainHandler.removeCallbacks(cardioTickRunnable)
                    }
                    cardioRemainingSecMap[block.exId] = targetSec
                    renderActivePage()
                }.apply {
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.65f).apply {
                        rightMargin = UiKit.rdp(this@MainActivity, 5)
                    }
                })

                actRow.addView(UiKit.primaryButton(
                    this,
                    if (loggedMin > 0) "Logged (${loggedMin}m) ✓" else "Complete Cardio",
                    0xFF059669.toInt()
                ) {
                    if (activeCardioExId == block.exId) {
                        activeCardioExId = null
                        mainHandler.removeCallbacks(cardioTickRunnable)
                    }
                    val elapsedSec = (targetSec - remSec).takeIf { it >= 30 } ?: targetSec
                    val minsDone = (elapsedSec / 60).coerceAtLeast(1)
                    cardioCompletedMap[block.exId] = minsDone
                    val firstSet = block.sets.firstOrNull()
                    if (firstSet != null) {
                        val updated = firstSet.copy(
                            weightKg = 0.0,
                            reps = minsDone,
                            completed = true,
                            completedDateIso = LocalDate.now().toString()
                        )
                        liveSetsState[firstSet.id] = updated
                        db.saveSetLog(updated, notifyWidget = true)
                    }
                    if (hapticEnabled) NativeHardwareBridge.hapticTick(this)
                    HyperLogStorageManager.saveDatabaseSnapshotAsync(this, db)
                    showBanner("✓ Completed $minsDone min $zone Cardio (${block.name})")
                    timerPanel.animate().scaleX(1.025f).scaleY(1.025f).setDuration(85L).withEndAction {
                        timerPanel.animate().scaleX(1f).scaleY(1f).setDuration(90L).withEndAction {
                            renderActivePage()
                        }.start()
                    }.start()
                }.apply {
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.1f)
                })
                timerPanel.addView(actRow)
                exCard.addView(timerPanel)
                pageContent.addView(exCard)
                return@forEach
            }

            // Spacious 5-Column Default Set Table (SET | KG/LB | REPS | EFFORT | DONE), Optional RPE on Demand
            val showBlockRpe = showOptionalRpeCol || block.sets.any { it.rpe != null }
            val colHead = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                val px = UiKit.rdp(this@MainActivity, 5)
                setPadding(px, 0, px, UiKit.dp(this@MainActivity, 4))
            }
            colHead.addView(UiKit.text(this, "SET", 9.5f, UiKit.COL_TEXT_MUTED, bold = true, tabular = true).apply {
                gravity = Gravity.CENTER
                width = UiKit.rdp(this@MainActivity, 28)
            })
            colHead.addView(UiKit.text(this, weightUnit.uppercase(), 9.5f, UiKit.COL_TEXT_MUTED, bold = true, tabular = true).apply {
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f)
            })
            colHead.addView(UiKit.spacerH(this, 4))
            colHead.addView(UiKit.text(this, "REPS", 9.5f, UiKit.COL_TEXT_MUTED, bold = true, tabular = true).apply {
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.8f)
            })
            colHead.addView(UiKit.spacerH(this, 4))
            colHead.addView(UiKit.text(this, "EFFORT", 9.5f, UiKit.COL_TEXT_MUTED, bold = true, tabular = true).apply {
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.15f)
            })
            if (showBlockRpe) {
                colHead.addView(UiKit.spacerH(this, 4))
                colHead.addView(UiKit.text(this, "RPE", 9.5f, UiKit.COL_TEXT_MUTED, bold = true, tabular = true).apply {
                    gravity = Gravity.CENTER
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.72f)
                })
            }
            colHead.addView(UiKit.text(this, "DONE", 9.5f, UiKit.COL_TEXT_MUTED, bold = true).apply {
                gravity = Gravity.CENTER
                width = UiKit.rdp(this@MainActivity, 38)
            })
            exCard.addView(colHead)

            block.sets.forEachIndexed { sIdx, setRow ->
                val rowLayout = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    background = if (UiKit.isPastelGlass && !setRow.completed) {
                        UiKit.pastelGlassSurfaceDrawable(this@MainActivity, radiusDp = 10f, subtle = true)
                    } else {
                        UiKit.roundedBg(
                            if (setRow.completed) UiKit.COL_ROW_COMPLETED else UiKit.COL_SUBTLE,
                            10f,
                            this@MainActivity,
                            if (setRow.completed) 0xFF10B981.toInt() else UiKit.COL_BORDER,
                            1f
                        )
                    }
                    val p = UiKit.rdp(this@MainActivity, 5)
                    setPadding(p, p, p, p)
                    layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                        bottomMargin = UiKit.rdp(this@MainActivity, 6)
                    }
                }
                UiKit.animateSetRowEntrance(rowLayout, sIdx)

                rowLayout.addView(UiKit.text(this, "${setRow.setIndex}", 12f, UiKit.COL_TEXT_DARK, bold = true, tabular = true).apply {
                    gravity = Gravity.CENTER
                    width = UiKit.rdp(this@MainActivity, 28)
                })

                val dispW = formatWeightForInput(setRow.weightKg)

                var latestRir = setRow.rir
                var latestRpe: Double? = setRow.rpe

                val wInput = UiKit.numericSetInputBox(this, dispW, weightUnit, InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL).apply {
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f)
                }
                val rInput = UiKit.numericSetInputBox(this, setRow.reps.coerceAtLeast(1).toString(), "10", InputType.TYPE_CLASS_NUMBER).apply {
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.8f)
                }
                val initRpeText = setRow.rpe?.let { r -> formatCleanDecimal(r) } ?: ""
                val rpeInput = UiKit.numericSetInputBox(this, initRpeText, "—", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL).apply {
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.72f)
                }

                fun currentSnapshot(completedFlag: Boolean = (liveSetsState[setRow.id]?.completed ?: setRow.completed)): SetLog {
                    val curW = wInput.text.toString().trim().toDoubleOrNull()?.let { parseInputToWeightKg(it) } ?: setRow.weightKg
                    val curR = rInput.text.toString().trim().toIntOrNull()?.coerceIn(1, 999) ?: setRow.reps.coerceIn(1, 999)
                    val snapRow = setRow.copy(
                        weightKg = curW,
                        reps = curR,
                        rir = latestRir,
                        rpe = latestRpe,
                        completed = completedFlag,
                        completedDateIso = if (completedFlag) (setRow.completedDateIso ?: LocalDate.now().toString()) else null
                    )
                    liveSetsState[setRow.id] = snapRow
                    return snapRow
                }

                wInput.addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                    override fun afterTextChanged(s: Editable?) {
                        if (s?.toString()?.trim()?.toDoubleOrNull() == null) return
                        val snapRow = currentSnapshot()
                        db.saveSetLog(snapRow, notifyWidget = snapRow.completed)
                        lastRenderedParitySignature = db.computeSetLogsParitySignature()
                        refreshLiveFooterSummaries()
                    }
                })
                rowLayout.addView(wInput)
                rowLayout.addView(UiKit.spacerH(this, 4))

                rInput.addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                    override fun afterTextChanged(s: Editable?) {
                        val parsedReps = s?.toString()?.trim()?.toIntOrNull() ?: return
                        if (parsedReps < 1) return
                        val snapRow = currentSnapshot()
                        db.saveSetLog(snapRow, notifyWidget = snapRow.completed)
                        lastRenderedParitySignature = db.computeSetLogsParitySignature()
                        refreshLiveFooterSummaries()
                    }
                })
                rowLayout.addView(rInput)
                rowLayout.addView(UiKit.spacerH(this, 4))

                val rirSpinner = UiKit.rirDropdownSpinner(this, setRow.rir) { chosenRir ->
                    latestRir = chosenRir
                    val snapRow = currentSnapshot()
                    db.saveSetLog(snapRow, notifyWidget = snapRow.completed)
                    lastRenderedParitySignature = db.computeSetLogsParitySignature()
                    if (hapticEnabled) NativeHardwareBridge.hapticTick(this@MainActivity)
                }.apply {
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.15f)
                }
                rowLayout.addView(rirSpinner)

                if (showBlockRpe) {
                    rowLayout.addView(UiKit.spacerH(this, 4))
                    rpeInput.addTextChangedListener(object : TextWatcher {
                        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                        override fun afterTextChanged(s: Editable?) {
                            val txt = s?.toString()?.trim().orEmpty()
                            if (txt.isEmpty()) {
                                latestRpe = null
                                val snapRow = currentSnapshot()
                                db.saveSetLog(snapRow, notifyWidget = snapRow.completed)
                                lastRenderedParitySignature = db.computeSetLogsParitySignature()
                                return
                            }
                            val parsed = txt.toDoubleOrNull() ?: return
                            latestRpe = ((parsed.coerceIn(1.0, 10.0)) * 2.0).roundToInt() / 2.0
                            val snapRow = currentSnapshot()
                            db.saveSetLog(snapRow, notifyWidget = snapRow.completed)
                            lastRenderedParitySignature = db.computeSetLogsParitySignature()
                        }
                    })
                    rowLayout.addView(rpeInput)
                }

                val cbWrap = android.widget.FrameLayout(this).apply {
                    layoutParams = LinearLayout.LayoutParams(UiKit.rdp(this@MainActivity, 36), LinearLayout.LayoutParams.WRAP_CONTENT)
                }
                val cb = CheckBox(this).apply {
                    isChecked = setRow.completed
                    layoutParams = android.widget.FrameLayout.LayoutParams(
                        android.widget.FrameLayout.LayoutParams.WRAP_CONTENT,
                        android.widget.FrameLayout.LayoutParams.WRAP_CONTENT,
                        Gravity.CENTER
                    )
                    setOnCheckedChangeListener { _, checked ->
                        db.saveSetLog(currentSnapshot(completedFlag = checked), notifyWidget = false)
                        HyperLogStreakWidgetProvider.onSetCompleted(this@MainActivity)
                        HyperLogStorageManager.saveDatabaseSnapshotAsync(this@MainActivity, db)
                        if (checked) {
                            if (hapticEnabled) NativeHardwareBridge.hapticTick(this@MainActivity)
                            startOrEnsureGlobalWorkoutTimer(activeSessionTitle, playTone = false)
                            startRestTimer(customRestDurationSec, block.name)
                            // Subtle compositor 'pop' animation on set completion before re-rendering
                            cbWrap.animate().scaleX(1.18f).scaleY(1.18f).setDuration(85L).withEndAction {
                                cbWrap.animate().scaleX(1f).scaleY(1f).setDuration(90L).start()
                            }.start()
                            rowLayout.animate().scaleX(1.028f).scaleY(1.028f).setDuration(85L).withEndAction {
                                rowLayout.animate().scaleX(1f).scaleY(1f).setDuration(95L).withEndAction {
                                    renderActivePage()
                                }.start()
                            }.start()
                        } else {
                            renderActivePage()
                        }
                    }
                }
                cbWrap.addView(cb)
                rowLayout.addView(cbWrap)
                exCard.addView(rowLayout)
            }

            // Calm 1-Row Footer: + Set | - Set | 1-Tap Pump Cycle
            val foot = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            foot.addView(UiKit.outlineButton(this, "+ Add Set") {
                val last = block.sets.lastOrNull()
                val weekMeta = MESOCYCLE_WEEKS.find { it.week == activeWeek } ?: MESOCYCLE_WEEKS[2]
                db.saveSetLog(SetLog(
                    id = "set_${System.currentTimeMillis()}",
                    week = activeWeek,
                    dayNumber = if (currentStandalone != null) 0 else activeDay,
                    templateSessionId = currentStandalone?.sessionId,
                    exerciseId = block.exId,
                    exerciseName = block.name,
                    muscleId = block.muscleId,
                    setIndex = (last?.setIndex ?: 0) + 1,
                    weightKg = last?.weightKg ?: block.defaultW,
                    reps = last?.reps ?: 10,
                    rir = last?.rir ?: weekMeta.defaultRirNumber,
                    restSeconds = block.restSec,
                    completed = false,
                    completedDateIso = null,
                    rpe = last?.rpe
                ))
                renderActivePage()
            })
            if (block.sets.size > 1) {
                foot.addView(UiKit.spacerH(this, 6))
                foot.addView(UiKit.outlineButton(this, "- Remove", UiKit.COL_TEXT_MUTED) {
                    block.sets.lastOrNull()?.let {
                        db.deleteSetLog(it.id)
                        renderActivePage()
                    }
                })
            }
            foot.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(0, 1, 1f) })

            val fbKey = "w${activeWeek}_${block.muscleId}"
            val curPump = feedbackMap[fbKey]?.pumpScore ?: 2
            val pumpLbl = when (curPump) {
                1 -> "Pump: Low"
                3 -> "Pump: Max"
                else -> "Pump: Good"
            }
            foot.addView(UiKit.chip(this, pumpLbl, curPump == 3) {
                val nextPump = when (curPump) {
                    2 -> 3
                    3 -> 1
                    else -> 2
                }
                db.saveFeedback(MuscleFeedback(fbKey, activeWeek, block.muscleId, nextPump, 1))
                if (hapticEnabled) NativeHardwareBridge.hapticTick(this)
                renderActivePage()
            })
            exCard.addView(foot)
            pageContent.addView(exCard)
        }

        // Mid-Workout Add Exercise + Add Cardio Timer Row
        val addExWrap = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = UiKit.rdp(this@MainActivity, 8)
            }
        }
        addExWrap.addView(UiKit.outlineButton(this, "+ Add Exercise", UiKit.COL_ACCENT) {
            showExercisePickerDialog { picked ->
                if (currentStandalone != null) {
                    standaloneSession = db.appendExerciseToStandaloneSession(currentStandalone, picked, activeWeek)
                    savePrefs()
                } else {
                    db.appendExerciseToScheduleDay(activeDay, picked, activeWeek)
                }
                showBanner("Added '${picked.name}' to active workout")
                renderActivePage()
            }
        }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                rightMargin = UiKit.rdp(this@MainActivity, 6)
            }
        })
        addExWrap.addView(UiKit.outlineButton(this, "+ Add Cardio Timer", 0xFF059669.toInt()) {
            val cardioLib = LibraryExercise(
                id = "lib_cardio_zone2_${System.currentTimeMillis()}",
                name = "Zone 2 Incline Treadmill Cardio",
                majorGroup = "CARDIO",
                primaryMuscle = "quads",
                secondaryMusclesCsv = "calves,glutes",
                equipment = "Machine",
                description = "Steady-state aerobic conditioning tracked via Cardio Timer.",
                instructionsText = "Maintain nasal breathing pace at 8–12% incline.",
                defaultRepRange = "20 min",
                defaultRestSeconds = 0,
                defaultWeightKg = 0.0,
                videoUrl = ""
            )
            if (currentStandalone != null) {
                standaloneSession = db.appendExerciseToStandaloneSession(currentStandalone, cardioLib, activeWeek)
                savePrefs()
            } else {
                db.appendExerciseToScheduleDay(activeDay, cardioLib, activeWeek)
            }
            showBanner("Added Cardio Timer block to active workout")
            renderActivePage()
        }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        pageContent.addView(addExWrap)

        // Primary Workout Complete CTA -> Finalizes session & redirects to Congratulations + Google Sync page
        val initialDone = liveSetsState.values.filter { it.completed }
        val finishRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = UiKit.rdp(this@MainActivity, 8)
            }
        }
        val finishBtn = UiKit.primaryButton(
            this,
            if (initialDone.isNotEmpty()) "Workout Complete (${initialDone.size} sets)" else "Workout Complete (${liveSetsState.size} sets)",
            0xFF059669.toInt()
        ) {
            val todayIso = LocalDate.now().toString()
            val curDone = liveSetsState.values.filter { it.completed }
            val setsToSave = if (curDone.isNotEmpty()) {
                curDone
            } else {
                db.completeSetsBatch(liveSetsState.values.toList(), todayIso)
            }
            completeWorkoutAndOpenCongratulations(activeSessionTitle, setsToSave)
        }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.3f).apply {
                rightMargin = UiKit.rdp(this@MainActivity, 6)
            }
        }
        inlineTrackFinishBtn = finishBtn
        finishRow.addView(finishBtn)

        finishRow.addView(UiKit.outlineButton(this, "Share PDF", UiKit.COL_ACCENT) {
            val todayIso = LocalDate.now().toString()
            val curDone = liveSetsState.values.filter { it.completed }
            shareSingleDayWorkoutPdf(todayIso, curDone.ifEmpty { db.getCompletedSetsForDate(todayIso) })
        }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.7f)
        })
        pageContent.addView(finishRow)

        // Cancel / Switch Workout Row: lets users stop an ongoing workout cleanly & choose another activity
        val cancelAndSyncRow = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        val cancelBtn = UiKit.outlineButton(this, "Cancel Workout & Pick Another Activity", 0xFFDC2626.toInt()) {
            showCancelWorkoutDialog(activeSessionTitle, liveSetsState.values.toList(), currentStandalone)
        }.apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = UiKit.rdp(this@MainActivity, 8)
            }
        }
        cancelAndSyncRow.addView(cancelBtn)
        inlineTrackHealthBtn = null
        pageContent.addView(cancelAndSyncRow)
    }

    /**
     * Exercise History Mini-Modal (Standalone Android App):
     * Displays the previous 3 sets performed for a specific exercise when its History icon is tapped,
     * with a 1-tap "Use Weights & Reps" action to populate unfinished sets.
     */
    private fun showExerciseHistoryMiniModal(
        exId: String,
        exDisplayName: String,
        cleanExName: String,
        muscleLabel: String,
        isCardioBlock: Boolean,
        currentSets: List<SetLog>
    ) {
        val recentSets = db.getRecentCompletedSetsForExercise(exId, cleanExName, limit = 3)
        val hasUncompleted = !isCardioBlock && recentSets.isNotEmpty() && currentSets.any { !it.completed }
        val todayIso = LocalDate.now().toString()
        val fmtShort = DateTimeFormatter.ofPattern("MMM d", Locale.US)

        val outerWrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val pad = UiKit.dp(this@MainActivity, 14)
            setPadding(pad, pad, pad, pad)
        }
        val cardBox = UiKit.card(this, padDp = 16)
        outerWrap.addView(cardBox)

        lateinit var dialogRef: AlertDialog

        val headerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        titleCol.addView(UiKit.text(this, exDisplayName, 16f, UiKit.COL_TEXT_DARK, bold = true))
        titleCol.addView(UiKit.text(
            this,
            "Previous 3 sets performed · $muscleLabel",
            11.5f,
            UiKit.COL_TEXT_MUTED
        ))
        headerRow.addView(titleCol)
        headerRow.addView(UiKit.text(this, "✕", 14f, UiKit.COL_TEXT_MUTED, bold = true).apply {
            val px = UiKit.dp(this@MainActivity, 8)
            setPadding(px, px, px, px)
            setOnClickListener { dialogRef.dismiss() }
        })
        fun makeModalDivider(): View = View(this).apply {
            setBackgroundColor(UiKit.COL_BORDER)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                UiKit.dp(this@MainActivity, 1).coerceAtLeast(1)
            )
        }

        cardBox.addView(headerRow)
        cardBox.addView(UiKit.spacerV(this, 10))
        cardBox.addView(makeModalDivider())

        if (recentSets.isEmpty()) {
            cardBox.addView(UiKit.spacerV(this, 12))
            cardBox.addView(UiKit.text(
                this,
                "No completed sets recorded for $cleanExName yet. Once you check off sets during a workout, your previous 3 sets will appear here for quick reference.",
                12.5f,
                UiKit.COL_TEXT_MUTED
            ))
            cardBox.addView(UiKit.spacerV(this, 12))
        } else {
            recentSets.forEachIndexed { idx, s ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    val py = UiKit.rdp(this@MainActivity, 9)
                    setPadding(0, py, 0, py)
                }
                val dIso = s.completedDateIso
                val dateLabel = when {
                    dIso.isNullOrBlank() -> "Week ${s.week}"
                    dIso == todayIso -> "Today"
                    else -> runCatching { LocalDate.parse(dIso).format(fmtShort) }.getOrElse { dIso }
                }

                val leftCol = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                leftCol.addView(UiKit.text(this, "Set ${s.setIndex}", 12.5f, UiKit.COL_TEXT_DARK, bold = true, tabular = true))
                leftCol.addView(UiKit.text(this, dateLabel, 11f, UiKit.COL_TEXT_MUTED))
                row.addView(leftCol)

                val rightCol = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.END
                }
                val perfText = if (isCardioBlock) {
                    "${s.reps} min"
                } else {
                    "${formatWeightForInput(s.weightKg)} $weightUnit × ${s.reps}"
                }
                val rirClean = formatCleanDecimal(s.rir)
                val effortText = if (isCardioBlock) {
                    "Timed cardio"
                } else {
                    val rpeSuffix = s.rpe?.let { " · RPE ${formatCleanDecimal(it)}" } ?: ""
                    "$rirClean RIR$rpeSuffix"
                }
                rightCol.addView(UiKit.text(this, perfText, 13.5f, UiKit.COL_TEXT_DARK, bold = true, tabular = true))
                rightCol.addView(UiKit.text(this, effortText, 11f, UiKit.COL_TEXT_MUTED, tabular = true))
                row.addView(rightCol)

                cardBox.addView(row)
                if (idx < recentSets.lastIndex) {
                    cardBox.addView(makeModalDivider())
                }
            }
            cardBox.addView(makeModalDivider())
            cardBox.addView(UiKit.spacerV(this, 12))
        }

        val btnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        if (hasUncompleted) {
            btnRow.addView(UiKit.primaryButton(this, "Use Weights & Reps", UiKit.COL_ACCENT) {
                currentSets.forEachIndexed { idx, row ->
                    if (!row.completed) {
                        val ref = recentSets[idx.coerceAtMost(recentSets.lastIndex)]
                        db.saveSetLog(
                            row.copy(weightKg = ref.weightKg, reps = ref.reps),
                            notifyWidget = false
                        )
                    }
                }
                if (hapticEnabled) NativeHardwareBridge.hapticTick(this)
                dialogRef.dismiss()
                showBanner("Applied previous weights & reps to $cleanExName")
                renderActivePage()
            }.apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.35f).apply {
                    rightMargin = UiKit.rdp(this@MainActivity, 6)
                }
            })
            btnRow.addView(UiKit.outlineButton(this, "Done") {
                dialogRef.dismiss()
            }.apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.75f)
            })
        } else {
            btnRow.addView(UiKit.outlineButton(this, "Done") {
                dialogRef.dismiss()
            }.apply {
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            })
        }
        cardBox.addView(btnRow)

        dialogRef = AlertDialog.Builder(this, UiKit.dialogTheme())
            .setView(outerWrap)
            .create()
        dialogRef.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialogRef.show()
    }

    /**
     * Friendly Workout Cancellation Dialog:
     * Gives the user a safe choice to either KEEP the sets they already checked off
     * or DISCARD them completely, then stops active timers and opens the Workout Launchpad.
     */
    private fun showCancelWorkoutDialog(
        sessionTitle: String,
        sessionSets: List<SetLog>,
        currentStandalone: StandaloneSession?
    ) {
        val doneSets = sessionSets.filter { it.completed }
        val msg = if (doneSets.isNotEmpty()) {
            "You have ${doneSets.size} completed set(s) in \"$sessionTitle\". Would you like to keep those logged sets in your history or discard this session completely?"
        } else {
            "Stop \"$sessionTitle\", reset running workout timers, and return to the Workout Selection menu?"
        }
        val builder = AlertDialog.Builder(this, UiKit.dialogTheme())
            .setTitle("Cancel Current Workout?")
            .setMessage(msg)
            .setNegativeButton("Keep Training", null)

        if (doneSets.isNotEmpty()) {
            builder.setNeutralButton("Cancel & Keep ${doneSets.size} Sets") { _, _ ->
                stopRestTimer()
                activeCardioExId = null
                mainHandler.removeCallbacks(cardioTickRunnable)
                stopAndResetGlobalWorkoutTimer()
                standaloneSession = null
                hasSelectedScheduleDay = false
                savePrefs()
                HyperLogStorageManager.saveDatabaseSnapshotAsync(this, db)
                showBanner("Workout stopped — kept ${doneSets.size} completed sets. Pick any new workout!")
                mainScroll.scrollTo(0, 0)
                renderActivePage()
            }
        }

        builder.setPositiveButton(if (doneSets.isNotEmpty()) "Discard Session Sets" else "Yes, Cancel Workout") { _, _ ->
            if (currentStandalone != null) {
                sessionSets.forEach { db.deleteSetLog(it.id) }
            } else {
                doneSets.forEach { s ->
                    db.saveSetLog(s.copy(completed = false, completedDateIso = null))
                }
            }
            stopRestTimer()
            activeCardioExId = null
            mainHandler.removeCallbacks(cardioTickRunnable)
            cardioCompletedMap.clear()
            stopAndResetGlobalWorkoutTimer()
            standaloneSession = null
            hasSelectedScheduleDay = false
            savePrefs()
            HyperLogStreakWidgetProvider.refreshAllWidgets(this)
            HyperLogStorageManager.saveDatabaseSnapshotAsync(this, db)
            showBanner("Cancelled \"$sessionTitle\" — choose your next workout below!")
            mainScroll.scrollTo(0, 0)
            renderActivePage()
        }
        builder.show()
    }

    private fun completeWorkoutAndOpenCongratulations(sessionTitle: String, completedSets: List<SetLog>) {
        val todayIso = LocalDate.now().toString()
        val elapsedMinutes = (currentGlobalElapsedSec() / 60).takeIf { it >= 1 } ?: 45
        val cardioMins = cardioCompletedMap.values.sum()
        val totalDur = (elapsedMinutes + cardioMins).coerceIn(5, 300)
        val tonKg = completedSets.sumOf { it.weightKg * it.reps }

        db.saveWorkoutDayNote(
            WorkoutDayNote(
                dateIso = todayIso,
                title = sessionTitle,
                durationMinutes = totalDur,
                notes = if (cardioMins > 0) "Includes $cardioMins min Cardio Timer session" else "Completed in HyperLog"
            )
        )
        db.recordWorkoutActivityToday()
        stopRestTimer()
        activeCardioExId = null
        mainHandler.removeCallbacks(cardioTickRunnable)
        stopAndResetGlobalWorkoutTimer()
        NativeHardwareBridge.playTimerCompleteTone(this, soundOnTimer)
        if (hapticEnabled) NativeHardwareBridge.hapticRestComplete(this)

        standaloneSession = null
        hasSelectedScheduleDay = false
        savePrefs()
        HyperLogStreakWidgetProvider.refreshAllWidgets(this)
        HyperLogStorageManager.saveDatabaseSnapshotAsync(this, db)

        val state = CompletedWorkoutViewState(
            title = sessionTitle,
            dateIso = todayIso,
            setsCount = completedSets.size.coerceAtLeast(1),
            tonnageKg = tonKg,
            durationMinutes = totalDur,
            cardioMinutes = cardioMins,
            googleSyncStatus = "Syncing to Google Fit & Android Health Connect..."
        )
        completedWorkoutState = state
        activeTab = 0
        mainScroll.scrollTo(0, 0)
        renderActivePage()

        NativeHardwareBridge.syncWorkoutToHealthConnect(
            activity = this,
            db = db,
            title = sessionTitle,
            completedSets = state.setsCount,
            tonnageKg = tonKg,
            durationMinutes = totalDur,
            modality = if (cardioMins > 0 && tonKg == 0.0) "cardio" else "strength"
        ) { statusMsg ->
            completedWorkoutState?.googleSyncStatus = statusMsg
            if (activeTab == 0 && completedWorkoutState != null) {
                renderActivePage()
            }
        }
    }

    /**
     * Celebratory Congratulations Screen:
     * Rewards the user with a gentle spring pop animation, XP level progress bar,
     * unlocked session achievement medals, and instant Google Fit / Health Connect sync.
     */
    private fun renderWorkoutCompletePage(summary: CompletedWorkoutViewState) {
        val snap = db.getWidgetProgressSnapshot(activeWeek)
        val earnedXp = (summary.setsCount * 25) + (summary.cardioMinutes * 10) + 100
        val totalLifetimeSets = db.getCompletedSetsByDateDesc().values.sumOf { it.size }
        val totalXp = (totalLifetimeSets * 25) + 250
        val athleteLevel = (totalXp / 500).coerceAtLeast(1)
        val levelProgress = ((totalXp % 500) / 500f).coerceIn(0.08f, 1f)

        val heroCard = UiKit.card(this, borderColor = 0xFF10B981.toInt(), borderDp = 1.5f, padDp = 16).apply {
            scaleX = 0.94f
            scaleY = 0.94f
            alpha = 0.85f
            animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(240L).start()
        }
        heroCard.addView(UiKit.text(this, "🏆 WORKOUT COMPLETE · +$earnedXp XP EARNED", 12f, 0xFF059669.toInt(), bold = true, tabular = true))
        heroCard.addView(UiKit.spacerV(this, 4))
        heroCard.addView(UiKit.text(this, "Awesome Job! Session Saved 🎉", 21f, UiKit.COL_TEXT_DARK, bold = true))
        heroCard.addView(UiKit.spacerV(this, 4))
        heroCard.addView(UiKit.text(this, "${summary.title} · ${summary.dateIso}", 13f, UiKit.COL_TEXT_MID, tabular = true))
        heroCard.addView(UiKit.spacerV(this, 12))

        val dispTon = if (weightUnit == "lb") "${(summary.tonnageKg * 2.20462).roundToInt()} lb" else "${summary.tonnageKg.roundToInt()} kg"
        val kpiRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(
            "SETS LOGGED" to summary.setsCount.toString(),
            "DURATION" to "${summary.durationMinutes} min",
            "VOLUME" to dispTon
        ).forEachIndexed { idx, (lbl, v) ->
            kpiRow.addView(UiKit.metricBox(this, lbl, v).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    if (idx < 2) rightMargin = UiKit.rdp(this@MainActivity, 6)
                }
            })
        }
        heroCard.addView(kpiRow)
        if (summary.cardioMinutes > 0) {
            heroCard.addView(UiKit.spacerV(this, 8))
            heroCard.addView(UiKit.text(
                this,
                "🫀 Cardio Timer Bonus: ${summary.cardioMinutes} min aerobic conditioning",
                12f,
                0xFF059669.toInt(),
                bold = true,
                tabular = true
            ))
        }

        // Level Progress & Unlocked Reward Medals Box
        heroCard.addView(UiKit.spacerV(this, 12))
        val xpBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = UiKit.roundedBg(UiKit.COL_SUBTLE, 10f, this@MainActivity, UiKit.COL_BORDER, 1f)
            val p = UiKit.rdp(this@MainActivity, 11)
            setPadding(p, p, p, p)
        }
        xpBox.addView(UiKit.text(
            this,
            "Level $athleteLevel Strength Explorer · 🔥 ${snap.streakDays}-Day Streak",
            13f,
            UiKit.COL_TEXT_DARK,
            bold = true,
            tabular = true
        ))
        xpBox.addView(UiKit.spacerV(this, 5))
        xpBox.addView(UiKit.progressBar(this, levelProgress, 0xFF10B981.toInt()))
        xpBox.addView(UiKit.spacerV(this, 7))

        val medals = mutableListOf("🥇 Session Finisher")
        if (snap.streakDays >= 2) medals.add("🔥 ${snap.streakDays}d Consistency Flame")
        if (summary.tonnageKg >= 2000.0) medals.add("🏋️ Heavy Iron Mover")
        if (summary.title.contains("Forearm", ignoreCase = true) || summary.title.contains("Grip", ignoreCase = true)) {
            medals.add("✊ Iron Forearm Grip")
        }
        if (summary.cardioMinutes > 0) medals.add("⚡ Cardio Engine")
        xpBox.addView(UiKit.text(this, "Unlocked Rewards: ${medals.joinToString("  ·  ")}", 11.5f, UiKit.COL_ACCENT, bold = true))
        heroCard.addView(xpBox)
        pageContent.addView(heroCard)

        // Google Sync & Health Connect Tracking Card
        val syncCard = UiKit.card(this, padDp = 14)
        syncCard.addView(UiKit.text(this, "Google Fit & Android Health Connect Sync", 15f, UiKit.COL_TEXT_DARK, bold = true))
        syncCard.addView(UiKit.spacerV(this, 4))
        syncCard.addView(UiKit.text(
            this,
            summary.googleSyncStatus,
            12f,
            0xFF059669.toInt(),
            bold = true,
            tabular = true
        ))
        syncCard.addView(UiKit.spacerV(this, 6))
        syncCard.addView(UiKit.text(
            this,
            "Internal Storage Backup: Saved to HyperLogData/database/user_database_snapshot.json",
            11.5f,
            UiKit.COL_TEXT_MUTED,
            tabular = true
        ))
        syncCard.addView(UiKit.spacerV(this, 10))

        val syncBtnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        syncBtnRow.addView(UiKit.primaryButton(this, "Sync Now with Google / Health Connect", UiKit.COL_ACCENT) {
            NativeHardwareBridge.syncWorkoutToHealthConnect(
                activity = this,
                db = db,
                title = summary.title,
                completedSets = summary.setsCount,
                tonnageKg = summary.tonnageKg,
                durationMinutes = summary.durationMinutes,
                modality = "strength"
            ) { msg ->
                summary.googleSyncStatus = msg
                showBanner(msg)
                renderActivePage()
            }
        }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.25f).apply {
                rightMargin = UiKit.rdp(this@MainActivity, 6)
            }
        })
        syncBtnRow.addView(UiKit.outlineButton(this, "Share PDF", UiKit.COL_ACCENT) {
            val sets = db.getCompletedSetsForDate(summary.dateIso)
            shareSingleDayWorkoutPdf(summary.dateIso, sets)
        }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.75f)
        })
        syncCard.addView(syncBtnRow)
        pageContent.addView(syncCard)

        val navRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        navRow.addView(UiKit.primaryButton(this, "View Workout Calendar", 0xFF059669.toInt()) {
            completedWorkoutState = null
            calendarSelectedDateIso = summary.dateIso
            workoutsSubTab = "calendar"
            activeTab = 2
            rebuildTopSettingsButton()
            rebuildBottomNav()
            renderActivePage()
        }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                rightMargin = UiKit.rdp(this@MainActivity, 6)
            }
        })
        navRow.addView(UiKit.outlineButton(this, "Back to Tracker") {
            completedWorkoutState = null
            renderActivePage()
        }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        pageContent.addView(navRow)
    }

    private fun showWorkoutSwitcherDialog() {
        val templates = db.getTemplates()
        val days = db.getWorkoutDays()
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = UiKit.dp(this@MainActivity, 16)
            setPadding(p, p, p, p)
        }
        scroll.addView(box)

        lateinit var dialogRef: AlertDialog

        box.addView(UiKit.text(this, "Quick Custom & Online Workouts", 11.5f, UiKit.COL_TEXT_MUTED, bold = true))
        box.addView(UiKit.spacerV(this, 5))
        box.addView(UiKit.primaryButton(this, "+ Start Empty Custom Workout", UiKit.COL_ACCENT) {
            standaloneSession = db.startQuickEmptySession("Custom Workout")
            startOrEnsureGlobalWorkoutTimer("Custom Workout", playTone = true)
            savePrefs()
            dialogRef.dismiss()
            renderActivePage()
        })
        box.addView(UiKit.spacerV(this, 6))
        box.addView(UiKit.outlineButton(this, "Pull 870+ Exercises & 13 Workouts (Mobile Data / Wi-Fi)", UiKit.COL_ACCENT) {
            dialogRef.dismiss()
            triggerOnlineCatalogSync()
        })
        box.addView(UiKit.spacerV(this, 12))

        box.addView(UiKit.text(this, "Workout Templates (${templates.size})", 11.5f, UiKit.COL_TEXT_MUTED, bold = true))
        box.addView(UiKit.spacerV(this, 5))
        templates.forEach { tpl ->
            val items = tpl.parsedExercises()
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = UiKit.roundedBg(UiKit.COL_SUBTLE, 10f, this@MainActivity, UiKit.COL_BORDER, 1f)
                val p = UiKit.rdp(this@MainActivity, 10)
                setPadding(p, p, p, p)
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = UiKit.rdp(this@MainActivity, 6)
                }
                setOnClickListener {
                    standaloneSession = db.startStandaloneTemplate(tpl, activeWeek)
                    startOrEnsureGlobalWorkoutTimer(tpl.name, playTone = true)
                    savePrefs()
                    dialogRef.dismiss()
                    renderActivePage()
                }
            }
            val left = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            left.addView(UiKit.text(this, tpl.name, 13.5f, UiKit.COL_TEXT_DARK, bold = true))
            left.addView(UiKit.text(this, "${tpl.splitType} · ${items.size} exercises", 11f, UiKit.COL_TEXT_MUTED))
            row.addView(left)
            row.addView(UiKit.text(this, "Track →", 12f, UiKit.COL_ACCENT, bold = true))
            box.addView(row)
        }

        box.addView(UiKit.spacerV(this, 8))
        box.addView(UiKit.text(this, "7-Day Mesocycle Split", 11.5f, UiKit.COL_TEXT_MUTED, bold = true))
        box.addView(UiKit.spacerV(this, 5))
        days.forEach { d ->
            val isCur = standaloneSession == null && activeDay == d.dayNumber
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = UiKit.roundedBg(
                    if (isCur) UiKit.COL_ROW_COMPLETED else UiKit.COL_SUBTLE,
                    10f,
                    this@MainActivity,
                    if (isCur) UiKit.COL_ACCENT else UiKit.COL_BORDER,
                    1f
                )
                val p = UiKit.rdp(this@MainActivity, 10)
                setPadding(p, p, p, p)
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = UiKit.rdp(this@MainActivity, 6)
                }
                setOnClickListener {
                    standaloneSession = null
                    hasSelectedScheduleDay = true
                    activeDay = d.dayNumber
                    savePrefs()
                    db.ensureDaySetRowsMaterialized(activeWeek, activeDay)
                    dialogRef.dismiss()
                    renderActivePage()
                }
            }
            val left = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            left.addView(UiKit.text(this, d.title, 13f, UiKit.COL_TEXT_DARK, bold = true))
            left.addView(UiKit.text(this, d.focusSummary, 11f, UiKit.COL_TEXT_MUTED))
            row.addView(left)
            row.addView(UiKit.text(this, if (isCur && hasSelectedScheduleDay) "Active ✓" else "Open", 11.5f, UiKit.COL_ACCENT, bold = true))
            box.addView(row)
        }

        dialogRef = AlertDialog.Builder(this, UiKit.dialogTheme())
            .setTitle("Select Workout to Track")
            .setView(scroll)
            .setNegativeButton("Close", null)
            .create()
        dialogRef.show()
    }

    private fun showFinishWorkoutDialog(defaultTitle: String, completedSets: List<SetLog>) {
        val todayIso = LocalDate.now().toString()
        val existingNote = db.getWorkoutDayNotesMap()[todayIso]
        val elapsedMinutes = (currentGlobalElapsedSec() / 60).takeIf { it >= 1 }
        val defaultDur = existingNote?.durationMinutes?.takeIf { it > 0 } ?: elapsedMinutes ?: 55

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = UiKit.dp(this@MainActivity, 16)
            setPadding(p, p, p, p)
        }
        val titleIn = UiKit.inputBox(this, existingNote?.title ?: defaultTitle, "Session Title", InputType.TYPE_CLASS_TEXT)
        val durIn = UiKit.inputBox(this, defaultDur.toString(), "Duration (minutes)", InputType.TYPE_CLASS_NUMBER)
        val notesIn = UiKit.inputBox(this, existingNote?.notes ?: "", "Optional session notes (pump, PRs, cues...)", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE)

        box.addView(UiKit.text(this, "${completedSets.size} sets logged today ($todayIso)", 12f, 0xFF059669.toInt(), bold = true))
        box.addView(UiKit.spacerV(this, 8))
        box.addView(UiKit.text(this, "Workout Title", 11f, UiKit.COL_TEXT_MUTED, bold = true))
        box.addView(titleIn)
        box.addView(UiKit.spacerV(this, 6))
        box.addView(UiKit.text(this, "Duration (minutes)", 11f, UiKit.COL_TEXT_MUTED, bold = true))
        box.addView(durIn)
        box.addView(UiKit.spacerV(this, 6))
        box.addView(UiKit.text(this, "Session Notes", 11f, UiKit.COL_TEXT_MUTED, bold = true))
        box.addView(notesIn)

        fun persistFinishMeta() {
            db.saveWorkoutDayNote(
                WorkoutDayNote(
                    dateIso = todayIso,
                    title = titleIn.text.toString().trim().ifBlank { defaultTitle },
                    durationMinutes = durIn.text.toString().toIntOrNull()?.coerceIn(1, 300) ?: defaultDur,
                    notes = notesIn.text.toString().trim()
                )
            )
            db.recordWorkoutActivityToday()
            stopRestTimer()
            stopAndResetGlobalWorkoutTimer()
            NativeHardwareBridge.playTimerCompleteTone(this, soundOnTimer)
            standaloneSession = null
            hasSelectedScheduleDay = false
            savePrefs()
            HyperLogStreakWidgetProvider.refreshAllWidgets(this)
        }

        AlertDialog.Builder(this, UiKit.dialogTheme())
            .setTitle("Finish Workout")
            .setView(box)
            .setPositiveButton("Finish & Save") { _, _ ->
                persistFinishMeta()
                calendarSelectedDateIso = todayIso
                calendarYear = LocalDate.now().year
                calendarMonth = LocalDate.now().monthValue
                workoutsSubTab = "calendar"
                activeTab = 2
                rebuildTopSettingsButton()
                rebuildBottomNav()
                showBanner("Workout saved to Calendar ($todayIso) & synced across all tabs!")
                renderActivePage()
            }
            .setNeutralButton("Finish & Share PDF") { _, _ ->
                persistFinishMeta()
                val allTodaySets = db.getCompletedSetsForDate(todayIso).ifEmpty { completedSets }
                shareSingleDayWorkoutPdf(todayIso, allTodaySets)
                renderActivePage()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showCustomRestSecondsDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = UiKit.dp(this@MainActivity, 16)
            setPadding(p, p, p, p)
        }
        box.addView(UiKit.text(this, "Enter Rest Time in Seconds (10 – 600s)", 12f, UiKit.COL_TEXT_MUTED, bold = true))
        box.addView(UiKit.spacerV(this, 6))
        val secIn = UiKit.inputBox(this, customRestDurationSec.toString(), "Seconds (e.g. 75, 105, 150)", InputType.TYPE_CLASS_NUMBER)
        box.addView(secIn)

        AlertDialog.Builder(this, UiKit.dialogTheme())
            .setTitle("Custom Vibration Rest Timer")
            .setView(box)
            .setPositiveButton("Start Timer") { _, _ ->
                val v = secIn.text.toString().toIntOrNull()?.coerceIn(10, 600) ?: customRestDurationSec
                startRestTimer(v, restExerciseLabel)
                renderActivePage()
            }
            .setNeutralButton("Save Default") { _, _ ->
                val v = secIn.text.toString().toIntOrNull()?.coerceIn(10, 600) ?: customRestDurationSec
                setPresetRestSeconds(v)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // =========================================================================
    // PAGE 3: WORKOUT CALENDAR + HISTORY & STREAKS + TEMPLATES + 7-DAY SCHEDULE
    // =========================================================================
    private fun renderWorkoutsPage() {
        val templates = db.getTemplates()
        val hist = db.getWorkoutHistoryAnalytics()
        val (subScroll, subRow) = UiKit.hScrollRow(this)
        subScroll.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = UiKit.rdp(this@MainActivity, 12)
        }
        subRow.addView(UiKit.chip(this, "Routines (${templates.size})", workoutsSubTab == "templates") {
            workoutsSubTab = "templates"; renderActivePage()
        })
        subRow.addView(UiKit.spacerH(this, 6))
        subRow.addView(UiKit.chip(this, "7-Day Split", workoutsSubTab == "schedule") {
            workoutsSubTab = "schedule"; renderActivePage()
        })
        subRow.addView(UiKit.spacerH(this, 6))
        subRow.addView(UiKit.chip(this, "Calendar", workoutsSubTab == "calendar") {
            workoutsSubTab = "calendar"; renderActivePage()
        })
        subRow.addView(UiKit.spacerH(this, 6))
        subRow.addView(UiKit.chip(this, "History (${hist.totalWorkoutsAllTime})", workoutsSubTab == "history") {
            workoutsSubTab = "history"; renderActivePage()
        })
        if (workoutsSubTab == "calendar" || workoutsSubTab == "history") {
            subRow.addView(UiKit.spacerH(this, 6))
            subRow.addView(UiKit.primaryButton(this, "+ Log Past Workout", UiKit.COL_ACCENT) {
                showLogPastWorkoutDialog(calendarSelectedDateIso)
            })
        } else if (workoutsSubTab == "templates") {
            subRow.addView(UiKit.spacerH(this, 6))
            subRow.addView(UiKit.primaryButton(this, "+ New Routine", UiKit.COL_ACCENT) {
                showTemplateStudioDialog(WorkoutTemplate(
                    "tpl_custom_${System.currentTimeMillis()}",
                    "Custom Hypertrophy Workout",
                    "Custom",
                    "Custom Split",
                    "Personalized offline hypertrophy template",
                    "[]",
                    System.currentTimeMillis()
                ))
            })
            subRow.addView(UiKit.spacerH(this, 6))
            subRow.addView(UiKit.outlineButton(this, if (isSyncingOnlineCatalog) "Syncing..." else "Refresh Online", UiKit.COL_ACCENT) {
                triggerOnlineCatalogSync()
            })
        }
        pageContent.addView(subScroll)

        if (workoutsSubTab == "calendar") {
            renderWorkoutCalendarSection()
        } else if (workoutsSubTab == "history") {
            renderWorkoutHistoryAndStreaksSection(hist)
        } else if (workoutsSubTab == "templates") {
            templates.forEach { tpl ->
                val items = tpl.parsedExercises()
                val totalSets = items.sumOf { it.sets }
                val cardKey = "tpl_${tpl.id}"
                val isExpanded = cardKey in expandedWorkoutCardIds

                val tCard = UiKit.card(this)
                val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                val hLeft = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                hLeft.addView(UiKit.text(this, "${tpl.splitType} · ${items.size} movements · $totalSets sets", 11f, UiKit.COL_ACCENT, bold = true, tabular = true))
                hLeft.addView(UiKit.text(this, tpl.name, 16f, UiKit.COL_TEXT_DARK, bold = true))
                head.addView(hLeft)
                tCard.addView(head)
                tCard.addView(UiKit.spacerV(this, 3))
                tCard.addView(UiKit.text(this, tpl.description, 12f, UiKit.COL_TEXT_MUTED))

                tCard.addView(UiKit.spacerV(this, 10))
                val (actScroll, actRow) = UiKit.hScrollRow(this)
                actRow.addView(UiKit.primaryButton(this, "Start Workout") {
                    if (items.isNotEmpty()) {
                        standaloneSession = db.startStandaloneTemplate(tpl, activeWeek)
                        startOrEnsureGlobalWorkoutTimer(tpl.name, playTone = true)
                        savePrefs()
                        activeTab = 0
                        rebuildTopSettingsButton()
                        rebuildBottomNav()
                        mainScroll.scrollTo(0, 0)
                        renderActivePage()
                    }
                })
                actRow.addView(UiKit.spacerH(this, 8))
                actRow.addView(UiKit.outlineButton(this, "Guide", UiKit.COL_ACCENT) {
                    showWorkoutHelpDialog(
                        workoutTitle = tpl.name,
                        subtitleSummary = "${tpl.splitType} · ${items.size} movements · $totalSets total sets",
                        exerciseSpecs = items.map {
                            Triple(it.name, it.primaryMuscle, "${it.sets} sets × ${it.reps} (${it.restSeconds}s rest)")
                        }
                    )
                })
                actRow.addView(UiKit.spacerH(this, 8))
                actRow.addView(UiKit.outlineButton(this, if (isExpanded) "Hide Details ▴" else "Schedule or Edit (${items.size}) ▾") {
                    if (isExpanded) expandedWorkoutCardIds.remove(cardKey) else expandedWorkoutCardIds.add(cardKey)
                    renderActivePage()
                })
                tCard.addView(actScroll)

                if (isExpanded) {
                    tCard.addView(UiKit.spacerV(this, 10))
                    items.forEachIndexed { idx, ex ->
                        tCard.addView(UiKit.text(this, "${idx + 1}. ${ex.name} — ${ex.sets} × ${ex.reps} (${ex.restSeconds}s)", 12f, UiKit.COL_TEXT_MID, tabular = true))
                    }
                    tCard.addView(UiKit.spacerV(this, 8))
                    val (secScroll, secRow) = UiKit.hScrollRow(this)
                    secRow.addView(UiKit.outlineButton(this, "Assign to Day") {
                        showAssignTemplateDialog(tpl)
                    })
                    secRow.addView(UiKit.spacerH(this, 8))
                    secRow.addView(UiKit.outlineButton(this, "Edit Routine") {
                        showTemplateStudioDialog(tpl)
                    })
                    secRow.addView(UiKit.spacerH(this, 8))
                    secRow.addView(UiKit.outlineButton(this, "Save Demos Offline", 0xFF059669.toInt()) {
                        val savedCount = OfflineVideoEngine.downloadTemplateExercisesOffline(this, db, tpl)
                        if (hapticEnabled) NativeHardwareBridge.hapticTick(this)
                        showBanner("✓ Saved $savedCount demo video(s) from '${tpl.name}' for offline viewing")
                        renderActivePage()
                    })
                    if (tpl.category == "Custom") {
                        secRow.addView(UiKit.spacerH(this, 8))
                        secRow.addView(UiKit.outlineButton(this, "Remove", 0xFFD97706.toInt()) {
                            db.deleteTemplate(tpl.id)
                            showBanner("Removed routine '${tpl.name}'")
                            renderActivePage()
                        })
                    }
                    tCard.addView(secScroll)
                }
                pageContent.addView(tCard)
            }
        } else {
            val allDayEx = db.getDayExercises()
            db.getWorkoutDays().forEach { day ->
                val dayExList = allDayEx.filter { it.dayNumber == day.dayNumber }
                val cardKey = "day_${day.dayNumber}"
                val isExpanded = cardKey in expandedWorkoutCardIds

                val dCard = UiKit.card(this)
                val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                val left = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                left.addView(UiKit.text(this, day.title, 15f, UiKit.COL_TEXT_DARK, bold = true))
                val sub = if (day.isRestDay) day.focusSummary else "${dayExList.size} exercises · ${day.focusSummary}"
                left.addView(UiKit.text(this, sub, 12f, UiKit.COL_TEXT_MUTED))
                head.addView(left)
                head.addView(UiKit.spacerH(this, 6))
                head.addView(UiKit.primaryButton(this, if (day.isRestDay) "Open" else "Track", UiKit.COL_ACCENT) {
                    standaloneSession = null
                    hasSelectedScheduleDay = true
                    activeDay = day.dayNumber
                    savePrefs()
                    db.ensureDaySetRowsMaterialized(activeWeek, activeDay)
                    if (!day.isRestDay) {
                        startOrEnsureGlobalWorkoutTimer(day.title, playTone = true)
                    }
                    activeTab = 0
                    rebuildTopSettingsButton()
                    rebuildBottomNav()
                    mainScroll.scrollTo(0, 0)
                    renderActivePage()
                })
                dCard.addView(head)

                if (!day.isRestDay || dayExList.isNotEmpty()) {
                    dCard.addView(UiKit.spacerV(this, 8))
                    val (actScroll, actionsRow) = UiKit.hScrollRow(this)
                    actionsRow.addView(UiKit.outlineButton(this, "? Help", UiKit.COL_ACCENT) {
                        showWorkoutHelpDialog(
                            workoutTitle = day.title,
                            subtitleSummary = "${dayExList.size} exercises · ${day.focusSummary}",
                            exerciseSpecs = dayExList.map {
                                Triple(it.name, it.muscleId, "${it.setsForWeek(activeWeek)} sets × ${it.repRange} (${it.restSeconds}s rest)")
                            }
                        )
                    })
                    actionsRow.addView(UiKit.spacerH(this, 8))
                    actionsRow.addView(UiKit.outlineButton(this, if (isExpanded) "Hide Exercises ▴" else "Exercises (${dayExList.size}) ▾") {
                        if (isExpanded) expandedWorkoutCardIds.remove(cardKey) else expandedWorkoutCardIds.add(cardKey)
                        renderActivePage()
                    })
                    actionsRow.addView(UiKit.spacerH(this, 8))
                    actionsRow.addView(UiKit.outlineButton(this, "+ Add Exercise", UiKit.COL_ACCENT) {
                        expandedWorkoutCardIds.add(cardKey)
                        showExercisePickerDialog { picked ->
                            db.appendExerciseToScheduleDay(day.dayNumber, picked, activeWeek)
                            HyperLogStreakWidgetProvider.refreshAllWidgets(this)
                            showBanner("Added '${picked.name}' to Day ${day.dayNumber}")
                            renderActivePage()
                        }
                    })
                    dCard.addView(actScroll)
                } else {
                    dCard.addView(UiKit.spacerV(this, 8))
                    dCard.addView(UiKit.outlineButton(this, "+ Add Exercise to Day ${day.dayNumber}") {
                        expandedWorkoutCardIds.add(cardKey)
                        showExercisePickerDialog { picked ->
                            db.appendExerciseToScheduleDay(day.dayNumber, picked, activeWeek)
                            HyperLogStreakWidgetProvider.refreshAllWidgets(this)
                            showBanner("Added '${picked.name}' to Day ${day.dayNumber}")
                            renderActivePage()
                        }
                    })
                }

                if (isExpanded && dayExList.isNotEmpty()) {
                    dCard.addView(UiKit.spacerV(this, 8))
                    dayExList.forEach { ex ->
                        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                        r.addView(UiKit.text(this, "• ${ex.name} (${ex.setsForWeek(activeWeek)}×${ex.repRange}, ${ex.restSeconds}s)", 12f, UiKit.COL_TEXT_MID, tabular = true).apply {
                            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                        })
                        r.addView(UiKit.text(this, "✕", 13f, UiKit.COL_TEXT_MUTED, bold = true).apply {
                            val px = UiKit.dp(this@MainActivity, 8)
                            setPadding(px, px, px, px)
                            setOnClickListener {
                                db.removeDayExercise(ex.id)
                                HyperLogStreakWidgetProvider.refreshAllWidgets(this@MainActivity)
                                renderActivePage()
                            }
                        })
                        dCard.addView(r)
                    }
                }
                pageContent.addView(dCard)
            }
        }
    }

    private fun renderWorkoutCalendarSection() {
        val setsByDate = db.getCompletedSetsByDateDesc()
        val notesMap = db.getWorkoutDayNotesMap()
        val landmarks = db.getLandmarks()
        val today = LocalDate.now()
        val todayIso = today.toString()

        val ym = YearMonth.of(calendarYear, calendarMonth)
        val monthPrefix = String.format(Locale.US, "%04d-%02d-", calendarYear, calendarMonth)
        val monthEntries = setsByDate.filterKeys { it.startsWith(monthPrefix) }
        val monthWorkoutDays = monthEntries.size
        val monthTotalSets = monthEntries.values.sumOf { it.size }

        val calCard = UiKit.card(this, padDp = 13)

        // Month Header Row
        val navRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        navRow.addView(UiKit.outlineButton(this, "◀") {
            val prev = ym.minusMonths(1)
            calendarYear = prev.year
            calendarMonth = prev.monthValue
            renderActivePage()
        }.apply {
            val px = UiKit.rdp(this@MainActivity, 10)
            val py = UiKit.rdp(this@MainActivity, 6)
            setPadding(px, py, px, py)
        })
        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val monthLabel = "${ym.month.getDisplayName(TextStyle.FULL, Locale.US)} $calendarYear"
        titleCol.addView(UiKit.text(this, monthLabel, 15.5f, UiKit.COL_TEXT_DARK, bold = true).apply {
            gravity = Gravity.CENTER
        })
        titleCol.addView(UiKit.text(this, "$monthWorkoutDays workout days · $monthTotalSets sets", 11f, UiKit.COL_TEXT_MUTED, tabular = true).apply {
            gravity = Gravity.CENTER
        })
        navRow.addView(titleCol)

        if (calendarYear != today.year || calendarMonth != today.monthValue || calendarSelectedDateIso != todayIso) {
            navRow.addView(UiKit.chip(this, "Today", false) {
                calendarYear = today.year
                calendarMonth = today.monthValue
                calendarSelectedDateIso = todayIso
                renderActivePage()
            }.apply {
                val px = UiKit.rdp(this@MainActivity, 8)
                val py = UiKit.rdp(this@MainActivity, 6)
                setPadding(px, py, px, py)
            })
            navRow.addView(UiKit.spacerH(this, 5))
        }

        navRow.addView(UiKit.outlineButton(this, "▶") {
            val nxt = ym.plusMonths(1)
            calendarYear = nxt.year
            calendarMonth = nxt.monthValue
            renderActivePage()
        }.apply {
            val px = UiKit.rdp(this@MainActivity, 10)
            val py = UiKit.rdp(this@MainActivity, 6)
            setPadding(px, py, px, py)
        })
        calCard.addView(navRow)
        calCard.addView(UiKit.spacerV(this, 10))

        // Weekday Labels (Sun..Sat)
        val wkHeader = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat").forEach { wd ->
            wkHeader.addView(UiKit.text(this, wd, 10.5f, UiKit.COL_TEXT_MUTED, bold = true).apply {
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
        }
        calCard.addView(wkHeader)
        calCard.addView(UiKit.spacerV(this, 5))

        // Calendar Day Cells
        val firstDayOffset = ym.atDay(1).dayOfWeek.value % 7 // Sunday=0 .. Saturday=6
        val totalDaysInMonth = ym.lengthOfMonth()
        val totalSlots = ((firstDayOffset + totalDaysInMonth + 6) / 7) * 7

        var rowLinear: LinearLayout? = null
        for (slot in 0 until totalSlots) {
            if (slot % 7 == 0) {
                rowLinear = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                        bottomMargin = UiKit.rdp(this@MainActivity, 4)
                    }
                }
                calCard.addView(rowLinear)
            }
            val dayNum = slot - firstDayOffset + 1
            if (dayNum < 1 || dayNum > totalDaysInMonth) {
                rowLinear?.addView(View(this).apply {
                    layoutParams = LinearLayout.LayoutParams(0, UiKit.rdp(this@MainActivity, 48), 1f).apply {
                        if (slot % 7 < 6) rightMargin = UiKit.rdp(this@MainActivity, 4)
                    }
                })
            } else {
                val cellIso = ym.atDay(dayNum).toString()
                val daySets = setsByDate[cellIso].orEmpty()
                val hasWorkout = daySets.isNotEmpty()
                val isSelected = cellIso == calendarSelectedDateIso
                val isToday = cellIso == todayIso

                val bgCol = when {
                    isSelected && hasWorkout -> 0xFF059669.toInt()
                    isSelected -> UiKit.COL_CHIP_ACTIVE_BG
                    hasWorkout -> if (UiKit.isDark) 0xFF064E3B.toInt() else 0xFFD1FAE5.toInt()
                    else -> UiKit.COL_SUBTLE
                }
                val strokeCol = when {
                    isSelected && hasWorkout -> 0xFF10B981.toInt()
                    isSelected -> UiKit.COL_ACCENT
                    hasWorkout -> 0xFF10B981.toInt()
                    isToday -> UiKit.COL_ACCENT
                    else -> UiKit.COL_BORDER
                }
                val numCol = when {
                    isSelected -> UiKit.COL_PURE_WHITE
                    hasWorkout -> if (UiKit.isDark) 0xFFECFDF5.toInt() else 0xFF064E3B.toInt()
                    else -> UiKit.COL_TEXT_DARK
                }
                val subCol = when {
                    isSelected -> 0xFFE2E8F0.toInt()
                    hasWorkout -> if (UiKit.isDark) 0xFF6EE7B7.toInt() else 0xFF047857.toInt()
                    isToday -> UiKit.COL_ACCENT
                    else -> UiKit.COL_TEXT_MUTED
                }

                val cellBox = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER_HORIZONTAL
                    background = UiKit.roundedBg(bgCol, 10f, this@MainActivity, strokeCol, if (isSelected || hasWorkout || isToday) 1.4f else 1f)
                    val p = UiKit.rdp(this@MainActivity, 4)
                    setPadding(p, p, p, p)
                    minimumHeight = UiKit.rdp(this@MainActivity, 48)
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                        if (slot % 7 < 6) rightMargin = UiKit.rdp(this@MainActivity, 4)
                    }
                    setOnClickListener {
                        calendarSelectedDateIso = cellIso
                        if (hapticEnabled) NativeHardwareBridge.hapticTick(this@MainActivity)
                        renderActivePage()
                    }
                }
                val topNumLabel = if (hasWorkout) "$dayNum ✓" else dayNum.toString()
                cellBox.addView(UiKit.text(this, topNumLabel, 11f, numCol, bold = true, tabular = true).apply {
                    gravity = Gravity.CENTER
                    maxLines = 1
                })
                val bottomTxt = when {
                    hasWorkout -> "${daySets.size}s"
                    isToday -> "Today"
                    else -> " "
                }
                cellBox.addView(UiKit.text(this, bottomTxt, 9.5f, subCol, bold = hasWorkout || isToday, tabular = true).apply {
                    gravity = Gravity.CENTER
                    maxLines = 1
                })
                rowLinear?.addView(cellBox)
            }
        }

        calCard.addView(UiKit.spacerV(this, 4))
        calCard.addView(UiKit.text(this, "✓ Emerald dates mark completed workouts · Tap any date to inspect or share that day's PDF", 11f, UiKit.COL_TEXT_MUTED))
        pageContent.addView(calCard)

        // Selected Date Inspector Card (Strictly for the selected day ONLY)
        val selectedSets = setsByDate[calendarSelectedDateIso].orEmpty()
        val selectedNote = notesMap[calendarSelectedDateIso]
        val humanSelected = try {
            LocalDate.parse(calendarSelectedDateIso).format(DateTimeFormatter.ofPattern("EEEE, MMM d, yyyy", Locale.US))
        } catch (_: Exception) {
            calendarSelectedDateIso
        }

        val dayCard = UiKit.card(this, padDp = 14)
        val dayHead = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val dayHeadLeft = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        dayHeadLeft.addView(UiKit.text(this, if (calendarSelectedDateIso == todayIso) "Today · $calendarSelectedDateIso" else calendarSelectedDateIso, 11f, UiKit.COL_ACCENT, bold = true, tabular = true))
        dayHeadLeft.addView(UiKit.text(this, humanSelected, 16f, UiKit.COL_TEXT_DARK, bold = true))
        dayHead.addView(dayHeadLeft)
        dayHead.addView(UiKit.outlineButton(this, "+ Log Manual") {
            showLogPastWorkoutDialog(calendarSelectedDateIso)
        })
        dayCard.addView(dayHead)

        if (selectedSets.isEmpty()) {
            dayCard.addView(UiKit.spacerV(this, 8))
            dayCard.addView(UiKit.text(
                this,
                "No completed workout sets recorded on this date. Forgot your phone during training? Tap '+ Log Manual' above to enter past exercises, duration, and sets.",
                12f,
                UiKit.COL_TEXT_MUTED
            ))
        } else {
            val sessionTitle = selectedNote?.title?.takeIf { it.isNotBlank() }
                ?: selectedSets.firstOrNull()?.let { s ->
                    if (s.dayNumber > 0) "Week ${s.week} · Day ${s.dayNumber} Workout" else "Logged Workout Session"
                } ?: "Workout Session"
            val groupedEx = selectedSets.groupBy { it.exerciseName }
            val totalTonnageKg = selectedSets.sumOf { it.weightKg * it.reps }
            val dispVol = if (weightUnit == "lb") "${(totalTonnageKg * 2.20462).roundToInt()} lb" else "${totalTonnageKg.roundToInt()} kg"
            val sessionDurMin = selectedNote?.durationMinutes?.takeIf { it > 0 } ?: (selectedSets.size * 3 + 12).coerceIn(15, 120)

            dayCard.addView(UiKit.spacerV(this, 6))
            val sessionTitleRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            sessionTitleRow.addView(UiKit.text(this, "$sessionTitle · ${sessionDurMin} min", 14f, UiKit.COL_TEXT_DARK, bold = true, tabular = true).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            sessionTitleRow.addView(UiKit.outlineButton(this, "Delete Session", 0xFFEF4444.toInt()) {
                confirmDeleteWorkoutSessionDialog(calendarSelectedDateIso, sessionTitle, selectedSets.size)
            })
            dayCard.addView(sessionTitleRow)
            dayCard.addView(UiKit.spacerV(this, 8))

            // Single-Day PDF Share, Save & Track Again Row (strictly for this selected date)
            val pdfRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            pdfRow.addView(UiKit.primaryButton(this, "Track Again", 0xFF059669.toInt()) {
                standaloneSession = db.repeatDateWorkoutSession(sessionTitle, selectedSets, activeWeek)
                savePrefs()
                activeTab = 0
                rebuildTopSettingsButton()
                rebuildBottomNav()
                mainScroll.scrollTo(0, 0)
                showBanner("Loaded '$sessionTitle' into Track")
                renderActivePage()
            }.apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    rightMargin = UiKit.rdp(this@MainActivity, 5)
                }
            })
            pdfRow.addView(UiKit.primaryButton(this, "Share PDF", UiKit.COL_ACCENT) {
                shareSingleDayWorkoutPdf(calendarSelectedDateIso, selectedSets)
            }.apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    rightMargin = UiKit.rdp(this@MainActivity, 5)
                }
            })
            pdfRow.addView(UiKit.outlineButton(this, "Save PDF", UiKit.COL_ACCENT) {
                saveSingleDayWorkoutPdfToDevice(calendarSelectedDateIso, selectedSets)
            }.apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.9f)
            })
            dayCard.addView(pdfRow)
            dayCard.addView(UiKit.spacerV(this, 10))

            // 4 Summary KPI Boxes for this day (including Duration)
            val kpiRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            listOf(
                "EXERCISES" to groupedEx.size.toString(),
                "SETS" to selectedSets.size.toString(),
                "DURATION" to "${sessionDurMin}m",
                "VOLUME" to dispVol
            ).forEachIndexed { idx, (lbl, v) ->
                kpiRow.addView(UiKit.metricBox(this, lbl, v).apply {
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                        if (idx < 3) rightMargin = UiKit.rdp(this@MainActivity, 5)
                    }
                })
            }
            dayCard.addView(kpiRow)
            dayCard.addView(UiKit.spacerV(this, 10))

            // Session Notes Line + Edit Button
            val noteRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val noteSummary = if (!selectedNote?.notes.isNullOrBlank()) "Note: ${selectedNote!!.notes}" else "No session notes added for this day."
            noteRow.addView(UiKit.text(this, noteSummary, 11.5f, UiKit.COL_TEXT_MUTED).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            noteRow.addView(UiKit.spacerH(this, 6))
            noteRow.addView(UiKit.outlineButton(this, "Notes") {
                showEditDayNoteDialog(calendarSelectedDateIso, sessionTitle, selectedNote)
            })
            dayCard.addView(noteRow)
            dayCard.addView(UiKit.spacerV(this, 10))

            // Exercise-by-Exercise Breakdown with per-exercise Delete Mistake control
            groupedEx.entries.forEachIndexed { exIdx, (exName, rows) ->
                val mName = landmarks[rows.first().muscleId]?.shortName ?: rows.first().muscleId
                val exBox = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    background = UiKit.roundedBg(UiKit.COL_SUBTLE, 10f, this@MainActivity, UiKit.COL_BORDER, 1f)
                    val p = UiKit.rdp(this@MainActivity, 10)
                    setPadding(p, p, p, p)
                    layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                        if (exIdx < groupedEx.size - 1) bottomMargin = UiKit.rdp(this@MainActivity, 7)
                    }
                }
                val exHeadRow = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                }
                exHeadRow.addView(UiKit.text(this, "${exIdx + 1}. $exName · $mName", 13f, UiKit.COL_TEXT_DARK, bold = true).apply {
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                })
                exHeadRow.addView(UiKit.text(this, "✕ Delete", 11f, 0xFFEF4444.toInt(), bold = true).apply {
                    val px = UiKit.dp(this@MainActivity, 6)
                    val py = UiKit.dp(this@MainActivity, 4)
                    setPadding(px, py, px, py)
                    setOnClickListener {
                        AlertDialog.Builder(this@MainActivity, UiKit.dialogTheme())
                            .setTitle("Delete Exercise Entry?")
                            .setMessage("Remove ${rows.size} logged set(s) of '$exName' on $calendarSelectedDateIso? Use this if an exercise was entered by mistake.")
                            .setPositiveButton("Delete Exercise") { _, _ ->
                                val removed = db.deleteExerciseLogsForDate(calendarSelectedDateIso, exName)
                                HyperLogStorageManager.saveDatabaseSnapshotAsync(this@MainActivity, db)
                                if (hapticEnabled) NativeHardwareBridge.hapticTick(this@MainActivity)
                                showBanner("Deleted $removed mistaken set(s) of '$exName' ($calendarSelectedDateIso)")
                                renderActivePage()
                            }
                            .setNegativeButton("Cancel", null)
                            .show()
                    }
                })
                exBox.addView(exHeadRow)
                exBox.addView(UiKit.spacerV(this, 4))
                rows.sortedBy { it.setIndex }.forEachIndexed { sIdx, s ->
                    val wVal = if (weightUnit == "lb") ((s.weightKg * 2.20462 * 10.0).roundToInt() / 10.0) else ((s.weightKg * 10.0).roundToInt() / 10.0)
                    val wClean = if (wVal % 1.0 == 0.0) wVal.toInt().toString() else String.format(Locale.US, "%.1f", wVal)
                    val rpeSuffix = s.rpe?.let { r ->
                        if (r % 1.0 == 0.0) " · RPE ${r.toInt()}" else String.format(Locale.US, " · RPE %.1f", r)
                    } ?: ""
                    exBox.addView(UiKit.text(
                        this,
                        "Set #${sIdx + 1}: $wClean $weightUnit × ${s.reps} reps @ ${formatRirShort(s.rir)}$rpeSuffix",
                        11.5f,
                        UiKit.COL_TEXT_MID,
                        tabular = true
                    ))
                }
                dayCard.addView(exBox)
            }
        }

        pageContent.addView(dayCard)
    }

    private fun confirmDeleteWorkoutSessionDialog(dateIso: String, sessionTitle: String, setsCount: Int) {
        AlertDialog.Builder(this, UiKit.dialogTheme())
            .setTitle("Delete Workout Record?")
            .setMessage("Delete '$sessionTitle' ($setsCount sets) on $dateIso? Your workout history and streak counter will recalculate immediately.")
            .setPositiveButton("Delete Workout") { _, _ ->
                val removed = db.deleteWorkoutSessionForDate(dateIso)
                HyperLogStorageManager.saveDatabaseSnapshotAsync(this, db)
                if (hapticEnabled) NativeHardwareBridge.hapticTick(this)
                showBanner("Deleted workout ($removed sets) on $dateIso — streaks updated.")
                renderActivePage()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun renderWorkoutHistoryAndStreaksSection(hist: WorkoutHistoryAnalytics) {
        val activeAcc = HyperLogDatabase.getActiveAccount(this)
        val streakCard = UiKit.card(this, borderColor = UiKit.COL_ACCENT, borderDp = 1.4f, padDp = 14)
        streakCard.addView(UiKit.text(this, "Workout Streak & Consistency (${activeAcc.displayName})", 16f, UiKit.COL_TEXT_DARK, bold = true))
        streakCard.addView(UiKit.text(
            this,
            "Tracks pure workout consistency, weekly training frequency, and session durations for your active profile.",
            11.5f,
            UiKit.COL_TEXT_MUTED
        ))
        streakCard.addView(UiKit.spacerV(this, 10))

        val rowA = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(
            Triple("CURRENT STREAK", "🔥 ${hist.currentWorkoutStreakDays}d", UiKit.COL_FLAME_ORANGE),
            Triple("BEST STREAK", "${hist.bestWorkoutStreakDays}d", UiKit.COL_ACCENT),
            Triple("FREQUENCY", "${hist.avgWorkoutsPerWeek}/wk", 0xFF059669.toInt())
        ).forEachIndexed { idx, (lbl, v, col) ->
            rowA.addView(UiKit.metricBox(this, lbl, v, col).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    if (idx < 2) rightMargin = UiKit.rdp(this@MainActivity, 6)
                }
            })
        }
        streakCard.addView(rowA)
        streakCard.addView(UiKit.spacerV(this, 6))

        val rowB = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(
            "7D / 30D SESSIONS" to "${hist.workoutsLast7Days} / ${hist.workoutsLast30Days}",
            "AVG DURATION" to "${hist.avgDurationMinutes} min",
            "TOTAL TIME" to "${hist.totalDurationMinutes} min"
        ).forEachIndexed { idx, (lbl, v) ->
            rowB.addView(UiKit.metricBox(this, lbl, v).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    if (idx < 2) rightMargin = UiKit.rdp(this@MainActivity, 6)
                }
            })
        }
        streakCard.addView(rowB)
        streakCard.addView(UiKit.spacerV(this, 12))

        // 14-Day Visual Consistency Strip
        streakCard.addView(UiKit.text(this, "14-Day Workout Consistency Strip (Tap any day to inspect or log)", 11.5f, UiKit.COL_TEXT_DARK, bold = true))
        streakCard.addView(UiKit.spacerV(this, 6))
        val (stripScroll, stripRow) = UiKit.hScrollRow(this)
        val todayIso = LocalDate.now().toString()
        hist.last14DaysConsistency.forEachIndexed { idx, (dIso, dayLbl, done) ->
            val isToday = dIso == todayIso
            val bg = when {
                done && isToday -> UiKit.COL_FLAME_ORANGE
                done -> 0xFF059669.toInt()
                else -> UiKit.COL_SUBTLE
            }
            val fg = if (done) UiKit.COL_PURE_WHITE else UiKit.COL_TEXT_MUTED
            val dayNum = dIso.takeLast(2).trimStart('0').ifEmpty { dIso.takeLast(2) }
            val pill = UiKit.text(
                this,
                if (done) "$dayLbl\n$dayNum ✓" else "$dayLbl\n$dayNum",
                10.5f,
                fg,
                bold = true,
                tabular = true
            ).apply {
                gravity = Gravity.CENTER
                background = UiKit.roundedBg(bg, 9f, this@MainActivity, if (isToday && !done) UiKit.COL_ACCENT else UiKit.COL_BORDER, 1f)
                val px = UiKit.rdp(this@MainActivity, 9)
                val py = UiKit.rdp(this@MainActivity, 6)
                setPadding(px, py, px, py)
                minimumWidth = UiKit.rdp(this@MainActivity, 44)
                UiKit.attachInstantPressFeedback(this)
                setOnClickListener {
                    val parsed = runCatching { LocalDate.parse(dIso) }.getOrDefault(LocalDate.now())
                    calendarYear = parsed.year
                    calendarMonth = parsed.monthValue
                    calendarSelectedDateIso = dIso
                    workoutsSubTab = "calendar"
                    renderActivePage()
                }
            }
            stripRow.addView(pill)
            if (idx < hist.last14DaysConsistency.lastIndex) stripRow.addView(UiKit.spacerH(this, 5))
        }
        streakCard.addView(stripScroll)
        streakCard.addView(UiKit.spacerV(this, 10))

        val ctaRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        ctaRow.addView(UiKit.primaryButton(this, "+ Log Missed / Phone-Free Workout", UiKit.COL_ACCENT) {
            showLogPastWorkoutDialog(LocalDate.now().toString())
        }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.35f).apply {
                rightMargin = UiKit.rdp(this@MainActivity, 6)
            }
        })
        ctaRow.addView(UiKit.outlineButton(this, "Export CSV") {
            triggerExportCsv()
        }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.65f)
        })
        streakCard.addView(ctaRow)
        pageContent.addView(streakCard)

        val setsByDate = db.getCompletedSetsByDateDesc()
        val notesMap = db.getWorkoutDayNotesMap()
        if (setsByDate.isEmpty()) {
            val emptyCard = UiKit.card(this, padDp = 14)
            emptyCard.addView(UiKit.text(this, "Fresh Workout Log — Zero Sessions Recorded Yet", 15f, UiKit.COL_TEXT_DARK, bold = true))
            emptyCard.addView(UiKit.spacerV(this, 4))
            emptyCard.addView(UiKit.text(
                this,
                "Your '${activeAcc.displayName}' profile is 100% clean with zero inherited data. Complete a workout in Track or tap '+ Log Missed / Phone-Free Workout' above to start your streak!",
                12f,
                UiKit.COL_TEXT_MUTED
            ))
            pageContent.addView(emptyCard)
            return
        }

        setsByDate.entries.forEach { (dIso, daySets) ->
            val note = notesMap[dIso]
            val title = note?.title?.takeIf { it.isNotBlank() }
                ?: daySets.firstOrNull()?.let { if (it.dayNumber > 0) "Week ${it.week} · Day ${it.dayNumber} Workout" else "Logged Workout Session" }
                ?: "Workout Session"
            val durMin = note?.durationMinutes?.takeIf { it > 0 } ?: (daySets.size * 3 + 12).coerceIn(15, 120)
            val groupedEx = daySets.groupBy { it.exerciseName }
            val tonKg = daySets.sumOf { it.weightKg * it.reps }
            val dispVol = if (weightUnit == "lb") "${(tonKg * 2.20462).roundToInt()} lb" else "${tonKg.roundToInt()} kg"

            val hCard = UiKit.card(this, padDp = 13)
            val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val left = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            left.addView(UiKit.text(this, "$dIso · ${durMin} min · ${groupedEx.size} exercises · ${daySets.size} sets · $dispVol", 11f, UiKit.COL_ACCENT, bold = true, tabular = true))
            left.addView(UiKit.text(this, title, 15f, UiKit.COL_TEXT_DARK, bold = true))
            top.addView(left)
            hCard.addView(top)
            hCard.addView(UiKit.spacerV(this, 6))

            groupedEx.entries.take(5).forEach { (exName, rows) ->
                val topW = rows.maxOf { it.weightKg }
                val wDisp = formatWeightForInput(topW)
                val bestReps = rows.maxOf { it.reps }
                hCard.addView(UiKit.text(
                    this,
                    "• $exName — ${rows.size} sets (top $wDisp $weightUnit × $bestReps)",
                    11.5f,
                    UiKit.COL_TEXT_MID,
                    tabular = true
                ))
            }
            if (groupedEx.size > 5) {
                hCard.addView(UiKit.text(this, "+ ${groupedEx.size - 5} more exercise(s)", 11f, UiKit.COL_TEXT_MUTED))
            }
            if (!note?.notes.isNullOrBlank()) {
                hCard.addView(UiKit.spacerV(this, 4))
                hCard.addView(UiKit.text(this, "Note: ${note!!.notes}", 11f, UiKit.COL_TEXT_MUTED))
            }
            hCard.addView(UiKit.spacerV(this, 8))

            val actRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            actRow.addView(UiKit.outlineButton(this, "Inspect / Edit", UiKit.COL_ACCENT) {
                val parsed = runCatching { LocalDate.parse(dIso) }.getOrDefault(LocalDate.now())
                calendarYear = parsed.year
                calendarMonth = parsed.monthValue
                calendarSelectedDateIso = dIso
                workoutsSubTab = "calendar"
                renderActivePage()
            }.apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    rightMargin = UiKit.rdp(this@MainActivity, 6)
                }
            })
            actRow.addView(UiKit.outlineButton(this, "Repeat", 0xFF059669.toInt()) {
                standaloneSession = db.repeatDateWorkoutSession(title, daySets, activeWeek)
                savePrefs()
                activeTab = 0
                rebuildTopSettingsButton()
                rebuildBottomNav()
                mainScroll.scrollTo(0, 0)
                showBanner("Loaded '$title' into Track")
                renderActivePage()
            }.apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.85f).apply {
                    rightMargin = UiKit.rdp(this@MainActivity, 6)
                }
            })
            actRow.addView(UiKit.outlineButton(this, "Delete", 0xFFEF4444.toInt()) {
                confirmDeleteWorkoutSessionDialog(dIso, title, daySets.size)
            }.apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.8f)
            })
            hCard.addView(actRow)
            pageContent.addView(hCard)
        }
    }

    private fun shareSingleDayWorkoutPdf(dateIso: String, daySets: List<SetLog>) {
        if (daySets.isEmpty()) {
            showBanner("No completed workout sets on $dateIso to export.")
            return
        }
        try {
            val file = WorkoutPdfExporter.generateSingleDayPdf(
                context = this,
                dateIso = dateIso,
                sets = daySets,
                dayNote = db.getWorkoutDayNotesMap()[dateIso],
                meals = db.getMealsForDate(dateIso),
                landmarks = db.getLandmarks(),
                weightUnit = weightUnit
            )
            val launched = WorkoutPdfExporter.shareExportFile(
                activity = this,
                file = file,
                mimeType = "application/pdf",
                chooserTitle = "Share $dateIso Workout PDF",
                subject = "HyperLog Workout Report ($dateIso)"
            )
            if (!launched) {
                saveSingleDayWorkoutPdfToDevice(dateIso, daySets)
            }
        } catch (e: Exception) {
            showBanner("PDF generation failed: ${e.message}")
        }
    }

    private fun saveSingleDayWorkoutPdfToDevice(dateIso: String, daySets: List<SetLog>) {
        if (daySets.isEmpty()) {
            showBanner("No completed workout sets on $dateIso to save.")
            return
        }
        try {
            val file = WorkoutPdfExporter.generateSingleDayPdf(
                context = this,
                dateIso = dateIso,
                sets = daySets,
                dayNote = db.getWorkoutDayNotesMap()[dateIso],
                meals = db.getMealsForDate(dateIso),
                landmarks = db.getLandmarks(),
                weightUnit = weightUnit
            )
            pendingExportSourceFile = file
            val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "application/pdf"
                putExtra(Intent.EXTRA_TITLE, file.name)
            }
            startActivityForResult(intent, REQ_SAVE_PDF)
        } catch (e: Exception) {
            showBanner("Save PDF unavailable: ${e.message}")
        }
    }

    private fun showEditDayNoteDialog(dateIso: String, fallbackTitle: String, current: WorkoutDayNote?) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = UiKit.dp(this@MainActivity, 16)
            setPadding(p, p, p, p)
        }
        val titleIn = UiKit.inputBox(this, current?.title ?: fallbackTitle, "Session Title", InputType.TYPE_CLASS_TEXT)
        val durIn = UiKit.inputBox(this, (current?.durationMinutes?.takeIf { it > 0 } ?: 55).toString(), "Duration (minutes)", InputType.TYPE_CLASS_NUMBER)
        val notesIn = UiKit.inputBox(this, current?.notes ?: "", "Session notes (pump, energy, cues...)", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE)

        box.addView(UiKit.text(this, "Workout Title ($dateIso)", 11f, UiKit.COL_TEXT_MUTED, bold = true))
        box.addView(titleIn)
        box.addView(UiKit.spacerV(this, 6))
        box.addView(UiKit.text(this, "Duration (min)", 11f, UiKit.COL_TEXT_MUTED, bold = true))
        box.addView(durIn)
        box.addView(UiKit.spacerV(this, 6))
        box.addView(UiKit.text(this, "Session Notes", 11f, UiKit.COL_TEXT_MUTED, bold = true))
        box.addView(notesIn)

        AlertDialog.Builder(this, UiKit.dialogTheme())
            .setTitle("Edit Day Notes ($dateIso)")
            .setView(box)
            .setPositiveButton("Save") { _, _ ->
                db.saveWorkoutDayNote(
                    WorkoutDayNote(
                        dateIso = dateIso,
                        title = titleIn.text.toString().trim().ifBlank { fallbackTitle },
                        durationMinutes = durIn.text.toString().toIntOrNull()?.coerceIn(5, 300) ?: 55,
                        notes = notesIn.text.toString().trim()
                    )
                )
                showBanner("Saved workout notes for $dateIso")
                renderActivePage()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private data class ManualExerciseDraft(
        var exercise: LibraryExercise,
        var setsText: String,
        var weightText: String,
        var repsText: String
    )

    /**
     * Multi-Exercise Manual Workout Entry Dialog:
     * Designed for athletes who forgot their phone during a gym session. Allows picking any date,
     * entering session title, duration, notes, and logging multiple exercises in one save!
     */
    private fun showLogPastWorkoutDialog(initialDateIso: String) {
        val lib = db.getLibraryExercises()
        val firstEx = lib.firstOrNull() ?: return
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = UiKit.dp(this@MainActivity, 16)
            setPadding(p, p, p, p)
        }
        scroll.addView(box)

        val dateIn = UiKit.inputBox(this, initialDateIso, "YYYY-MM-DD", InputType.TYPE_CLASS_DATETIME)
        val (dateChipScroll, dateChipRow) = UiKit.hScrollRow(this)
        val today = LocalDate.now()
        listOf(
            "Today" to today.toString(),
            "Yesterday" to today.minusDays(1).toString(),
            "2d Ago" to today.minusDays(2).toString(),
            "3d Ago" to today.minusDays(3).toString()
        ).forEachIndexed { idx, (lbl, dIso) ->
            dateChipRow.addView(UiKit.chip(this, lbl, dIso == initialDateIso) {
                dateIn.setText(dIso)
            })
            if (idx < 3) dateChipRow.addView(UiKit.spacerH(this, 6))
        }

        val titleIn = UiKit.inputBox(this, "Manual Gym Session", "Session Title (e.g. Upper Push)", InputType.TYPE_CLASS_TEXT)
        val durIn = UiKit.inputBox(this, "50", "Duration (minutes)", InputType.TYPE_CLASS_NUMBER)
        val rpeIn = UiKit.inputBox(this, "8.5", "Avg RPE (optional, 6–10)", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        val notesIn = UiKit.inputBox(this, "", "Optional notes (e.g. Forgot phone at home)", InputType.TYPE_CLASS_TEXT)

        fun defaultWeightDisp(ex: LibraryExercise): String {
            return if (weightUnit == "lb") {
                ((ex.defaultWeightKg * 2.20462 * 10.0).roundToInt() / 10.0).toString()
            } else {
                ex.defaultWeightKg.toString()
            }
        }

        val drafts = mutableListOf(
            ManualExerciseDraft(firstEx, "3", defaultWeightDisp(firstEx), "10")
        )
        val draftsWrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        fun rebuildDraftsUi() {
            draftsWrap.removeAllViews()
            drafts.forEachIndexed { idx, draft ->
                val dCard = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    background = UiKit.roundedBg(UiKit.COL_SUBTLE, 10f, this@MainActivity, UiKit.COL_BORDER, 1f)
                    val p = UiKit.rdp(this@MainActivity, 10)
                    setPadding(p, p, p, p)
                    layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                        bottomMargin = UiKit.rdp(this@MainActivity, 8)
                    }
                }
                val topRow = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                }
                val pickBtn = UiKit.outlineButton(this, "${idx + 1}. ${draft.exercise.name} ▾", UiKit.COL_ACCENT) {
                    showExercisePickerDialog { picked ->
                        draft.exercise = picked
                        draft.weightText = defaultWeightDisp(picked)
                        rebuildDraftsUi()
                    }
                }.apply {
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                topRow.addView(pickBtn)
                if (drafts.size > 1) {
                    topRow.addView(UiKit.spacerH(this, 6))
                    topRow.addView(UiKit.outlineButton(this, "✕", 0xFFEF4444.toInt()) {
                        drafts.removeAt(idx)
                        rebuildDraftsUi()
                    })
                }
                dCard.addView(topRow)
                dCard.addView(UiKit.spacerV(this, 6))

                val sIn = UiKit.inputBox(this, draft.setsText, "Sets", InputType.TYPE_CLASS_NUMBER).apply {
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    addTextChangedListener(object : TextWatcher {
                        override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                        override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                        override fun afterTextChanged(s: Editable?) { draft.setsText = s?.toString() ?: "3" }
                    })
                }
                val wIn = UiKit.inputBox(this, draft.weightText, weightUnit, InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL).apply {
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    addTextChangedListener(object : TextWatcher {
                        override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                        override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                        override fun afterTextChanged(s: Editable?) { draft.weightText = s?.toString() ?: "0" }
                    })
                }
                val rIn = UiKit.inputBox(this, draft.repsText, "Reps", InputType.TYPE_CLASS_NUMBER).apply {
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    addTextChangedListener(object : TextWatcher {
                        override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                        override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                        override fun afterTextChanged(s: Editable?) { draft.repsText = s?.toString() ?: "10" }
                    })
                }
                val numRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                numRow.addView(sIn); numRow.addView(UiKit.spacerH(this, 6))
                numRow.addView(wIn); numRow.addView(UiKit.spacerH(this, 6))
                numRow.addView(rIn)
                dCard.addView(UiKit.text(this, "Sets · Weight ($weightUnit) · Reps", 10.5f, UiKit.COL_TEXT_MUTED, bold = true))
                dCard.addView(numRow)
                draftsWrap.addView(dCard)
            }
        }
        rebuildDraftsUi()

        box.addView(UiKit.text(this, "Workout Date (YYYY-MM-DD)", 11f, UiKit.COL_TEXT_MUTED, bold = true))
        box.addView(UiKit.spacerV(this, 4))
        box.addView(dateChipScroll)
        box.addView(UiKit.spacerV(this, 5))
        box.addView(dateIn)
        box.addView(UiKit.spacerV(this, 8))

        box.addView(UiKit.text(this, "Session Title", 11f, UiKit.COL_TEXT_MUTED, bold = true))
        box.addView(titleIn)
        box.addView(UiKit.spacerV(this, 6))

        val metaRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        durIn.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        rpeIn.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        metaRow.addView(durIn); metaRow.addView(UiKit.spacerH(this, 6)); metaRow.addView(rpeIn)
        box.addView(UiKit.text(this, "Duration (min) · Avg RPE", 11f, UiKit.COL_TEXT_MUTED, bold = true))
        box.addView(metaRow)
        box.addView(UiKit.spacerV(this, 8))

        box.addView(UiKit.text(this, "Exercises Performed", 12f, UiKit.COL_TEXT_DARK, bold = true))
        box.addView(UiKit.spacerV(this, 5))
        box.addView(draftsWrap)
        box.addView(UiKit.outlineButton(this, "+ Add Another Exercise", UiKit.COL_ACCENT) {
            showExercisePickerDialog { picked ->
                drafts.add(ManualExerciseDraft(picked, "3", defaultWeightDisp(picked), "10"))
                rebuildDraftsUi()
            }
        })
        box.addView(UiKit.spacerV(this, 8))
        box.addView(UiKit.text(this, "Optional Notes", 11f, UiKit.COL_TEXT_MUTED, bold = true))
        box.addView(notesIn)

        AlertDialog.Builder(this, UiKit.dialogTheme())
            .setTitle("Manual Workout Data Entry")
            .setView(scroll)
            .setPositiveButton("Save Workout") { _, _ ->
                val rawDate = dateIn.text.toString().trim()
                val parsedDate = runCatching { LocalDate.parse(rawDate) }.getOrDefault(LocalDate.now())
                val cleanDateIso = parsedDate.toString()
                val durationMin = (durIn.text.toString().toIntOrNull() ?: 50).coerceIn(5, 300)
                val rpe = rpeIn.text.toString().trim().toDoubleOrNull()?.coerceIn(1.0, 10.0)
                val sessionId = "manual_${cleanDateIso}_${System.currentTimeMillis()}"
                val allLogs = mutableListOf<SetLog>()

                drafts.forEachIndexed { exOrder, d ->
                    val count = (d.setsText.trim().toIntOrNull() ?: 3).coerceIn(1, 20)
                    val rawW = d.weightText.trim().toDoubleOrNull() ?: d.exercise.defaultWeightKg
                    val wKg = if (weightUnit == "lb") rawW / 2.20462 else rawW
                    val reps = (d.repsText.trim().toIntOrNull() ?: 10).coerceAtLeast(1)
                    for (idx in 1..count) {
                        allLogs.add(
                            SetLog(
                                id = "${sessionId}_e${exOrder + 1}_s$idx",
                                week = activeWeek,
                                dayNumber = 0,
                                templateSessionId = sessionId,
                                exerciseId = d.exercise.id,
                                exerciseName = d.exercise.name,
                                muscleId = d.exercise.primaryMuscle,
                                setIndex = idx,
                                weightKg = (wKg * 100.0).roundToInt() / 100.0,
                                reps = reps,
                                rir = if (rpe != null) (10.0 - rpe).coerceIn(0.0, 5.0) else 2.0,
                                restSeconds = d.exercise.defaultRestSeconds,
                                completed = true,
                                completedDateIso = cleanDateIso,
                                rpe = rpe
                            )
                        )
                    }
                }

                db.logManualWorkoutForDate(
                    dateIso = cleanDateIso,
                    title = titleIn.text.toString().trim().ifBlank { "Manual Workout Session" },
                    durationMin = durationMin,
                    notes = notesIn.text.toString().trim(),
                    sets = allLogs
                )
                calendarYear = parsedDate.year
                calendarMonth = parsedDate.monthValue
                calendarSelectedDateIso = cleanDateIso
                HyperLogStorageManager.saveDatabaseSnapshotAsync(this, db)
                if (hapticEnabled) NativeHardwareBridge.hapticTick(this)
                showBanner("✓ Saved ${drafts.size} exercise(s) (${allLogs.size} sets) on $cleanDateIso!")
                renderActivePage()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showAssignTemplateDialog(tpl: WorkoutTemplate) {
        val labels = (1..7).map { "Assign to Day $it" }.toTypedArray()
        AlertDialog.Builder(this, UiKit.dialogTheme())
            .setTitle("Assign '${tpl.name}' to Schedule")
            .setItems(labels) { _, which ->
                val dayNum = which + 1
                db.assignTemplateToDay(tpl, dayNum, activeWeek)
                HyperLogStreakWidgetProvider.refreshAllWidgets(this)
                showBanner("Assigned '${tpl.name}' to Day $dayNum")
                renderActivePage()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showTemplateStudioDialog(initial: WorkoutTemplate) {
        val items = initial.parsedExercises().toMutableList()
        val scroll = ScrollView(this)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = UiKit.dp(this@MainActivity, 16)
            setPadding(p, p, p, p)
        }
        scroll.addView(container)

        val nameIn = UiKit.inputBox(this, initial.name, "Template Name", InputType.TYPE_CLASS_TEXT)
        val splitIn = UiKit.inputBox(this, initial.splitType, "Split Tag (e.g. PPL, Upper/Lower)", InputType.TYPE_CLASS_TEXT)
        val itemsWrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        fun refreshItemsUi() {
            itemsWrap.removeAllViews()
            items.forEachIndexed { idx, it ->
                val box = UiKit.card(this, padDp = 10)
                val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                top.addView(UiKit.text(this, "${idx + 1}. ${it.name}", 13f, UiKit.COL_TEXT_DARK, bold = true).apply {
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                })
                top.addView(UiKit.text(this, "Remove", 11f, 0xFFEF4444.toInt(), bold = true).apply {
                    val p = UiKit.dp(this@MainActivity, 4)
                    setPadding(p, p, p, p)
                    setOnClickListener { items.removeAt(idx); refreshItemsUi() }
                })
                box.addView(top)
                box.addView(UiKit.spacerV(this, 4))

                val editsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                val setsEd = UiKit.inputBox(this, it.sets.toString(), "Sets", InputType.TYPE_CLASS_NUMBER).apply {
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                val repsEd = UiKit.inputBox(this, it.reps, "Reps", InputType.TYPE_CLASS_TEXT).apply {
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                val restEd = UiKit.inputBox(this, it.restSeconds.toString(), "Rest(s)", InputType.TYPE_CLASS_NUMBER).apply {
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                setsEd.addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                    override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                    override fun afterTextChanged(s: Editable?) {
                        s?.toString()?.toIntOrNull()?.let { v -> items[idx] = items[idx].copy(sets = v.coerceIn(1, 15)) }
                    }
                })
                repsEd.addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                    override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                    override fun afterTextChanged(s: Editable?) {
                        val v = s?.toString() ?: return
                        if (v.isNotBlank()) items[idx] = items[idx].copy(reps = v)
                    }
                })
                restEd.addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                    override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                    override fun afterTextChanged(s: Editable?) {
                        s?.toString()?.toIntOrNull()?.let { v -> items[idx] = items[idx].copy(restSeconds = v.coerceIn(15, 600)) }
                    }
                })

                editsRow.addView(setsEd); editsRow.addView(UiKit.spacerH(this, 6))
                editsRow.addView(repsEd); editsRow.addView(UiKit.spacerH(this, 6))
                editsRow.addView(restEd)
                box.addView(editsRow)
                itemsWrap.addView(box)
            }
        }

        container.addView(UiKit.text(this, "Template Name", 11f, UiKit.COL_TEXT_MUTED, bold = true))
        container.addView(nameIn)
        container.addView(UiKit.spacerV(this, 6))
        container.addView(UiKit.text(this, "Split Type", 11f, UiKit.COL_TEXT_MUTED, bold = true))
        container.addView(splitIn)
        container.addView(UiKit.spacerV(this, 10))
        container.addView(itemsWrap)
        container.addView(UiKit.outlineButton(this, "+ Add Exercise from Library", UiKit.COL_ACCENT) {
            showExercisePickerDialog { picked ->
                items.add(TemplateExerciseItem(
                    "ti_${System.currentTimeMillis()}", picked.id, picked.name, picked.primaryMuscle,
                    3, picked.defaultRepRange, picked.defaultRestSeconds, picked.defaultWeightKg
                ))
                refreshItemsUi()
            }
        })
        refreshItemsUi()

        AlertDialog.Builder(this, UiKit.dialogTheme())
            .setTitle("Workout Template Studio")
            .setView(scroll)
            .setPositiveButton("Save Template") { _, _ ->
                val savedId = if (initial.category == "Starter") "tpl_custom_${System.currentTimeMillis()}" else initial.id
                db.saveTemplate(WorkoutTemplate(
                    id = savedId,
                    name = nameIn.text.toString().ifBlank { "Custom Template" },
                    category = "Custom",
                    splitType = splitIn.text.toString().ifBlank { "Custom Split" },
                    description = initial.description,
                    exercisesJson = serializeTemplateItems(items),
                    updatedAtEpochMs = System.currentTimeMillis()
                ))
                showBanner("Saved workout template to offline SQLite")
                renderActivePage()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showExercisePickerDialog(onPicked: (LibraryExercise) -> Unit) {
        val landmarks = db.getLandmarks()
        var allLib = db.getLibraryExercisesPrioritized(limit = null, offset = 0)
        var query = ""
        var selectedFilter = "All"
        var pickerVisibleLimit = 10
        var currentMatchesCount = 0
        val filterTags = listOf("All", "Chest", "Back", "Shoulders", "Arms", "Core", "Legs", "Yoga", "Stretching", "Cardio")

        lateinit var dialogRef: AlertDialog
        lateinit var rebuildPickerListFn: () -> Unit

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = UiKit.dp(this@MainActivity, 14)
            setPadding(p, p, p, p)
        }

        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val countTv = UiKit.text(this, "Showing first 10 of ${allLib.size} exercises", 11.5f, UiKit.COL_TEXT_MUTED, bold = true, tabular = true).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        topRow.addView(countTv)
        topRow.addView(UiKit.outlineButton(this, if (isSyncingOnlineCatalog) "Syncing..." else "+ Pull 870+ Online", UiKit.COL_ACCENT) {
            triggerOnlineCatalogSync {
                allLib = db.getLibraryExercisesPrioritized(limit = null, offset = 0)
                dialogRef.dismiss()
                showExercisePickerDialog(onPicked)
            }
        })
        root.addView(topRow)
        root.addView(UiKit.spacerV(this, 8))

        val searchIn = UiKit.inputBox(this, "", "Search exercise, muscle, yoga, cardio...", InputType.TYPE_CLASS_TEXT)
        root.addView(searchIn)
        root.addView(UiKit.spacerV(this, 8))

        val (chipScroll, chipRow) = UiKit.hScrollRow(this)
        root.addView(chipScroll)
        root.addView(UiKit.spacerV(this, 8))

        val listCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val listScroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                (resources.displayMetrics.heightPixels * 0.48f).toInt()
            )
            addView(listCol)
            viewTreeObserver.addOnScrollChangedListener {
                if (pickerVisibleLimit < currentMatchesCount) {
                    val contentH = listCol.height
                    val bottomY = scrollY + height
                    if (contentH > 0 && contentH - bottomY <= UiKit.dp(this@MainActivity, 140)) {
                        pickerVisibleLimit += 10
                        rebuildPickerListFn()
                    }
                }
            }
        }
        root.addView(listScroll)

        rebuildPickerListFn = fun() {
            chipRow.removeAllViews()
            filterTags.forEach { tag ->
                chipRow.addView(UiKit.chip(this, tag, selectedFilter == tag) {
                    selectedFilter = tag
                    pickerVisibleLimit = 10
                    listScroll.scrollTo(0, 0)
                    rebuildPickerListFn()
                })
                chipRow.addView(UiKit.spacerH(this, 5))
            }

            val matches = allLib.filter { ex ->
                val qOk = query.isBlank() ||
                    ex.name.contains(query, ignoreCase = true) ||
                    ex.primaryMuscle.contains(query, ignoreCase = true) ||
                    ex.equipment.contains(query, ignoreCase = true) ||
                    ex.description.contains(query, ignoreCase = true)
                val fOk = when (selectedFilter) {
                    "All" -> true
                    "Yoga", "Stretching", "Cardio" -> ex.inferModality().equals(selectedFilter, ignoreCase = true)
                    else -> ex.majorGroup.equals(selectedFilter, ignoreCase = true)
                }
                qOk && fOk
            }
            currentMatchesCount = matches.size
            val shown = matches.take(pickerVisibleLimit)
            countTv.text = "Showing ${shown.size} of ${matches.size} exercises"

            listCol.removeAllViews()
            if (matches.isEmpty()) {
                listCol.addView(UiKit.text(
                    this,
                    "No exercises match '$query' in $selectedFilter. Tap '+ Pull 870+ Online' above to fetch the full open catalog.",
                    12f,
                    UiKit.COL_TEXT_MUTED
                ))
                return
            }

            shown.forEach { ex ->
                val mLabel = landmarks[ex.primaryMuscle]?.shortName ?: ex.primaryMuscle
                val customPrefix = if (ex.isCustom) "Custom · " else ""
                val itemRow = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    background = UiKit.roundedBg(UiKit.COL_SUBTLE, 10f, this@MainActivity, UiKit.COL_BORDER, 1f)
                    val px = UiKit.rdp(this@MainActivity, 10)
                    val py = UiKit.rdp(this@MainActivity, 9)
                    setPadding(px, py, px, py)
                    layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                        bottomMargin = UiKit.rdp(this@MainActivity, 6)
                    }
                    setOnClickListener {
                        dialogRef.dismiss()
                        onPicked(ex)
                    }
                }
                val info = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                info.addView(UiKit.text(this, ex.name, 13.5f, UiKit.COL_TEXT_DARK, bold = true))
                info.addView(UiKit.text(this, "$customPrefix$mLabel · ${ex.equipment} · ${ex.defaultRepRange}", 11f, UiKit.COL_TEXT_MUTED, tabular = true))
                itemRow.addView(info)
                itemRow.addView(UiKit.text(this, "+ Add", 12f, UiKit.COL_ACCENT, bold = true))
                listCol.addView(itemRow)
            }

            if (shown.size < matches.size) {
                listCol.addView(UiKit.outlineButton(this, "+ Load 10 More (${shown.size}/${matches.size})", UiKit.COL_ACCENT) {
                    pickerVisibleLimit += 10
                    rebuildPickerListFn()
                })
            }
        }

        searchIn.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString()?.trim() ?: ""
                pickerVisibleLimit = 10
                listScroll.scrollTo(0, 0)
                rebuildPickerListFn()
            }
        })

        rebuildPickerListFn()

        dialogRef = AlertDialog.Builder(this, UiKit.dialogTheme())
            .setTitle("Add Exercise (Scroll-to-Load)")
            .setView(root)
            .setNegativeButton("Close", null)
            .create()
        dialogRef.show()
    }

    // =========================================================================
    // PAGE 4: EXERCISE LIBRARY + DEDICATED OFFLINE DEMO VIDEOS VAULT
    // =========================================================================
    private fun createLibraryExerciseCard(
        ex: LibraryExercise,
        landmarks: Map<String, MuscleLandmark>
    ): View {
        val pName = landmarks[ex.primaryMuscle]?.shortName ?: ex.primaryMuscle
        val sNames = ex.secondaryList().map { landmarks[it]?.shortName ?: it }
        val progPts = db.getExerciseProgressionHistory(ex)
        val savedOffline = db.isExerciseSavedOffline(ex.id)
        val c = UiKit.card(this, padDp = 13)
        c.setOnClickListener { showExerciseDetailDialog(ex, landmarks) }

        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        r.addView(UiKit.text(this, ex.name, 15f, UiKit.COL_TEXT_DARK, bold = true).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        val rightMeta = buildString {
            if (ex.isCustom) append("Custom · ")
            append("${ex.equipment} · ${ex.defaultRepRange}")
        }
        r.addView(UiKit.text(this, rightMeta, 11f, UiKit.COL_ACCENT, bold = true, tabular = true))
        c.addView(r)
        c.addView(UiKit.spacerV(this, 4))
        c.addView(UiKit.text(this, ex.description, 12f, UiKit.COL_TEXT_MID))
        c.addView(UiKit.spacerV(this, 4))
        val muscleLine = if (sNames.isNotEmpty()) "Primary: $pName · Secondary: ${sNames.joinToString(", ")}" else "Primary: $pName"
        val modLevel = "${ex.inferModality()} · ${ex.inferLevel()}"
        val sessSuffix = if (progPts.isNotEmpty()) " · ${progPts.size} sessions" else ""
        c.addView(UiKit.text(this, "$muscleLine · $modLevel$sessSuffix", 11f, UiKit.COL_TEXT_MUTED, tabular = true))
        c.addView(UiKit.spacerV(this, 8))

        val actionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        if (savedOffline) {
            actionRow.addView(UiKit.chip(this, "✓ Saved Offline · ▶ Play Demo", true) {
                val entry = db.getOfflineVideoEntries().firstOrNull { it.exerciseId == ex.id }
                    ?: OfflineVideoEngine.downloadExerciseForOffline(this, db, ex)
                OfflineVideoEngine.showOfflineVideoPlayerDialog(this, entry)
            })
        } else {
            actionRow.addView(UiKit.outlineButton(this, "⬇ Save Offline Video", 0xFF059669.toInt()) {
                val entry = OfflineVideoEngine.downloadExerciseForOffline(this, db, ex)
                if (hapticEnabled) NativeHardwareBridge.hapticTick(this)
                showBanner("✓ Downloaded '${entry.exerciseName}' to Offline Videos!")
                renderActivePage()
            })
        }
        actionRow.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(0, 1, 1f) })
        actionRow.addView(UiKit.outlineButton(this, "Guide & Chart", UiKit.COL_ACCENT) {
            showExerciseDetailDialog(ex, landmarks)
        })
        c.addView(actionRow)
        return c
    }

    private fun refreshLibraryFooterUi() {
        val footer = libraryFooterWrap ?: return
        footer.removeAllViews()
        val total = lastFilteredLibraryList.size
        val shown = lastRenderedLibraryCardCount
        footer.addView(UiKit.text(
            this,
            "Showing $shown of $total exercises · Scroll down or tap below to load +10",
            11.5f,
            UiKit.COL_TEXT_MUTED,
            tabular = true
        ))
        if (shown < total) {
            footer.addView(UiKit.spacerV(this, 6))
            footer.addView(UiKit.outlineButton(this, "+ Load 10 More ($shown/$total)", UiKit.COL_ACCENT) {
                appendNextLibraryBatch()
            })
        }
    }

    private fun appendNextLibraryBatch() {
        val container = libraryCardsContainer ?: return
        if (lastRenderedLibraryCardCount >= lastFilteredLibraryList.size) return
        val landmarks = db.getLandmarks()
        val nextTarget = (lastRenderedLibraryCardCount + 10).coerceAtMost(lastFilteredLibraryList.size)
        for (idx in lastRenderedLibraryCardCount until nextTarget) {
            container.addView(createLibraryExerciseCard(lastFilteredLibraryList[idx], landmarks))
        }
        lastRenderedLibraryCardCount = nextTarget
        libraryVisibleLimit = maxOf(libraryVisibleLimit, nextTarget)
        refreshLibraryFooterUi()
    }

    private fun renderLibraryPage() {
        val landmarks = db.getLandmarks()
        val offlineEntries = db.getOfflineVideoEntries()

        // Top Mode Switch: Exercise Catalog vs Dedicated Offline Videos Section
        val (modeScroll, modeRow) = UiKit.hScrollRow(this)
        modeScroll.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = UiKit.rdp(this@MainActivity, 10)
        }
        modeRow.addView(UiKit.chip(this, "Exercise Catalog", librarySubTab == "catalog") {
            librarySubTab = "catalog"
            renderActivePage()
        })
        modeRow.addView(UiKit.spacerH(this, 6))
        modeRow.addView(UiKit.chip(this, "Offline Videos (${offlineEntries.size})", librarySubTab == "offline") {
            librarySubTab = "offline"
            libraryCardsContainer = null
            libraryFooterWrap = null
            renderActivePage()
        })
        if (librarySubTab == "offline") {
            modeRow.addView(UiKit.spacerH(this, 6))
            modeRow.addView(UiKit.primaryButton(this, "⬇ Starter Pack (8)", 0xFF059669.toInt()) {
                val added = OfflineVideoEngine.downloadStarterPackOffline(this, db)
                if (hapticEnabled) NativeHardwareBridge.hapticTick(this)
                showBanner(if (added > 0) "✓ Saved $added starter workout demo videos offline!" else "Starter pack already saved in Offline Videos!")
                renderActivePage()
            })
        }
        pageContent.addView(modeScroll)

        if (librarySubTab == "offline") {
            renderOfflineVideosSection(landmarks, offlineEntries)
            return
        }

        val hasActiveFilters = libraryQuery.isNotBlank() ||
            libraryGroupFilter != MajorMuscleGroup.ALL ||
            libraryEquipFilter != "All" ||
            libraryModalityFilter != "All" ||
            libraryLevelFilter != "All"

        val sourceLib = if (loginHydratedFirst10Only && !hasActiveFilters && cachedFirst10Library.isNotEmpty()) {
            cachedFirst10Library
        } else {
            db.getLibraryExercisesPrioritized(limit = null, offset = 0)
        }
        val totalCatalogCount = if (cachedTotalLibraryCount > 0) cachedTotalLibraryCount else sourceLib.size

        val filtered = sourceLib.filter { ex ->
            val qOk = libraryQuery.isBlank() ||
                ex.name.contains(libraryQuery, ignoreCase = true) ||
                ex.description.contains(libraryQuery, ignoreCase = true) ||
                ex.primaryMuscle.contains(libraryQuery, ignoreCase = true) ||
                ex.equipment.contains(libraryQuery, ignoreCase = true)
            val gOk = libraryGroupFilter == MajorMuscleGroup.ALL || ex.majorGroup.equals(libraryGroupFilter.name, ignoreCase = true)
            val eOk = libraryEquipFilter == "All" || ex.equipment.equals(libraryEquipFilter, ignoreCase = true)
            val mOk = libraryModalityFilter == "All" || ex.inferModality().equals(libraryModalityFilter, ignoreCase = true)
            val lOk = libraryLevelFilter == "All" || ex.inferLevel().equals(libraryLevelFilter, ignoreCase = true)
            qOk && gOk && eOk && mOk && lOk
        }

        lastFilteredLibraryList = filtered
        val initialBatchCount = libraryVisibleLimit.coerceAtLeast(10).coerceAtMost(filtered.size)

        val filterCard = UiKit.card(this)
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val headLeft = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        headLeft.addView(UiKit.text(this, "Movement Library", 16f, UiKit.COL_TEXT_DARK, bold = true))
        val subCountLabel = if (hasActiveFilters) {
            "Showing ${filtered.size} of $totalCatalogCount movements"
        } else {
            "Browse ${initialBatchCount} of $totalCatalogCount movements · Form cues & offline demos"
        }
        headLeft.addView(UiKit.text(this, subCountLabel, 11.5f, UiKit.COL_TEXT_MUTED, tabular = true))
        head.addView(headLeft)
        head.addView(UiKit.outlineButton(this, "+ Custom", UiKit.COL_ACCENT) { showCreateExerciseDialog() })
        filterCard.addView(head)
        filterCard.addView(UiKit.spacerV(this, 8))

        val searchBox = UiKit.inputBox(this, libraryQuery, "Search movement, muscle, yoga, cardio...", InputType.TYPE_CLASS_TEXT)
        val searchRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        searchBox.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        searchRow.addView(searchBox)
        searchRow.addView(UiKit.spacerH(this, 6))
        searchRow.addView(UiKit.primaryButton(this, "Search") {
            libraryQuery = searchBox.text.toString().trim()
            libraryVisibleLimit = 10
            renderActivePage()
        })
        if (libraryQuery.isNotBlank()) {
            searchRow.addView(UiKit.spacerH(this, 4))
            searchRow.addView(UiKit.outlineButton(this, "Clear") {
                libraryQuery = ""
                libraryVisibleLimit = 10
                renderActivePage()
            })
        }
        filterCard.addView(searchRow)
        filterCard.addView(UiKit.spacerV(this, 8))

        val (quickFilterScroll, quickFilterRow) = UiKit.hScrollRow(this)
        val isForearmFilterActive = libraryQuery.equals("Forearms", ignoreCase = true)
        quickFilterRow.addView(UiKit.chip(this, "Forearms & Grip", isForearmFilterActive) {
            libraryQuery = if (isForearmFilterActive) "" else "Forearms"
            libraryVisibleLimit = 10
            renderActivePage()
        })
        quickFilterRow.addView(UiKit.spacerH(this, 6))
        quickFilterRow.addView(UiKit.chip(
            this,
            if (showLibraryFilters) "Hide Filters ▴" else "Filter by Muscle, Level or Gear ▾",
            showLibraryFilters || hasActiveFilters
        ) {
            showLibraryFilters = !showLibraryFilters
            renderActivePage()
        })
        quickFilterRow.addView(UiKit.spacerH(this, 6))
        quickFilterRow.addView(UiKit.outlineButton(this, if (isSyncingOnlineCatalog) "Syncing..." else "Refresh Online", UiKit.COL_ACCENT) {
            triggerOnlineCatalogSync {
                cachedTotalLibraryCount = db.getTotalLibraryExerciseCount()
            }
        })
        if (hasActiveFilters) {
            quickFilterRow.addView(UiKit.spacerH(this, 6))
            quickFilterRow.addView(UiKit.outlineButton(this, "Reset Filters") {
                libraryQuery = ""
                libraryGroupFilter = MajorMuscleGroup.ALL
                libraryEquipFilter = "All"
                libraryModalityFilter = "All"
                libraryLevelFilter = "All"
                libraryVisibleLimit = 10
                renderActivePage()
            })
        }
        filterCard.addView(quickFilterScroll)

        // Progressive-Disclosure Filter Rows (Collapsed by Default)
        if (showLibraryFilters) {
            filterCard.addView(UiKit.spacerV(this, 8))
            val (gScroll, gRow) = UiKit.hScrollRow(this)
            MajorMuscleGroup.entries.forEach { grp ->
                gRow.addView(UiKit.chip(this, grp.label, libraryGroupFilter == grp) {
                    libraryGroupFilter = grp
                    libraryVisibleLimit = 10
                    renderActivePage()
                })
                gRow.addView(UiKit.spacerH(this, 6))
            }
            filterCard.addView(gScroll)
            filterCard.addView(UiKit.spacerV(this, 6))

            val (mScroll, mRow) = UiKit.hScrollRow(this)
            listOf("All", "Strength", "Cardio", "Yoga", "Stretching").forEach { mod ->
                mRow.addView(UiKit.chip(this, mod, libraryModalityFilter == mod) {
                    libraryModalityFilter = mod
                    libraryVisibleLimit = 10
                    renderActivePage()
                })
                mRow.addView(UiKit.spacerH(this, 6))
            }
            mRow.addView(UiKit.text(this, "·", 13f, UiKit.COL_TEXT_MUTED, bold = true).apply {
                setPadding(UiKit.dp(this@MainActivity, 2), 0, UiKit.dp(this@MainActivity, 6), 0)
            })
            listOf("All", "Beginner", "Intermediate", "Advanced").forEach { lvl ->
                val lbl = if (lvl == "All") "All Levels" else lvl
                mRow.addView(UiKit.chip(this, lbl, libraryLevelFilter == lvl) {
                    libraryLevelFilter = lvl
                    libraryVisibleLimit = 10
                    renderActivePage()
                })
                mRow.addView(UiKit.spacerH(this, 6))
            }
            filterCard.addView(mScroll)
            filterCard.addView(UiKit.spacerV(this, 6))

            val (eScroll, eRow) = UiKit.hScrollRow(this)
            listOf(
                "All", "Barbell", "Dumbbell", "Cable", "Machine", "Smith Machine",
                "Bodyweight", "EZ Bar", "Yoga", "Stretching", "Cardio", "Kettlebells", "Bands"
            ).forEach { eq ->
                eRow.addView(UiKit.chip(this, eq, libraryEquipFilter == eq) {
                    libraryEquipFilter = eq
                    libraryVisibleLimit = 10
                    renderActivePage()
                })
                eRow.addView(UiKit.spacerH(this, 6))
            }
            filterCard.addView(eScroll)
        }
        pageContent.addView(filterCard)

        val cardsWrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        libraryCardsContainer = cardsWrap
        filtered.take(initialBatchCount).forEach { ex ->
            cardsWrap.addView(createLibraryExerciseCard(ex, landmarks))
        }
        lastRenderedLibraryCardCount = initialBatchCount
        pageContent.addView(cardsWrap)

        val footerWrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val py = UiKit.rdp(this@MainActivity, 6)
            setPadding(0, py, 0, py)
        }
        libraryFooterWrap = footerWrap
        pageContent.addView(footerWrap)
        refreshLibraryFooterUi()
    }

    private fun renderOfflineVideosSection(
        landmarks: Map<String, MuscleLandmark>,
        entries: List<OfflineDemoVideoEntry>
    ) {
        val totalBytes = entries.sumOf { it.fileSizeBytes }
        val vaultCard = UiKit.card(this, borderColor = 0xFF059669.toInt(), borderDp = 1.4f, padDp = 14)
        vaultCard.addView(UiKit.text(this, "Offline Workout Demo Videos", 16f, UiKit.COL_TEXT_DARK, bold = true))
        vaultCard.addView(UiKit.text(
            this,
            "Saved in internal storage (HyperLogData/videos/offline_saved) for zero-buffering form playback in basement gyms or Airplane Mode.",
            11.5f,
            UiKit.COL_TEXT_MUTED
        ))
        vaultCard.addView(UiKit.spacerV(this, 8))

        val kpiRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(
            "SAVED VIDEOS" to entries.size.toString(),
            "STORAGE USED" to HyperLogStorageManager.formatBytes(totalBytes),
            "PLAYBACK" to "100% Offline"
        ).forEachIndexed { idx, (lbl, v) ->
            kpiRow.addView(UiKit.metricBox(this, lbl, v, if (idx == 2) 0xFF059669.toInt() else UiKit.COL_TEXT_DARK).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    if (idx < 2) rightMargin = UiKit.rdp(this@MainActivity, 6)
                }
            })
        }
        vaultCard.addView(kpiRow)
        vaultCard.addView(UiKit.spacerV(this, 10))

        val btnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        btnRow.addView(UiKit.primaryButton(this, "⬇ Download 8-Exercise Starter Pack", 0xFF059669.toInt()) {
            val count = OfflineVideoEngine.downloadStarterPackOffline(this, db)
            if (hapticEnabled) NativeHardwareBridge.hapticTick(this)
            showBanner(if (count > 0) "✓ Downloaded $count workout demo videos for offline viewing!" else "All 8 starter demos are already saved offline!")
            renderActivePage()
        }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.3f).apply {
                rightMargin = UiKit.rdp(this@MainActivity, 6)
            }
        })
        btnRow.addView(UiKit.outlineButton(this, "Browse Catalog", UiKit.COL_ACCENT) {
            librarySubTab = "catalog"
            renderActivePage()
        }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.7f)
        })
        vaultCard.addView(btnRow)
        pageContent.addView(vaultCard)

        if (entries.isEmpty()) {
            val emptyCard = UiKit.card(this, padDp = 14)
            emptyCard.addView(UiKit.text(this, "No Offline Demo Videos Saved Yet", 14.5f, UiKit.COL_TEXT_DARK, bold = true))
            emptyCard.addView(UiKit.spacerV(this, 4))
            emptyCard.addView(UiKit.text(
                this,
                "Tap '⬇ Download 8-Exercise Starter Pack' above, tap '⬇ Save Offline Video' on any exercise in the Catalog, or tap '⬇ Save Demos Offline' on any Workout Template.",
                12f,
                UiKit.COL_TEXT_MUTED
            ))
            pageContent.addView(emptyCard)
            return
        }

        val (fScroll, fRow) = UiKit.hScrollRow(this)
        fScroll.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = UiKit.rdp(this@MainActivity, 8)
        }
        val filterGroups = listOf("All", "CHEST", "BACK", "SHOULDERS", "ARMS", "CORE", "LEGS")
        filterGroups.forEach { grp ->
            val label = if (grp == "All") "All Saved (${entries.size})" else grp.lowercase(Locale.US).replaceFirstChar { it.uppercase() }
            fRow.addView(UiKit.chip(this, label, offlineVideoMuscleFilter == grp) {
                offlineVideoMuscleFilter = grp
                renderActivePage()
            })
            fRow.addView(UiKit.spacerH(this, 6))
        }
        pageContent.addView(fScroll)

        val visibleEntries = entries.filter { e ->
            offlineVideoMuscleFilter == "All" || e.majorGroup.equals(offlineVideoMuscleFilter, ignoreCase = true)
        }

        visibleEntries.forEach { entry ->
            val mName = landmarks[entry.primaryMuscle]?.shortName ?: entry.primaryMuscle
            val vCard = UiKit.card(this, padDp = 13)
            val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val info = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            info.addView(UiKit.text(
                this,
                "✓ OFFLINE READY · $mName · ${entry.equipment} · ${entry.durationSec}s loop",
                10.5f,
                0xFF059669.toInt(),
                bold = true,
                tabular = true
            ))
            info.addView(UiKit.text(this, entry.exerciseName, 15f, UiKit.COL_TEXT_DARK, bold = true))
            info.addView(UiKit.text(
                this,
                "Saved ${entry.downloadedAtIso} · ${HyperLogStorageManager.formatBytes(entry.fileSizeBytes)}",
                11f,
                UiKit.COL_TEXT_MUTED,
                tabular = true
            ))
            top.addView(info)
            vCard.addView(top)
            vCard.addView(UiKit.spacerV(this, 8))

            val act = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            act.addView(UiKit.primaryButton(this, "▶ Watch Offline Demo", UiKit.COL_ACCENT) {
                OfflineVideoEngine.showOfflineVideoPlayerDialog(this, entry)
            }.apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.35f).apply {
                    rightMargin = UiKit.rdp(this@MainActivity, 6)
                }
            })
            act.addView(UiKit.outlineButton(this, "Delete", 0xFFEF4444.toInt()) {
                OfflineVideoEngine.deleteOfflineVideo(this, db, entry.exerciseId)
                if (hapticEnabled) NativeHardwareBridge.hapticTick(this)
                showBanner("Removed '${entry.exerciseName}' from Offline Videos")
                renderActivePage()
            }.apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.65f)
            })
            vCard.addView(act)
            pageContent.addView(vCard)
        }
    }

    private fun showExerciseDetailDialog(ex: LibraryExercise, landmarks: Map<String, MuscleLandmark>) {
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = UiKit.dp(this@MainActivity, 16)
            setPadding(p, p, p, p)
        }
        scroll.addView(box)

        val pName = landmarks[ex.primaryMuscle]?.name ?: ex.primaryMuscle
        val sNames = ex.secondaryList().map { landmarks[it]?.shortName ?: it }
        val points = db.getExerciseProgressionHistory(ex)

        box.addView(UiKit.text(this, "${ex.equipment} · Default ${ex.defaultRepRange} reps · ${ex.defaultRestSeconds}s rest", 12f, UiKit.COL_ACCENT, bold = true))
        box.addView(UiKit.spacerV(this, 6))
        box.addView(UiKit.text(this, ex.description, 13f, UiKit.COL_TEXT_DARK))
        box.addView(UiKit.spacerV(this, 10))

        // Offline Demo Video Download & Instant Playback Box
        val offlineWrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = UiKit.roundedBg(UiKit.COL_SUBTLE, 12f, this@MainActivity, 0xFF10B981.toInt(), 1.2f)
            val p = UiKit.rdp(this@MainActivity, 11)
            setPadding(p, p, p, p)
        }
        fun rebuildOfflineControls() {
            offlineWrap.removeAllViews()
            val isSaved = db.isExerciseSavedOffline(ex.id)
            offlineWrap.addView(UiKit.text(
                this,
                if (isSaved) "✓ Saved in Offline Videos Vault (Airplane Mode Ready)" else "Offline Biomechanical Demo Video",
                12.5f,
                if (isSaved) 0xFF059669.toInt() else UiKit.COL_TEXT_DARK,
                bold = true
            ))
            offlineWrap.addView(UiKit.spacerV(this, 6))
            val btnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            btnRow.addView(UiKit.primaryButton(this, "▶ Watch Offline Demo", UiKit.COL_ACCENT) {
                val entry = db.getOfflineVideoEntries().firstOrNull { it.exerciseId == ex.id }
                    ?: OfflineVideoEngine.downloadExerciseForOffline(this, db, ex)
                rebuildOfflineControls()
                OfflineVideoEngine.showOfflineVideoPlayerDialog(this, entry)
            }.apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.25f).apply {
                    rightMargin = UiKit.rdp(this@MainActivity, 6)
                }
            })
            if (isSaved) {
                btnRow.addView(UiKit.outlineButton(this, "Remove", 0xFFEF4444.toInt()) {
                    OfflineVideoEngine.deleteOfflineVideo(this, db, ex.id)
                    rebuildOfflineControls()
                    if (activeTab == 3) renderActivePage()
                }.apply {
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.75f)
                })
            } else {
                btnRow.addView(UiKit.outlineButton(this, "⬇ Save Offline", 0xFF059669.toInt()) {
                    OfflineVideoEngine.downloadExerciseForOffline(this, db, ex)
                    if (hapticEnabled) NativeHardwareBridge.hapticTick(this)
                    rebuildOfflineControls()
                    if (activeTab == 3) renderActivePage()
                }.apply {
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.85f)
                })
            }
            offlineWrap.addView(btnRow)
        }
        rebuildOfflineControls()
        box.addView(offlineWrap)
        box.addView(UiKit.spacerV(this, 10))

        // Historical Weight Progression (Last 10 Sessions) Card
        val chartCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = UiKit.roundedBg(UiKit.COL_SUBTLE, 12f, this@MainActivity, UiKit.COL_BORDER, 1f)
            val p = UiKit.rdp(this@MainActivity, 12)
            setPadding(p, p, p, p)
        }
        chartCard.addView(UiKit.text(this, "Weight Progression (Last 10 Sessions)", 13f, UiKit.COL_TEXT_DARK, bold = true))
        chartCard.addView(UiKit.spacerV(this, 6))

        val chartView = ExerciseProgressionChartView(this).apply {
            this.points = points
            this.metricMode = libraryChartMetric
            this.weightUnit = this@MainActivity.weightUnit
        }
        val kpiWrap = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val modeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        fun rebuildProgressionKpisAndChips() {
            modeRow.removeAllViews()
            listOf("top" to "Top Load", "avg" to "Avg Load", "e1rm" to "Est. 1RM").forEachIndexed { idx, (mId, mLbl) ->
                modeRow.addView(UiKit.chip(this, mLbl, libraryChartMetric == mId) {
                    libraryChartMetric = mId
                    chartView.metricMode = mId
                    rebuildProgressionKpisAndChips()
                }.apply {
                    val px = UiKit.rdp(this@MainActivity, 8)
                    val py = UiKit.rdp(this@MainActivity, 5)
                    setPadding(px, py, px, py)
                    if (idx < 2) {
                        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                            rightMargin = UiKit.rdp(this@MainActivity, 6)
                        }
                    }
                })
            }

            kpiWrap.removeAllViews()
            if (points.isNotEmpty()) {
                fun pickKg(pt: ExerciseSessionPoint): Double = when (libraryChartMetric) {
                    "avg" -> pt.avgWeightKg
                    "e1rm" -> pt.est1RmKg
                    else -> pt.topWeightKg
                }
                fun fmtW(kg: Double): String {
                    val v = if (weightUnit == "lb") kg * 2.20462 else kg
                    val r = (v * 10.0).roundToInt() / 10.0
                    val s = if (r % 1.0 == 0.0) r.toInt().toString() else String.format(Locale.US, "%.1f", r)
                    return "$s $weightUnit"
                }
                val firstKg = pickKg(points.first())
                val latestKg = pickKg(points.last())
                val peakKg = points.maxOf { pickKg(it) }
                val deltaRaw = if (weightUnit == "lb") (latestKg - firstKg) * 2.20462 else (latestKg - firstKg)
                val deltaR = (deltaRaw * 10.0).roundToInt() / 10.0
                val deltaStr = (if (deltaR >= 0) "+" else "") + (if (deltaR % 1.0 == 0.0) deltaR.toInt().toString() else String.format(Locale.US, "%.1f", deltaR)) + " $weightUnit"

                listOf(
                    "LATEST" to fmtW(latestKg),
                    "10-SESS Δ" to deltaStr,
                    "PEAK" to fmtW(peakKg)
                ).forEachIndexed { idx, (lbl, v) ->
                    kpiWrap.addView(UiKit.metricBox(this, lbl, v).apply {
                        layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                            if (idx < 2) rightMargin = UiKit.rdp(this@MainActivity, 6)
                        }
                    })
                }
            }
        }
        rebuildProgressionKpisAndChips()

        chartCard.addView(modeRow)
        if (points.isNotEmpty()) {
            chartCard.addView(UiKit.spacerV(this, 8))
            chartCard.addView(kpiWrap)
        }
        chartCard.addView(UiKit.spacerV(this, 8))
        chartCard.addView(chartView)
        box.addView(chartCard)
        box.addView(UiKit.spacerV(this, 10))

        box.addView(UiKit.text(this, "Muscles Targeted", 13f, UiKit.COL_TEXT_DARK, bold = true))
        box.addView(UiKit.text(this, "• Primary: $pName", 12f, UiKit.COL_TEXT_MID))
        if (sNames.isNotEmpty()) {
            box.addView(UiKit.text(this, "• Secondary: ${sNames.joinToString(", ")}", 12f, UiKit.COL_TEXT_MID))
        }
        box.addView(UiKit.spacerV(this, 10))
        box.addView(UiKit.text(this, "Step-by-Step Instructions", 13f, UiKit.COL_TEXT_DARK, bold = true))
        ex.instructionSteps().forEachIndexed { idx, step ->
            box.addView(UiKit.spacerV(this, 4))
            box.addView(UiKit.text(this, "${idx + 1}. $step", 12f, UiKit.COL_TEXT_MID))
        }

        if (ex.videoUrl.isNotBlank()) {
            box.addView(UiKit.spacerV(this, 12))
            box.addView(UiKit.outlineButton(this, "Open External Web Video Link ↗", UiKit.COL_ACCENT) {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(ex.videoUrl)))
                } catch (_: Exception) {
                    showBanner("No browser installed on this device to open external video link.")
                }
            })
        }

        AlertDialog.Builder(this, UiKit.dialogTheme())
            .setTitle(ex.name)
            .setView(scroll)
            .setNeutralButton("+ Add & Track Now") { _, _ ->
                val curSt = standaloneSession
                if (curSt != null) {
                    standaloneSession = db.appendExerciseToStandaloneSession(curSt, ex, activeWeek)
                    savePrefs()
                } else {
                    db.appendExerciseToScheduleDay(activeDay, ex, activeWeek)
                }
                activeTab = 0
                rebuildTopSettingsButton()
                rebuildBottomNav()
                mainScroll.scrollTo(0, 0)
                showBanner("Added '${ex.name}' to active workout")
                renderActivePage()
            }
            .setPositiveButton("Done", null)
            .show()
    }

    private fun showCreateExerciseDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = UiKit.dp(this@MainActivity, 16)
            setPadding(p, p, p, p)
        }
        val nameIn = UiKit.inputBox(this, "", "Exercise Name", InputType.TYPE_CLASS_TEXT)
        val equipIn = UiKit.inputBox(this, "Dumbbell", "Equipment (Barbell, Cable, Machine...)", InputType.TYPE_CLASS_TEXT)
        val muscleIn = UiKit.inputBox(this, "chest", "Primary muscle ID (chest, back, quads, biceps...)", InputType.TYPE_CLASS_TEXT)
        val descIn = UiKit.inputBox(this, "", "Biomechanical description", InputType.TYPE_CLASS_TEXT)
        val stepsIn = UiKit.inputBox(this, "Brace core and set stable posture.\nControl 2–3s eccentric stretch.\nDrive smoothly to peak contraction.", "Instructions (1 step per line)", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE)

        listOf("Name" to nameIn, "Equipment" to equipIn, "Primary Muscle ID" to muscleIn, "Description" to descIn, "Instructions" to stepsIn).forEach { (l, v) ->
            box.addView(UiKit.text(this, l, 11f, UiKit.COL_TEXT_MUTED, bold = true))
            box.addView(v)
            box.addView(UiKit.spacerV(this, 6))
        }

        AlertDialog.Builder(this, UiKit.dialogTheme())
            .setTitle("Create Custom Library Exercise")
            .setView(box)
            .setPositiveButton("Save") { _, _ ->
                val nm = nameIn.text.toString().trim()
                if (nm.isNotEmpty()) {
                    val mId = muscleIn.text.toString().trim().ifBlank { "chest" }
                    val grp = MajorMuscleGroup.entries.firstOrNull { it != MajorMuscleGroup.ALL && it.matchesMuscle(mId) }?.name ?: "CHEST"
                    db.saveLibraryExercise(LibraryExercise(
                        "lib_custom_${System.currentTimeMillis()}", nm, grp, mId, "",
                        equipIn.text.toString().ifBlank { "Dumbbell" },
                        descIn.text.toString().ifBlank { "Custom offline hypertrophy exercise." },
                        stepsIn.text.toString(), "8–12", 90, 20.0, ""
                    ))
                    showBanner("Saved '$nm' to offline Exercise Library")
                    renderActivePage()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // =========================================================================
    // PAGE 5: CALORIES + OFFLINE CALCULATOR + REDESIGNED OFFLINE MEAL BUILDER
    // =========================================================================
    private fun syncBuilderMacrosFromIngredients() {
        builderProteinG = builderIngredients.sumOf { it.macros.proteinG }
        builderCarbsG = builderIngredients.sumOf { it.macros.carbsG }
        builderFatG = builderIngredients.sumOf { it.macros.fatG }
        if (!builderManualKcalOverride) {
            builderManualKcal = autoCalculateCaloriesFromMacros(
                builderProteinG.toDouble(),
                builderCarbsG.toDouble(),
                builderFatG.toDouble()
            )
        }
        if (builderMealName.isBlank() && builderIngredients.isNotEmpty()) {
            builderMealName = builderIngredients.take(3).joinToString(" + ") {
                it.food.name.substringBefore(" (")
            }
        }
    }

    private fun renderCaloriesPage() {
        studioClockView = null
        breathClockView = null
        breathCueView = null
        hiitClockView = null

        // Single Clean Wellness Sub-Tab Strip (Duplicate Spinner Menu Removed)
        val (hubScroll, hubRow) = UiKit.hScrollRow(this)
        hubScroll.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = UiKit.rdp(this@MainActivity, 10)
        }
        listOf(
            "wellbeing" to "Overview",
            "indian" to "Indian Meals",
            "studio" to "Movement",
            "tools" to "Tools",
            "nutrition" to "Nutrition"
        ).forEach { (tabId, tabLbl) ->
            hubRow.addView(UiKit.chip(this, tabLbl, wellnessSubTab == tabId) {
                wellnessSubTab = tabId
                if (tabId != "wellbeing" && breathTimerRunning) {
                    breathTimerRunning = false
                    lastBreathPhaseKey = ""
                    mainHandler.removeCallbacks(breathTickRunnable)
                    BreathingSoundscapeEngine.stop()
                }
                if (hapticEnabled) NativeHardwareBridge.hapticTick(this)
                renderActivePage()
            })
            hubRow.addView(UiKit.spacerH(this, 6))
        }
        pageContent.addView(hubScroll)
        pageContent.addView(UiKit.spacerV(this, 4))

        // 5-Day Date Selector Strip (shared across Nutrition, Indian Meals & Wellbeing)
        if (wellnessSubTab == "nutrition" || wellnessSubTab == "indian" || wellnessSubTab == "wellbeing") {
            val (dateScroll, dateRow) = UiKit.hScrollRow(this)
            val today = LocalDate.now()
            (4 downTo 0).forEach { offset ->
                val dt = today.minusDays(offset.toLong())
                val dIso = dt.toString()
                val lbl = if (offset == 0) "Today (${dt.dayOfMonth})"
                else "${dt.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.US)} ${dt.dayOfMonth}"
                dateRow.addView(UiKit.chip(this, lbl, selectedDateIso == dIso) {
                    selectedDateIso = dIso
                    weightInputDateIso = dIso
                    renderActivePage()
                })
                dateRow.addView(UiKit.spacerH(this, 6))
            }
            pageContent.addView(dateScroll)
            pageContent.addView(UiKit.spacerV(this, 8))
        }

        when (wellnessSubTab) {
            "indian" -> {
                renderIndianNutritionSection()
                return
            }
            "studio" -> {
                renderGuidedStudioSection()
                return
            }
            "wellbeing" -> {
                renderWellbeingSection()
                return
            }
            "tools" -> {
                renderFitnessToolsSection()
                return
            }
        }

        val metrics = db.getDailyMetrics(selectedDateIso)
        val meals = db.getMealsForDate(selectedDateIso)
        val savedCustomMeals = db.getSavedCustomMeals()
        val weeklySets = db.getSetLogs().count { it.week == activeWeek && it.completed }

        val phaseDelta = when (metrics.phase) {
            "Massing" -> 300; "Mini-Cut" -> -500; else -> 0
        }
        val stepBonus = ((metrics.steps - 6000).coerceAtLeast(0) * 0.035).roundToInt()
        val liftBonus = ((weeklySets * 16.5) / 7.0).roundToInt()
        val targetKcal = (metrics.baseTdee + phaseDelta + stepBonus + liftBonus).coerceAtLeast(1250)
        val targetP = (metrics.bodyweightKg * metrics.proteinPerKg).roundToInt().coerceAtLeast(95)
        val targetF = (metrics.bodyweightKg * (if (metrics.phase == "Mini-Cut") 0.75 else 0.85)).roundToInt().coerceAtLeast(42)
        val targetC = ((targetKcal - targetP * 4 - targetF * 9) / 4).coerceAtLeast(60)

        val eatenKcal = meals.sumOf { it.calories }
        val eatenP = meals.sumOf { it.proteinG }
        val eatenC = meals.sumOf { it.carbsG }
        val eatenF = meals.sumOf { it.fatG }

        // 2. Clean Daily Energy & Macro Progress Card
        val calCard = UiKit.card(this)
        val topHeader = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val topLeft = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        topLeft.addView(UiKit.text(this, "Daily Nutrition", 16f, UiKit.COL_TEXT_DARK, bold = true))
        val remKcal = targetKcal - eatenKcal
        val remText = if (remKcal >= 0) "$remKcal kcal left" else "${-remKcal} kcal over"
        topLeft.addView(UiKit.text(this, "$eatenKcal / $targetKcal kcal · $remText", 13f, UiKit.COL_ACCENT, bold = true, tabular = true))
        topHeader.addView(topLeft)
        topHeader.addView(UiKit.chip(this, if (showBodyMetricsDrawer) "Weight/Steps ▴" else "Weight/Steps ▾", showBodyMetricsDrawer) {
            showBodyMetricsDrawer = !showBodyMetricsDrawer
            renderActivePage()
        })
        calCard.addView(topHeader)
        calCard.addView(UiKit.progressBar(this, eatenKcal.toFloat() / targetKcal.toFloat(), UiKit.COL_FLAME_ORANGE))
        calCard.addView(UiKit.spacerV(this, 8))

        listOf(
            Triple("Protein", "$eatenP / ${targetP}g", eatenP.toFloat() / targetP.toFloat() to 0xFF3B82F6.toInt()),
            Triple("Carbs", "$eatenC / ${targetC}g", eatenC.toFloat() / targetC.toFloat() to 0xFF10B981.toInt()),
            Triple("Fat", "$eatenF / ${targetF}g", eatenF.toFloat() / targetF.toFloat() to 0xFFF59E0B.toInt())
        ).forEach { (lbl, valStr, pair) ->
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            r.addView(UiKit.text(this, lbl, 12f, UiKit.COL_TEXT_MID, bold = true).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            r.addView(UiKit.text(this, valStr, 12f, UiKit.COL_TEXT_DARK, bold = true, tabular = true))
            calCard.addView(r)
            calCard.addView(UiKit.progressBar(this, pair.first, pair.second))
        }

        // Collapsible Goal Phase + Bodyweight & Steps Drawer
        if (showBodyMetricsDrawer) {
            calCard.addView(UiKit.spacerV(this, 8))
            val (phScroll, phRow) = UiKit.hScrollRow(this)
            listOf("Massing" to "Lean Mass (+300)", "Maintenance" to "Maintenance", "Mini-Cut" to "Mini-Cut (-500)").forEach { (phKey, phLbl) ->
                phRow.addView(UiKit.chip(this, phLbl, metrics.phase == phKey) {
                    db.saveDailyMetrics(metrics.copy(phase = phKey))
                    calcGoalId = GoalPhaseOption.fromDbPhase(phKey).id
                    savePrefs()
                    HyperLogStreakWidgetProvider.refreshAllWidgets(this)
                    renderActivePage()
                })
                phRow.addView(UiKit.spacerH(this, 6))
            }
            calCard.addView(phScroll)
            calCard.addView(UiKit.spacerV(this, 8))

            val bwDisp = if (weightUnit == "lb") ((metrics.bodyweightKg * 2.20462 * 10.0).roundToInt() / 10.0).toString()
            else ((metrics.bodyweightKg * 10.0).roundToInt() / 10.0).toString()
            val bwRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val bwIn = UiKit.inputBox(this, bwDisp, "Weight ($weightUnit)", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            val stIn = UiKit.inputBox(this, metrics.steps.toString(), "Daily Steps", InputType.TYPE_CLASS_NUMBER).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            bwRow.addView(bwIn); bwRow.addView(UiKit.spacerH(this, 6))
            bwRow.addView(stIn); bwRow.addView(UiKit.spacerH(this, 6))
            bwRow.addView(UiKit.outlineButton(this, "Save") {
                val rawW = bwIn.text.toString().toDoubleOrNull()
                val newKg = if (rawW != null) {
                    if (weightUnit == "lb") rawW / 2.20462 else rawW
                } else metrics.bodyweightKg
                db.saveDailyMetrics(metrics.copy(
                    bodyweightKg = (newKg * 10.0).roundToInt() / 10.0,
                    steps = stIn.text.toString().toIntOrNull() ?: metrics.steps
                ))
                HyperLogStreakWidgetProvider.refreshAllWidgets(this)
                showBanner("Saved bodyweight & daily steps")
                renderActivePage()
            })
            calCard.addView(bwRow)
        }
        pageContent.addView(calCard)

        // 2B. Dedicated Daily Weight Record Logger + Dual-Line Bodyweight & Caloric Intake Chart
        val weightRecordMetrics = db.getDailyMetrics(weightInputDateIso)
        val curWDisp = if (weightUnit == "lb") {
            ((weightRecordMetrics.bodyweightKg * 2.20462 * 10.0).roundToInt() / 10.0)
        } else {
            ((weightRecordMetrics.bodyweightKg * 10.0).roundToInt() / 10.0)
        }

        val weightCard = UiKit.card(this, padDp = 13)
        weightCard.addView(UiKit.text(this, "Log Daily Bodyweight Record", 14.5f, UiKit.COL_TEXT_DARK, bold = true))
        weightCard.addView(UiKit.text(
            this,
            "Record daily scale weight ($weightUnit) to plot weight trends against caloric intake",
            11f,
            UiKit.COL_TEXT_MUTED
        ))
        weightCard.addView(UiKit.spacerV(this, 7))

        val (wDateScroll, wDateRow) = UiKit.hScrollRow(this)
        val todayRef = LocalDate.now()
        (4 downTo 0).forEach { off ->
            val dObj = todayRef.minusDays(off.toLong())
            val dIso = dObj.toString()
            val lbl = if (off == 0) "Today" else dIso.substring(5)
            wDateRow.addView(UiKit.chip(this, lbl, weightInputDateIso == dIso) {
                weightInputDateIso = dIso
                renderActivePage()
            })
            wDateRow.addView(UiKit.spacerH(this, 5))
        }
        weightCard.addView(wDateScroll)
        weightCard.addView(UiKit.spacerV(this, 8))

        val wInputRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val dailyWEd = UiKit.numericSetInputBox(
            this,
            curWDisp.toString(),
            weightUnit,
            InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        ).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        wInputRow.addView(UiKit.outlineButton(this, "-0.2") {
            val v = (dailyWEd.text.toString().toDoubleOrNull() ?: curWDisp) - 0.2
            val newKg = if (weightUnit == "lb") v / 2.20462 else v
            db.saveDailyMetrics(weightRecordMetrics.copy(bodyweightKg = ((newKg.coerceIn(30.0, 260.0)) * 10.0).roundToInt() / 10.0))
            HyperLogStreakWidgetProvider.refreshAllWidgets(this)
            HyperLogStorageManager.saveDatabaseSnapshotAsync(this, db)
            if (hapticEnabled) NativeHardwareBridge.hapticTick(this)
            renderActivePage()
        })
        wInputRow.addView(UiKit.spacerH(this, 5))
        wInputRow.addView(dailyWEd)
        wInputRow.addView(UiKit.spacerH(this, 5))
        wInputRow.addView(UiKit.outlineButton(this, "+0.2") {
            val v = (dailyWEd.text.toString().toDoubleOrNull() ?: curWDisp) + 0.2
            val newKg = if (weightUnit == "lb") v / 2.20462 else v
            db.saveDailyMetrics(weightRecordMetrics.copy(bodyweightKg = ((newKg.coerceIn(30.0, 260.0)) * 10.0).roundToInt() / 10.0))
            HyperLogStreakWidgetProvider.refreshAllWidgets(this)
            HyperLogStorageManager.saveDatabaseSnapshotAsync(this, db)
            if (hapticEnabled) NativeHardwareBridge.hapticTick(this)
            renderActivePage()
        })
        wInputRow.addView(UiKit.spacerH(this, 6))
        wInputRow.addView(UiKit.primaryButton(this, "Save Weight", UiKit.COL_ACCENT) {
            val typed = dailyWEd.text.toString().toDoubleOrNull() ?: curWDisp
            val newKg = if (weightUnit == "lb") typed / 2.20462 else typed
            val cleanKg = (newKg.coerceIn(30.0, 260.0) * 10.0).roundToInt() / 10.0
            db.saveDailyMetrics(weightRecordMetrics.copy(bodyweightKg = cleanKg))
            HyperLogStreakWidgetProvider.refreshAllWidgets(this)
            HyperLogStorageManager.saveDatabaseSnapshotAsync(this, db)
            if (hapticEnabled) NativeHardwareBridge.hapticTick(this)
            showBanner("Saved bodyweight ($typed $weightUnit) for $weightInputDateIso")
            renderActivePage()
        })
        weightCard.addView(wInputRow)
        pageContent.addView(weightCard)

        val trendRecords = db.getNutritionWeightTrend(nutritionChartDays)
        val chartCard = UiKit.card(this, padDp = 13)
        val chartHead = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val chartLeft = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        chartLeft.addView(UiKit.text(this, "Bodyweight vs. Time & Caloric Intake", 14.5f, UiKit.COL_TEXT_DARK, bold = true))
        chartLeft.addView(UiKit.text(this, "Emerald line: Weight ($weightUnit) · Blue line: Daily kcal · Dashed: Target", 11f, UiKit.COL_TEXT_MUTED))
        chartHead.addView(chartLeft)
        listOf(7 to "7D", 10 to "10D", 14 to "14D").forEach { (dCnt, lbl) ->
            chartHead.addView(UiKit.chip(this, lbl, nutritionChartDays == dCnt) {
                nutritionChartDays = dCnt
                renderActivePage()
            })
            chartHead.addView(UiKit.spacerH(this, 4))
        }
        chartCard.addView(chartHead)
        chartCard.addView(UiKit.spacerV(this, 8))
        chartCard.addView(createNutritionWeightChartView(trendRecords, targetKcal))
        pageContent.addView(chartCard)

        // 2C. Daily Nutrition Tracking by Meal Type with Per-Slot 'Quick Add' Dropdown Modal
        val mealSlotsCard = UiKit.card(this, padDp = 13)
        val slotsHead = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        slotsHead.addView(UiKit.text(this, "Daily Nutrition by Meal Type", 14.5f, UiKit.COL_TEXT_DARK, bold = true).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        slotsHead.addView(UiKit.chip(this, "Indian Recipes →", false) {
            wellnessSubTab = "indian"
            renderActivePage()
        })
        mealSlotsCard.addView(slotsHead)
        mealSlotsCard.addView(UiKit.text(this, "Tap Quick Add next to any meal type to open your Saved Custom Meals dropdown", 11.5f, UiKit.COL_TEXT_MUTED))
        mealSlotsCard.addView(UiKit.spacerV(this, 8))

        val mealTypesList = listOf("Breakfast", "Lunch", "Pre-Workout", "Post-Workout", "Dinner", "Snack")
        mealTypesList.forEachIndexed { idx, slotType ->
            val slotMeals = meals.filter { it.mealType.equals(slotType, ignoreCase = true) }
            val slotKcal = slotMeals.sumOf { it.calories }
            val slotProt = slotMeals.sumOf { it.proteinG }

            val slotRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = UiKit.roundedBg(UiKit.COL_SUBTLE, 10f, this@MainActivity, UiKit.COL_BORDER, 1f)
                val p = UiKit.rdp(this@MainActivity, 9)
                setPadding(p, p, p, p)
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                    if (idx < mealTypesList.lastIndex) bottomMargin = UiKit.rdp(this@MainActivity, 6)
                }
            }
            val slotCol = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            slotCol.addView(UiKit.text(this, slotType, 13.5f, UiKit.COL_TEXT_DARK, bold = true))
            val slotSummary = if (slotMeals.isEmpty()) {
                "No items logged yet"
            } else {
                "${slotMeals.size} item(s) · $slotKcal kcal · P ${slotProt}g"
            }
            slotCol.addView(UiKit.text(this, slotSummary, 11f, UiKit.COL_TEXT_MUTED, tabular = true))
            slotRow.addView(slotCol)
            slotRow.addView(UiKit.outlineButton(this, "Quick Add ▾", UiKit.COL_ACCENT) {
                showQuickAddMealSlotDialog(slotType, savedCustomMeals)
            })
            mealSlotsCard.addView(slotRow)
        }
        pageContent.addView(mealSlotsCard)

        // 3. 1-Tap Quick Meals (Primary fast logging action right near the top!)
        val presetCard = UiKit.card(this, padDp = 13)
        presetCard.addView(UiKit.text(this, "Quick Log Saved Meals", 14.5f, UiKit.COL_TEXT_DARK, bold = true))
        presetCard.addView(UiKit.spacerV(this, 6))
        val (pScroll, pRow) = UiKit.hScrollRow(this)
        savedCustomMeals.forEach { scm ->
            pRow.addView(UiKit.outlineButton(this, "+ ${scm.name} (${scm.calories})") {
                db.saveMeal(
                    MealLog(
                        "meal_${System.currentTimeMillis()}",
                        selectedDateIso,
                        scm.mealType,
                        scm.name,
                        scm.calories,
                        scm.proteinG,
                        scm.carbsG,
                        scm.fatG,
                        System.currentTimeMillis()
                    ),
                    notifyWidget = false
                )
                HyperLogStreakWidgetProvider.onMealSaved(this)
                HyperLogStorageManager.saveDatabaseSnapshotAsync(this, db)
                if (hapticEnabled) NativeHardwareBridge.hapticTick(this)
                showBanner("Logged '${scm.name}' (${scm.calories} kcal)")
                renderActivePage()
            })
            pRow.addView(UiKit.spacerH(this, 6))
        }
        presetCard.addView(pScroll)
        presetCard.addView(UiKit.spacerV(this, 10))

        // Clean 2-Button Progressive Disclosure Row: Custom Meal Builder | TDEE Calculator
        val toolsBtnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        toolsBtnRow.addView(UiKit.primaryButton(
            this,
            if (mealBuilderExpanded) "Hide Meal Builder" else "+ Custom Meal",
            UiKit.COL_ACCENT
        ) {
            mealBuilderExpanded = !mealBuilderExpanded
            renderActivePage()
        }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.15f).apply {
                rightMargin = UiKit.rdp(this@MainActivity, 6)
            }
        })
        toolsBtnRow.addView(UiKit.outlineButton(
            this,
            if (showCalculatorPanel) "Hide TDEE Calc" else "TDEE Calculator",
            UiKit.COL_ACCENT
        ) {
            showCalculatorPanel = !showCalculatorPanel
            renderActivePage()
        }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.95f)
        })
        presetCard.addView(toolsBtnRow)
        pageContent.addView(presetCard)

        // 4. Expandable TDEE Calorie Calculator
        if (showCalculatorPanel) {
            renderOfflineCalorieCalculatorCard(metrics)
        }

        // 5. Expandable Offline Custom Meal Builder (Includes Indian Foods + Live 4P+4C+9F Auto-Calc)
        if (mealBuilderExpanded) {
            renderRedesignedMealBuilderCard()
        }

        // 6. Logged Meals List for Selected Date
        pageContent.addView(UiKit.text(this, "Logged Meals · $selectedDateIso (${meals.size})", 14.5f, UiKit.COL_TEXT_DARK, bold = true))
        pageContent.addView(UiKit.spacerV(this, 6))

        if (meals.isEmpty()) {
            val emptyCard = UiKit.card(this, padDp = 13)
            emptyCard.addView(UiKit.text(this, "No meals logged for $selectedDateIso yet. Tap Quick Add above or explore Indian Meals.", 12f, UiKit.COL_TEXT_MUTED))
            pageContent.addView(emptyCard)
        } else {
            meals.forEach { m ->
                val mc = UiKit.card(this, padDp = 12)
                val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                val left = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                left.addView(UiKit.text(this, "${m.mealType} · ${m.name}", 13.5f, UiKit.COL_TEXT_DARK, bold = true))
                left.addView(UiKit.text(this, "${m.calories} kcal · P ${m.proteinG}g · C ${m.carbsG}g · F ${m.fatG}g", 11.5f, UiKit.COL_TEXT_MUTED, tabular = true))
                r.addView(left)
                r.addView(UiKit.outlineButton(this, "Delete", 0xFFEF4444.toInt()) {
                    db.deleteMeal(m.id, notifyWidget = false)
                    HyperLogStreakWidgetProvider.onMealSaved(this)
                    HyperLogStorageManager.saveDatabaseSnapshotAsync(this, db)
                    renderActivePage()
                })
                mc.addView(r)
                pageContent.addView(mc)
            }
        }
    }

    private fun renderIndianNutritionSection() {
        val allRecipes = SeedCatalog.indianRecipes()
        val indianFoods = SeedCatalog.offlineFoods().filter { it.category.equals("Indian Foods", ignoreCase = true) }

        val introCard = UiKit.card(this, borderColor = UiKit.COL_ACCENT, borderDp = 1.3f, padDp = 14)
        introCard.addView(UiKit.text(this, "Indian Nutrition, Meals & Recipes", 16.5f, UiKit.COL_TEXT_DARK, bold = true))
        introCard.addView(UiKit.spacerV(this, 3))
        introCard.addView(UiKit.text(
            this,
            "High-protein North, South, West & Pan-Indian meals with step-by-step instructions across Vegetarian, Vegan, Eggetarian, and Non-Veg diets.",
            11.5f,
            UiKit.COL_TEXT_MUTED
        ))
        introCard.addView(UiKit.spacerV(this, 10))

        // Dietary Preference Filter Chips
        val (dietScroll, dietRow) = UiKit.hScrollRow(this)
        listOf("All", "Vegetarian", "High-Protein Veg", "Vegan", "Eggetarian", "Non-Vegetarian").forEach { tag ->
            dietRow.addView(UiKit.chip(this, tag, indianDietFilter == tag) {
                indianDietFilter = tag
                renderActivePage()
            })
            dietRow.addView(UiKit.spacerH(this, 6))
        }
        introCard.addView(dietScroll)
        introCard.addView(UiKit.spacerV(this, 8))

        val qRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val qEd = UiKit.inputBox(this, indianRecipeQuery, "Search paneer, soya, dosa, dal, chicken, egg...", InputType.TYPE_CLASS_TEXT).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        qRow.addView(qEd)
        qRow.addView(UiKit.spacerH(this, 6))
        qRow.addView(UiKit.outlineButton(this, "Search", UiKit.COL_ACCENT) {
            indianRecipeQuery = qEd.text.toString().trim()
            renderActivePage()
        })
        if (indianRecipeQuery.isNotBlank()) {
            qRow.addView(UiKit.spacerH(this, 4))
            qRow.addView(UiKit.outlineButton(this, "✕") {
                indianRecipeQuery = ""
                renderActivePage()
            })
        }
        introCard.addView(qRow)
        pageContent.addView(introCard)

        // 1-Tap Authentic Indian Staple Whole Foods Strip
        if (indianFoods.isNotEmpty()) {
            val staplesCard = UiKit.card(this, padDp = 13)
            val stHead = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            stHead.addView(UiKit.text(this, "1-Tap Indian Staple Foods (${indianFoods.size})", 14f, UiKit.COL_TEXT_DARK, bold = true).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            stHead.addView(UiKit.chip(this, "Open in Meal Builder", false) {
                wellnessSubTab = "nutrition"
                mealBuilderExpanded = true
                builderFoodCategory = "Indian Foods"
                renderActivePage()
            })
            staplesCard.addView(stHead)
            staplesCard.addView(UiKit.spacerV(this, 6))

            val (fScroll, fRow) = UiKit.hScrollRow(this)
            indianFoods.forEach { fd ->
                fRow.addView(UiKit.outlineButton(this, "+ ${fd.name.substringBefore(" (")} (${fd.kcalPerBase})") {
                    db.saveMeal(
                        MealLog(
                            id = "meal_${System.currentTimeMillis()}",
                            dateIso = selectedDateIso,
                            mealType = "Dinner",
                            name = "${fd.name} (${fd.unitHint})",
                            calories = fd.kcalPerBase,
                            proteinG = fd.proteinPerBase.roundToInt(),
                            carbsG = fd.carbsPerBase.roundToInt(),
                            fatG = fd.fatPerBase.roundToInt(),
                            loggedAtEpochMs = System.currentTimeMillis()
                        ),
                        notifyWidget = false
                    )
                    HyperLogStreakWidgetProvider.onMealSaved(this)
                    HyperLogStorageManager.saveDatabaseSnapshotAsync(this, db)
                    if (hapticEnabled) NativeHardwareBridge.hapticTick(this)
                    showBanner("Logged '${fd.name}' (${fd.kcalPerBase} kcal) on $selectedDateIso")
                })
                fRow.addView(UiKit.spacerH(this, 6))
            }
            staplesCard.addView(fScroll)
            pageContent.addView(staplesCard)
        }

        // Filtered Indian Recipes List (26 Curated Regional Indian Recipes)
        val q = indianRecipeQuery.trim().lowercase(Locale.US)
        val filteredRecipes = allRecipes.filter { r ->
            val dietOk = r.matchesDietFilter(indianDietFilter)
            val qOk = q.isEmpty() ||
                r.name.lowercase(Locale.US).contains(q) ||
                r.region.lowercase(Locale.US).contains(q) ||
                r.mealType.lowercase(Locale.US).contains(q) ||
                r.summary.lowercase(Locale.US).contains(q) ||
                r.dietaryTags.any { it.lowercase(Locale.US).contains(q) } ||
                r.ingredients.any { it.lowercase(Locale.US).contains(q) }
            dietOk && qOk
        }

        // Collapsible Regional Indian Cooking Styles & Video Guides Showcase
        val cookingStyleVideos = listOf(
            Triple("Tandoori & Air-Fryer Chargrill", "Paneer Tikka · Tandoori Chicken Breast", "https://www.youtube.com/results?search_query=high+protein+indian+tandoori+paneer+chicken+tikka+recipe"),
            Triple("North Indian Double-Tadka Legumes", "Dal Tadka · Punjabi Rajma · Chana Masala", "https://www.youtube.com/results?search_query=dhaba+style+double+tadka+dal+rajma+high+protein+recipe"),
            Triple("South Indian Fermented & Tawa Batter", "Green Moong Pesarattu · Ragi Dosa · Idli Sambar", "https://www.youtube.com/results?search_query=crispy+green+moong+pesarattu+high+protein+dosa+recipe"),
            Triple("Iron-Skillet Greens & Millet Bhakri", "Lasooni Palak Paneer · Jowar & Bajra Bhakri", "https://www.youtube.com/results?search_query=lasooni+palak+paneer+jowar+bhakri+healthy+indian+recipe"),
            Triple("Mumbai Street Tawa & Sprout Chaat", "Masala Egg Bhurji · Moong Sprouts Bhel Chaat", "https://www.youtube.com/results?search_query=mumbai+masala+egg+bhurji+sprouts+chaat+high+protein+recipe"),
            Triple("Coastal Curry-Leaf & Chettinad Roast", "Kerala Fish Molee · Chettinad Pepper Chicken", "https://www.youtube.com/results?search_query=authentic+kerala+fish+curry+chettinad+pepper+chicken+recipe")
        )
        val videosExpanded = "indian_videos" in expandedWellnessDropdownKeys
        val (vidDropCard, vidDropBody) = UiKit.collapsibleDropdownCard(
            ctx = this,
            title = "Indian Cooking Styles & Video Guides",
            subtitle = "6 regional cooking styles — Tandoori, Tadka, Fermented Dosa, Bhakri, Tawa & Coastal",
            expanded = videosExpanded,
            badgeText = "6 Videos"
        ) {
            if (videosExpanded) expandedWellnessDropdownKeys.remove("indian_videos")
            else expandedWellnessDropdownKeys.add("indian_videos")
            renderActivePage()
        }
        cookingStyleVideos.forEach { (styleTitle, dishesSub, url) ->
            val vRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = UiKit.roundedBg(UiKit.COL_SUBTLE, 10f, this@MainActivity, UiKit.COL_BORDER, 1f)
                val px = UiKit.rdp(this@MainActivity, 10)
                val py = UiKit.rdp(this@MainActivity, 8)
                setPadding(px, py, px, py)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = UiKit.rdp(this@MainActivity, 6)
                }
            }
            val vCol = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            vCol.addView(UiKit.text(this, styleTitle, 12.5f, UiKit.COL_TEXT_DARK, bold = true))
            vCol.addView(UiKit.text(this, dishesSub, 11f, UiKit.COL_TEXT_MUTED))
            vRow.addView(vCol)
            vRow.addView(UiKit.outlineButton(this, "▶ Watch", UiKit.COL_ACCENT) {
                runCatching {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                }.onFailure {
                    showBanner("Unable to open video link on this device.")
                }
            })
            vidDropBody.addView(vRow)
        }
        pageContent.addView(vidDropCard)

        pageContent.addView(UiKit.text(
            this,
            "Step-by-Step Indian Recipes (${filteredRecipes.size} of ${allRecipes.size})",
            14.5f,
            UiKit.COL_TEXT_DARK,
            bold = true,
            tabular = true
        ))
        pageContent.addView(UiKit.spacerV(this, 6))

        filteredRecipes.forEach { rec ->
            val rc = UiKit.card(this, padDp = 14)
            val tagsLabel = rec.dietaryTags.distinct().joinToString(" · ")
            rc.addView(UiKit.text(
                this,
                "$tagsLabel · ${rec.region} · ${rec.resolvedCookingStyle()} · ${rec.prepMinutes + rec.cookMinutes} min",
                11f,
                UiKit.COL_ACCENT,
                bold = true,
                tabular = true
            ))
            rc.addView(UiKit.spacerV(this, 2))
            rc.addView(UiKit.text(this, rec.name, 15.5f, UiKit.COL_TEXT_DARK, bold = true))
            rc.addView(UiKit.spacerV(this, 3))
            rc.addView(UiKit.text(this, rec.summary, 12f, UiKit.COL_TEXT_MUTED))
            rc.addView(UiKit.spacerV(this, 7))
            rc.addView(UiKit.text(
                this,
                "${rec.calories} kcal · Protein ${rec.proteinG}g · Carbs ${rec.carbsG}g · Fat ${rec.fatG}g",
                12.5f,
                UiKit.COL_TEXT_DARK,
                bold = true,
                tabular = true
            ))
            rc.addView(UiKit.spacerV(this, 9))

            val (bScroll, bRow) = UiKit.hScrollRow(this)
            bRow.addView(UiKit.primaryButton(this, "+ Log Meal", UiKit.COL_ACCENT) {
                db.saveMeal(
                    MealLog(
                        id = "meal_${System.currentTimeMillis()}",
                        dateIso = selectedDateIso,
                        mealType = rec.mealType,
                        name = rec.name,
                        calories = rec.calories,
                        proteinG = rec.proteinG,
                        carbsG = rec.carbsG,
                        fatG = rec.fatG,
                        loggedAtEpochMs = System.currentTimeMillis()
                    ),
                    notifyWidget = false
                )
                HyperLogStreakWidgetProvider.onMealSaved(this)
                HyperLogStorageManager.saveDatabaseSnapshotAsync(this, db)
                if (hapticEnabled) NativeHardwareBridge.hapticTick(this)
                showBanner("Logged '${rec.name}' (${rec.calories} kcal) to ${rec.mealType}")
            })
            bRow.addView(UiKit.spacerH(this, 6))
            bRow.addView(UiKit.outlineButton(this, "▶ Recipe Video", UiKit.COL_ACCENT) {
                runCatching {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(rec.resolvedVideoUrl())))
                }.onFailure {
                    showBanner("Could not open browser for recipe video.")
                }
            })
            bRow.addView(UiKit.spacerH(this, 6))
            bRow.addView(UiKit.outlineButton(this, "View Steps", UiKit.COL_ACCENT) {
                showIndianRecipeDialog(rec)
            })
            bRow.addView(UiKit.spacerH(this, 6))
            bRow.addView(UiKit.outlineButton(this, "Save to Quick Add") {
                db.saveCustomMealPreset(
                    SavedCustomMeal(
                        id = "scm_${rec.id}",
                        name = rec.name,
                        mealType = rec.mealType,
                        calories = rec.calories,
                        proteinG = rec.proteinG,
                        carbsG = rec.carbsG,
                        fatG = rec.fatG,
                        ingredientsSummary = rec.ingredients.take(3).joinToString(", ")
                    )
                )
                HyperLogStorageManager.saveDatabaseSnapshotAsync(this, db)
                if (hapticEnabled) NativeHardwareBridge.hapticTick(this)
                showBanner("Saved '${rec.name}' to Quick Add Custom Meals!")
            })
            rc.addView(bScroll)
            pageContent.addView(rc)
        }
    }

    private fun showIndianRecipeDialog(rec: IndianRecipe) {
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = UiKit.dp(this@MainActivity, 16)
            setPadding(p, p, p, p)
        }
        scroll.addView(box)

        box.addView(UiKit.text(
            this,
            "${rec.dietaryTag} · ${rec.region} · ${rec.resolvedCookingStyle()} · Prep ${rec.prepMinutes}m · Cook ${rec.cookMinutes}m",
            11.5f,
            UiKit.COL_ACCENT,
            bold = true,
            tabular = true
        ))
        box.addView(UiKit.spacerV(this, 4))
        box.addView(UiKit.text(
            this,
            "${rec.calories} kcal · P ${rec.proteinG}g · C ${rec.carbsG}g · F ${rec.fatG}g",
            13f,
            UiKit.COL_TEXT_DARK,
            bold = true,
            tabular = true
        ))
        box.addView(UiKit.spacerV(this, 6))
        box.addView(UiKit.text(this, rec.summary, 12f, UiKit.COL_TEXT_MID))
        box.addView(UiKit.spacerV(this, 8))
        box.addView(UiKit.outlineButton(this, "▶ Watch ${rec.resolvedCookingStyle()} Video Guide", UiKit.COL_ACCENT) {
            runCatching {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(rec.resolvedVideoUrl())))
            }
        })
        box.addView(UiKit.spacerV(this, 10))

        box.addView(UiKit.text(this, "Ingredients (${rec.ingredients.size})", 13f, UiKit.COL_TEXT_DARK, bold = true))
        box.addView(UiKit.spacerV(this, 4))
        rec.ingredients.forEach { ing ->
            box.addView(UiKit.text(this, "• $ing", 12f, UiKit.COL_TEXT_MID))
            box.addView(UiKit.spacerV(this, 2))
        }
        box.addView(UiKit.spacerV(this, 10))

        box.addView(UiKit.text(this, "Step-by-Step Instructions", 13f, UiKit.COL_TEXT_DARK, bold = true))
        box.addView(UiKit.spacerV(this, 4))
        rec.steps.forEachIndexed { idx, step ->
            box.addView(UiKit.text(this, "${idx + 1}. $step", 12f, UiKit.COL_TEXT_DARK))
            box.addView(UiKit.spacerV(this, 5))
        }

        AlertDialog.Builder(this, UiKit.dialogTheme())
            .setTitle(rec.name)
            .setView(scroll)
            .setPositiveButton("+ Log Meal") { _, _ ->
                db.saveMeal(
                    MealLog(
                        id = "meal_${System.currentTimeMillis()}",
                        dateIso = selectedDateIso,
                        mealType = rec.mealType,
                        name = rec.name,
                        calories = rec.calories,
                        proteinG = rec.proteinG,
                        carbsG = rec.carbsG,
                        fatG = rec.fatG,
                        loggedAtEpochMs = System.currentTimeMillis()
                    ),
                    notifyWidget = false
                )
                HyperLogStreakWidgetProvider.onMealSaved(this)
                HyperLogStorageManager.saveDatabaseSnapshotAsync(this, db)
                showBanner("Logged '${rec.name}' (${rec.calories} kcal) on $selectedDateIso")
                renderActivePage()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showQuickAddMealSlotDialog(slotType: String, savedMeals: List<SavedCustomMeal>) {
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = UiKit.dp(this@MainActivity, 16)
            setPadding(p, p, p, p)
        }
        scroll.addView(box)

        lateinit var dialogRef: AlertDialog

        box.addView(UiKit.text(
            this,
            "Select a saved custom meal below to append it to $slotType ($selectedDateIso) immediately.",
            12f,
            UiKit.COL_TEXT_MUTED
        ))
        box.addView(UiKit.spacerV(this, 10))

        if (savedMeals.isEmpty()) {
            box.addView(UiKit.text(this, "No saved custom meals yet. Create one in Custom Meal Builder or save any Indian Recipe.", 12f, UiKit.COL_TEXT_MID))
        } else {
            savedMeals.forEach { picked ->
                val itemRow = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    background = UiKit.roundedBg(UiKit.COL_SUBTLE, 10f, this@MainActivity, UiKit.COL_BORDER, 1f)
                    val p = UiKit.rdp(this@MainActivity, 10)
                    setPadding(p, p, p, p)
                    layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                        bottomMargin = UiKit.rdp(this@MainActivity, 7)
                    }
                    setOnClickListener {
                        db.saveMeal(
                            MealLog(
                                id = "meal_${System.currentTimeMillis()}",
                                dateIso = selectedDateIso,
                                mealType = slotType,
                                name = picked.name,
                                calories = picked.calories,
                                proteinG = picked.proteinG,
                                carbsG = picked.carbsG,
                                fatG = picked.fatG,
                                loggedAtEpochMs = System.currentTimeMillis()
                            ),
                            notifyWidget = false
                        )
                        HyperLogStreakWidgetProvider.onMealSaved(this@MainActivity)
                        HyperLogStorageManager.saveDatabaseSnapshotAsync(this@MainActivity, db)
                        if (hapticEnabled) NativeHardwareBridge.hapticTick(this@MainActivity)
                        dialogRef.dismiss()
                        showBanner("✓ Quick-added '${picked.name}' (${picked.calories} kcal) to $slotType")
                        renderActivePage()
                    }
                }
                val col = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                col.addView(UiKit.text(this, picked.name, 13.5f, UiKit.COL_TEXT_DARK, bold = true))
                col.addView(UiKit.text(
                    this,
                    "${picked.calories} kcal · P ${picked.proteinG}g · C ${picked.carbsG}g · F ${picked.fatG}g",
                    11.5f,
                    UiKit.COL_ACCENT,
                    bold = true,
                    tabular = true
                ))
                if (picked.ingredientsSummary.isNotBlank()) {
                    col.addView(UiKit.text(this, picked.ingredientsSummary, 10.5f, UiKit.COL_TEXT_MUTED).apply { maxLines = 1 })
                }
                itemRow.addView(col)
                itemRow.addView(UiKit.text(this, "+ Add", 12f, 0xFF059669.toInt(), bold = true))
                box.addView(itemRow)
            }
        }

        dialogRef = AlertDialog.Builder(this, UiKit.dialogTheme())
            .setTitle("Quick Add · $slotType")
            .setView(scroll)
            .setNeutralButton("+ New Custom Meal") { _, _ ->
                builderMealType = slotType
                mealBuilderExpanded = true
                renderActivePage()
            }
            .setNegativeButton("Close", null)
            .create()
        dialogRef.show()
    }

    private fun createNutritionWeightChartView(
        records: List<Triple<String, Double, Int>>,
        targetKcal: Int
    ): View {
        val heightPx = UiKit.rdp(this, 185)
        return object : View(this) {
            override fun onDraw(canvas: android.graphics.Canvas) {
                super.onDraw(canvas)
                if (records.isEmpty() || width <= 0 || height <= 0) return
                val padL = UiKit.dp(context, 36).toFloat()
                val padR = UiKit.dp(context, 38).toFloat()
                val padT = UiKit.dp(context, 16).toFloat()
                val padB = UiKit.dp(context, 24).toFloat()
                val plotW = (width - padL - padR).coerceAtLeast(10f)
                val plotH = (height - padT - padB).coerceAtLeast(10f)

                val maxKcal = maxOf(targetKcal, records.maxOf { it.third }, 2200) * 1.12f
                val weightsDisp = records.map { (_, kg, _) ->
                    if (weightUnit == "lb") kg * 2.20462 else kg
                }
                val minW = (weightsDisp.minOrNull() ?: 70.0) - 0.8
                val maxW = (weightsDisp.maxOrNull() ?: 85.0) + 0.8
                val spanW = (maxW - minW).coerceAtLeast(1.0)

                val gridPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                    color = UiKit.COL_BORDER
                    strokeWidth = UiKit.dp(context, 1).toFloat()
                }
                canvas.drawLine(padL, padT + plotH, padL + plotW, padT + plotH, gridPaint)

                // Dashed Target Calorie Reference Line
                val targetY = padT + plotH * (1f - (targetKcal / maxKcal).coerceIn(0f, 1f))
                val refPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                    color = 0xFF94A3B8.toInt()
                    strokeWidth = UiKit.dp(context, 1).toFloat()
                    style = android.graphics.Paint.Style.STROKE
                    pathEffect = android.graphics.DashPathEffect(floatArrayOf(10f, 8f), 0f)
                }
                val refPath = android.graphics.Path().apply {
                    moveTo(padL, targetY)
                    lineTo(padL + plotW, targetY)
                }
                canvas.drawPath(refPath, refPaint)

                val kcalLinePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                    color = 0xFF3B82F6.toInt()
                    strokeWidth = UiKit.dp(context, 2).toFloat()
                    style = android.graphics.Paint.Style.STROKE
                }
                val kcalDotPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                    color = 0xFF3B82F6.toInt()
                    style = android.graphics.Paint.Style.FILL
                }
                val weightLinePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                    color = 0xFF059669.toInt()
                    strokeWidth = UiKit.dp(context, 2.5f.roundToInt()).toFloat()
                    style = android.graphics.Paint.Style.STROKE
                }
                val weightDotPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                    color = 0xFF059669.toInt()
                    style = android.graphics.Paint.Style.FILL
                }
                val labelPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                    color = UiKit.COL_TEXT_MUTED
                    textSize = UiKit.dp(context, 9).toFloat()
                }

                val stepX = plotW / records.size.coerceAtLeast(1)
                val weightPath = android.graphics.Path()
                val kcalPath = android.graphics.Path()

                records.forEachIndexed { i, (dateIso, _, kcal) ->
                    val cx = padL + stepX * (i + 0.5f)
                    val ky = padT + plotH * (1f - (kcal / maxKcal).coerceIn(0f, 1f))
                    if (i == 0) kcalPath.moveTo(cx, ky) else kcalPath.lineTo(cx, ky)

                    val wVal = weightsDisp[i]
                    val wy = (padT + plotH * (1.0 - (wVal - minW) / spanW)).toFloat()
                    if (i == 0) weightPath.moveTo(cx, wy) else weightPath.lineTo(cx, wy)

                    if (i == 0 || i == records.lastIndex || i % 3 == 0) {
                        val shortDate = if (dateIso.length >= 10) dateIso.substring(5) else dateIso
                        val tw = labelPaint.measureText(shortDate)
                        canvas.drawText(shortDate, cx - tw / 2f, padT + plotH + UiKit.dp(context, 14), labelPaint)
                    }
                }
                canvas.drawPath(kcalPath, kcalLinePaint)
                canvas.drawPath(weightPath, weightLinePaint)

                records.forEachIndexed { i, (_, _, kcal) ->
                    val cx = padL + stepX * (i + 0.5f)
                    val ky = padT + plotH * (1f - (kcal / maxKcal).coerceIn(0f, 1f))
                    val wy = (padT + plotH * (1.0 - (weightsDisp[i] - minW) / spanW)).toFloat()
                    canvas.drawCircle(cx, ky, UiKit.dp(context, 2).toFloat(), kcalDotPaint)
                    canvas.drawCircle(cx, wy, UiKit.dp(context, 3).toFloat(), weightDotPaint)
                }

                canvas.drawText("${targetKcal}k", 2f, targetY + UiKit.dp(context, 3), labelPaint)
                val latestW = ((weightsDisp.lastOrNull() ?: 0.0) * 10.0).roundToInt() / 10.0
                canvas.drawText("$latestW$weightUnit", padL + plotW + 3f, padT + UiKit.dp(context, 10), labelPaint)
            }
        }.apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, heightPx)
        }
    }

    private fun renderOfflineCalorieCalculatorCard(currentMetrics: DailyMetrics) {
        val card = UiKit.card(this, borderColor = UiKit.COL_ACCENT, borderDp = 1.5f, padDp = 14)

        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val hLeft = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        hLeft.addView(UiKit.text(this, "Offline Calorie & Macro Calculator", 16f, UiKit.COL_TEXT_DARK, bold = true))
        hLeft.addView(UiKit.text(this, "Mifflin-St Jeor BMR · 100% On-Device Calculation", 11.5f, UiKit.COL_TEXT_MUTED))
        head.addView(hLeft)
        head.addView(UiKit.outlineButton(this, "Close") {
            showCalculatorPanel = false
            renderActivePage()
        })
        card.addView(head)
        card.addView(UiKit.spacerV(this, 10))

        // Sex Selector
        card.addView(UiKit.text(this, "Biological Sex", 11f, UiKit.COL_TEXT_MUTED, bold = true))
        card.addView(UiKit.spacerV(this, 4))
        val sexRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("male" to "Male", "female" to "Female").forEachIndexed { idx, (id, lbl) ->
            sexRow.addView(UiKit.chip(this, lbl, calcSex == id) {
                calcSex = id; savePrefs(); renderActivePage()
            }.apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    if (idx == 0) rightMargin = UiKit.rdp(this@MainActivity, 6)
                }
            })
        }
        card.addView(sexRow)
        card.addView(UiKit.spacerV(this, 8))

        // Weight, Height, Age Inputs (3-column responsive grid)
        val dispW = if (weightUnit == "lb") ((calcWeightKg * 2.20462 * 10.0).roundToInt() / 10.0).toString()
        else ((calcWeightKg * 10.0).roundToInt() / 10.0).toString()

        val dimRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        val wCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                rightMargin = UiKit.rdp(this@MainActivity, 6)
            }
        }
        wCol.addView(UiKit.text(this, "Weight ($weightUnit)", 11f, UiKit.COL_TEXT_MUTED, bold = true))
        val wEd = UiKit.inputBox(this, dispW, weightUnit, InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        wCol.addView(wEd)

        val hCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                rightMargin = UiKit.rdp(this@MainActivity, 6)
            }
        }
        hCol.addView(UiKit.text(this, "Height (cm)", 11f, UiKit.COL_TEXT_MUTED, bold = true))
        val hEd = UiKit.inputBox(this, calcHeightCm.roundToInt().toString(), "cm", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        hCol.addView(hEd)

        val aCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.85f)
        }
        aCol.addView(UiKit.text(this, "Age (yrs)", 11f, UiKit.COL_TEXT_MUTED, bold = true))
        val aEd = UiKit.inputBox(this, calcAgeYears.toString(), "Age", InputType.TYPE_CLASS_NUMBER)
        aCol.addView(aEd)

        dimRow.addView(wCol); dimRow.addView(hCol); dimRow.addView(aCol)
        card.addView(dimRow)
        card.addView(UiKit.spacerV(this, 8))

        // Activity Level Chips
        card.addView(UiKit.text(this, "Activity Level", 11f, UiKit.COL_TEXT_MUTED, bold = true))
        card.addView(UiKit.spacerV(this, 4))
        val (actScroll, actRow) = UiKit.hScrollRow(this)
        ActivityLevelOption.entries.forEach { opt ->
            actRow.addView(UiKit.chip(this, opt.shortLabel, calcActivityId == opt.id) {
                wEd.text.toString().toDoubleOrNull()?.let { v -> calcWeightKg = if (weightUnit == "lb") v / 2.20462 else v }
                hEd.text.toString().toDoubleOrNull()?.let { v -> calcHeightCm = v }
                aEd.text.toString().toIntOrNull()?.let { v -> calcAgeYears = v }
                calcActivityId = opt.id
                savePrefs()
                renderActivePage()
            })
            actRow.addView(UiKit.spacerH(this, 6))
        }
        card.addView(actScroll)
        card.addView(UiKit.text(this, ActivityLevelOption.fromId(calcActivityId).detail, 11f, UiKit.COL_TEXT_MUTED))
        card.addView(UiKit.spacerV(this, 8))

        // Goal Phase Chips
        card.addView(UiKit.text(this, "Hypertrophy Goal", 11f, UiKit.COL_TEXT_MUTED, bold = true))
        card.addView(UiKit.spacerV(this, 4))
        val (goalScroll, goalRow) = UiKit.hScrollRow(this)
        GoalPhaseOption.entries.forEach { gOpt ->
            goalRow.addView(UiKit.chip(this, gOpt.label, calcGoalId == gOpt.id) {
                wEd.text.toString().toDoubleOrNull()?.let { v -> calcWeightKg = if (weightUnit == "lb") v / 2.20462 else v }
                hEd.text.toString().toDoubleOrNull()?.let { v -> calcHeightCm = v }
                aEd.text.toString().toIntOrNull()?.let { v -> calcAgeYears = v }
                calcGoalId = gOpt.id
                savePrefs()
                renderActivePage()
            })
            goalRow.addView(UiKit.spacerH(this, 6))
        }
        card.addView(goalScroll)
        card.addView(UiKit.spacerV(this, 10))

        // Live Computed Result Box (updates dynamically as user types!)
        val resultBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = UiKit.roundedBg(UiKit.COL_SUBTLE, 12f, this@MainActivity, UiKit.COL_BORDER, 1f)
            val p = UiKit.rdp(this@MainActivity, 12)
            setPadding(p, p, p, p)
        }
        val resHeadline = UiKit.text(this, "", 16f, UiKit.COL_ACCENT, bold = true, tabular = true)
        val resSub = UiKit.text(this, "", 11.5f, UiKit.COL_TEXT_MID, tabular = true)
        val resMacros = UiKit.text(this, "", 12.5f, UiKit.COL_TEXT_DARK, bold = true, tabular = true)
        resultBox.addView(resHeadline)
        resultBox.addView(UiKit.spacerV(this, 2))
        resultBox.addView(resSub)
        resultBox.addView(UiKit.spacerV(this, 4))
        resultBox.addView(resMacros)
        card.addView(resultBox)

        fun recomputePreview(): CalorieCalculationResult {
            val typedW = wEd.text.toString().toDoubleOrNull()?.let { if (weightUnit == "lb") it / 2.20462 else it } ?: calcWeightKg
            val typedH = hEd.text.toString().toDoubleOrNull() ?: calcHeightCm
            val typedAge = aEd.text.toString().toIntOrNull() ?: calcAgeYears
            val res = computeOfflineCalorieTargets(
                CalorieCalculatorProfile(calcSex, typedAge, typedW, typedH, calcActivityId, calcGoalId)
            )
            resHeadline.text = "Daily Target: ${res.targetCalories} kcal / day"
            resSub.text = "BMR ${res.bmrKcal} kcal · Maintenance TDEE ${res.tdeeKcal} kcal"
            resMacros.text = "Macros: Protein ${res.proteinG}g · Carbs ${res.carbsG}g · Fat ${res.fatG}g"
            return res
        }
        recomputePreview()

        val liveWatcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { recomputePreview() }
        }
        wEd.addTextChangedListener(liveWatcher)
        hEd.addTextChangedListener(liveWatcher)
        aEd.addTextChangedListener(liveWatcher)

        card.addView(UiKit.spacerV(this, 10))
        card.addView(UiKit.primaryButton(this, "Apply Calculated Targets Offline", UiKit.COL_ACCENT) {
            wEd.text.toString().toDoubleOrNull()?.let { v -> calcWeightKg = if (weightUnit == "lb") v / 2.20462 else v }
            hEd.text.toString().toDoubleOrNull()?.let { v -> calcHeightCm = v }
            aEd.text.toString().toIntOrNull()?.let { v -> calcAgeYears = v }
            savePrefs()

            val computed = computeOfflineCalorieTargets(
                CalorieCalculatorProfile(calcSex, calcAgeYears, calcWeightKg, calcHeightCm, calcActivityId, calcGoalId)
            )
            val goalEnum = GoalPhaseOption.fromId(calcGoalId)
            db.saveDailyMetrics(
                currentMetrics.copy(
                    bodyweightKg = (calcWeightKg * 10.0).roundToInt() / 10.0,
                    phase = goalEnum.dbPhaseName,
                    baseTdee = computed.tdeeKcal,
                    proteinPerKg = computed.proteinPerKg
                )
            )
            showCalculatorPanel = false
            HyperLogStreakWidgetProvider.refreshAllWidgets(this)
            if (hapticEnabled) NativeHardwareBridge.hapticTick(this)
            showBanner("Applied ${computed.targetCalories} kcal (${computed.proteinG}P / ${computed.carbsG}C / ${computed.fatG}F) targets!")
            renderActivePage()
        })

        pageContent.addView(card)
    }

    private fun renderRedesignedMealBuilderCard() {
        val card = UiKit.card(this, padDp = 14)

        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val hLeft = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        hLeft.addView(UiKit.text(this, "Offline Custom Meal Builder", 16f, UiKit.COL_TEXT_DARK, bold = true))
        hLeft.addView(UiKit.text(this, "Pick whole foods or enter macros — calories auto-calculate live", 11.5f, UiKit.COL_TEXT_MUTED))
        head.addView(hLeft)
        head.addView(UiKit.outlineButton(this, if (mealBuilderExpanded) "Collapse" else "Expand") {
            mealBuilderExpanded = !mealBuilderExpanded
            renderActivePage()
        })
        card.addView(head)

        if (!mealBuilderExpanded) {
            pageContent.addView(card)
            return
        }

        card.addView(UiKit.spacerV(this, 10))

        // Meal Timing Chips
        val (typeScroll, typeRow) = UiKit.hScrollRow(this)
        listOf("Breakfast", "Pre-Workout", "Post-Workout", "Dinner", "Snack").forEach { mt ->
            typeRow.addView(UiKit.chip(this, mt, builderMealType == mt) {
                builderMealType = mt
                renderActivePage()
            })
            typeRow.addView(UiKit.spacerH(this, 6))
        }
        card.addView(typeScroll)
        card.addView(UiKit.spacerV(this, 8))

        // Meal Name Input
        val nameEd = UiKit.inputBox(this, builderMealName, "Meal name (e.g. Post-Workout Chicken & Rice Bowl)", InputType.TYPE_CLASS_TEXT)
        nameEd.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                builderMealName = s?.toString() ?: ""
            }
        })
        card.addView(nameEd)
        card.addView(UiKit.spacerV(this, 10))

        // Part A: Offline Food Library Search & Picker
        val libBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = UiKit.roundedBg(UiKit.COL_SUBTLE, 12f, this@MainActivity, UiKit.COL_BORDER, 1f)
            val p = UiKit.rdp(this@MainActivity, 11)
            setPadding(p, p, p, p)
        }
        libBox.addView(UiKit.text(this, "1. Add Whole Foods from Offline Catalog (${SeedCatalog.offlineFoods().size} Foods)", 12.5f, UiKit.COL_TEXT_DARK, bold = true))
        libBox.addView(UiKit.spacerV(this, 6))

        val (catScroll, catRow) = UiKit.hScrollRow(this)
        listOf("All", "Indian Foods", "Protein", "Carbs", "Fats & Dairy", "Fruit & Veg").forEach { cat ->
            catRow.addView(UiKit.chip(this, cat, builderFoodCategory == cat) {
                builderFoodCategory = cat
                renderActivePage()
            })
            catRow.addView(UiKit.spacerH(this, 5))
        }
        libBox.addView(catScroll)
        libBox.addView(UiKit.spacerV(this, 6))

        val fSearchRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val fSearchIn = UiKit.inputBox(this, builderFoodQuery, "Filter foods (chicken, rice, oats, egg, whey...)", InputType.TYPE_CLASS_TEXT).apply {
            background = UiKit.roundedBg(UiKit.COL_CARD, 9f, this@MainActivity, UiKit.COL_BORDER, 1f)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        fSearchRow.addView(fSearchIn)
        fSearchRow.addView(UiKit.spacerH(this, 6))
        fSearchRow.addView(UiKit.outlineButton(this, "Filter", UiKit.COL_ACCENT) {
            builderFoodQuery = fSearchIn.text.toString().trim()
            renderActivePage()
        })
        if (builderFoodQuery.isNotBlank()) {
            fSearchRow.addView(UiKit.spacerH(this, 4))
            fSearchRow.addView(UiKit.outlineButton(this, "✕") {
                builderFoodQuery = ""
                renderActivePage()
            })
        }
        libBox.addView(fSearchRow)
        libBox.addView(UiKit.spacerV(this, 8))

        val matchingFoods = SeedCatalog.offlineFoods().filter { f ->
            val cOk = builderFoodCategory == "All" || f.category.equals(builderFoodCategory, ignoreCase = true)
            val qOk = builderFoodQuery.isBlank() || f.name.contains(builderFoodQuery, ignoreCase = true)
            cOk && qOk
        }.take(6)

        matchingFoods.forEach { food ->
            val fRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = UiKit.roundedBg(UiKit.COL_CARD, 9f, this@MainActivity, UiKit.COL_BORDER, 1f)
                val px = UiKit.rdp(this@MainActivity, 9)
                val py = UiKit.rdp(this@MainActivity, 7)
                setPadding(px, py, px, py)
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = UiKit.rdp(this@MainActivity, 5)
                }
            }
            val infoCol = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            infoCol.addView(UiKit.text(this, food.name, 12.5f, UiKit.COL_TEXT_DARK, bold = true))
            infoCol.addView(UiKit.text(
                this,
                "${food.unitHint} · ${food.kcalPerBase} kcal (${food.proteinPerBase.roundToInt()}P/${food.carbsPerBase.roundToInt()}C/${food.fatPerBase.roundToInt()}F)",
                10.5f,
                UiKit.COL_TEXT_MUTED,
                tabular = true
            ))
            fRow.addView(infoCol)
            fRow.addView(UiKit.outlineButton(this, "+ ${food.baseGrams}g", UiKit.COL_ACCENT) {
                val existingIdx = builderIngredients.indexOfFirst { it.food.id == food.id }
                if (existingIdx >= 0) {
                    val cur = builderIngredients[existingIdx]
                    builderIngredients[existingIdx] = cur.copy(grams = cur.grams + food.baseGrams)
                } else {
                    builderIngredients.add(MealIngredientPick(food, food.baseGrams))
                }
                syncBuilderMacrosFromIngredients()
                if (hapticEnabled) NativeHardwareBridge.hapticTick(this)
                renderActivePage()
            })
            fRow.addView(UiKit.spacerH(this, 4))
            fRow.addView(UiKit.outlineButton(this, "Grams") {
                showFoodPortionDialog(food)
            })
            libBox.addView(fRow)
        }

        // Selected Ingredients Plate
        if (builderIngredients.isNotEmpty()) {
            libBox.addView(UiKit.spacerV(this, 6))
            val plateHead = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            plateHead.addView(UiKit.text(this, "Current Meal Plate (${builderIngredients.size} items)", 11.5f, UiKit.COL_ACCENT, bold = true).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            plateHead.addView(UiKit.text(this, "Clear Plate", 11f, 0xFFD97706.toInt(), bold = true).apply {
                setOnClickListener {
                    builderIngredients.clear()
                    syncBuilderMacrosFromIngredients()
                    renderActivePage()
                }
            })
            libBox.addView(plateHead)
            libBox.addView(UiKit.spacerV(this, 4))

            builderIngredients.forEachIndexed { idx, pick ->
                val m = pick.macros
                val pRow = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                }
                pRow.addView(UiKit.text(
                    this,
                    "• ${pick.food.name} (${pick.grams}g) — ${m.calories} kcal · ${m.proteinG}P/${m.carbsG}C/${m.fatG}F",
                    11.5f,
                    UiKit.COL_TEXT_DARK,
                    tabular = true
                ).apply {
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                })
                pRow.addView(UiKit.text(this, "✕", 12.5f, UiKit.COL_TEXT_MUTED, bold = true).apply {
                    val p = UiKit.dp(this@MainActivity, 6)
                    setPadding(p, p, p, p)
                    setOnClickListener {
                        builderIngredients.removeAt(idx)
                        syncBuilderMacrosFromIngredients()
                        renderActivePage()
                    }
                })
                libBox.addView(pRow)
            }
        }

        card.addView(libBox)
        card.addView(UiKit.spacerV(this, 10))

        // Part B: Direct Macro Inputs + Live 4P+4C+9F Auto-Calculated Calories
        card.addView(UiKit.text(this, "2. Macros & Auto-Calculated Calories (4×P + 4×C + 9×F)", 12.5f, UiKit.COL_TEXT_DARK, bold = true))
        card.addView(UiKit.spacerV(this, 6))

        val macroRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        fun buildMacroField(label: String, initialVal: Int, rightMarginDp: Int): Pair<LinearLayout, android.widget.EditText> {
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    if (rightMarginDp > 0) rightMargin = UiKit.rdp(this@MainActivity, rightMarginDp)
                }
            }
            col.addView(UiKit.text(this, label, 11f, UiKit.COL_TEXT_MUTED, bold = true))
            val ed = UiKit.inputBox(this, if (initialVal > 0) initialVal.toString() else "", "0", InputType.TYPE_CLASS_NUMBER)
            col.addView(ed)
            return col to ed
        }

        val (pCol, pEd) = buildMacroField("Protein (g)", builderProteinG, 6)
        val (cCol, cEd) = buildMacroField("Carbs (g)", builderCarbsG, 6)
        val (fCol, fEd) = buildMacroField("Fat (g)", builderFatG, 0)
        macroRow.addView(pCol); macroRow.addView(cCol); macroRow.addView(fCol)
        card.addView(macroRow)
        card.addView(UiKit.spacerV(this, 8))

        // Live Auto-Calculated Calorie Readout Strip
        val autoBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = UiKit.roundedBg(UiKit.COL_SUBTLE, 11f, this@MainActivity, UiKit.COL_ACCENT, 1.2f)
            val p = UiKit.rdp(this@MainActivity, 11)
            setPadding(p, p, p, p)
        }
        val autoKcalHeadline = UiKit.text(this, "", 16f, UiKit.COL_ACCENT, bold = true, tabular = true)
        val autoFormulaSub = UiKit.text(this, "", 11f, UiKit.COL_TEXT_MUTED, tabular = true)
        autoBox.addView(autoKcalHeadline)
        autoBox.addView(autoFormulaSub)

        val manualOverrideIn = UiKit.inputBox(
            this,
            if (builderManualKcal > 0) builderManualKcal.toString() else "",
            "Override calories (kcal)",
            InputType.TYPE_CLASS_NUMBER
        ).apply {
            visibility = if (builderManualKcalOverride) View.VISIBLE else View.GONE
        }

        val overrideRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        overrideRow.addView(UiKit.text(this, "Manual calorie override (for fiber/label rounding)", 11f, UiKit.COL_TEXT_MID).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        val ovSwitch = Switch(this).apply {
            isChecked = builderManualKcalOverride
            setOnCheckedChangeListener { _, checked ->
                builderManualKcalOverride = checked
                manualOverrideIn.visibility = if (checked) View.VISIBLE else View.GONE
                if (!checked) {
                    builderManualKcal = autoCalculateCaloriesFromMacros(
                        builderProteinG.toDouble(),
                        builderCarbsG.toDouble(),
                        builderFatG.toDouble()
                    )
                }
            }
        }
        overrideRow.addView(ovSwitch)
        autoBox.addView(UiKit.spacerV(this, 4))
        autoBox.addView(overrideRow)
        autoBox.addView(manualOverrideIn)
        card.addView(autoBox)

        fun refreshLiveAutoKcal() {
            val p = pEd.text.toString().toIntOrNull() ?: 0
            val c = cEd.text.toString().toIntOrNull() ?: 0
            val f = fEd.text.toString().toIntOrNull() ?: 0
            builderProteinG = p
            builderCarbsG = c
            builderFatG = f
            val formulaKcal = autoCalculateCaloriesFromMacros(p.toDouble(), c.toDouble(), f.toDouble())
            val finalKcal = if (builderManualKcalOverride) {
                manualOverrideIn.text.toString().toIntOrNull() ?: formulaKcal
            } else {
                builderManualKcal = formulaKcal
                formulaKcal
            }
            autoKcalHeadline.text = "Auto-Calculated Energy: $finalKcal kcal"
            autoFormulaSub.text = "${p}g P (${p * 4}) + ${c}g C (${c * 4}) + ${f}g F (${f * 9}) = $formulaKcal kcal"
        }
        refreshLiveAutoKcal()

        val macroWatcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { refreshLiveAutoKcal() }
        }
        pEd.addTextChangedListener(macroWatcher)
        cEd.addTextChangedListener(macroWatcher)
        fEd.addTextChangedListener(macroWatcher)
        manualOverrideIn.addTextChangedListener(macroWatcher)

        card.addView(UiKit.spacerV(this, 10))

        // Action Buttons: + Log Meal Today | Save as Reusable Preset
        val actRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actRow.addView(UiKit.primaryButton(this, "+ Log Meal", UiKit.COL_ACCENT) {
            val p = pEd.text.toString().toIntOrNull() ?: 0
            val c = cEd.text.toString().toIntOrNull() ?: 0
            val f = fEd.text.toString().toIntOrNull() ?: 0
            val autoKcal = autoCalculateCaloriesFromMacros(p.toDouble(), c.toDouble(), f.toDouble())
            val finalKcal = if (builderManualKcalOverride) (manualOverrideIn.text.toString().toIntOrNull() ?: autoKcal) else autoKcal
            val finalName = nameEd.text.toString().trim().ifBlank {
                if (builderIngredients.isNotEmpty()) builderIngredients.joinToString(" + ") { it.food.name.substringBefore(" (") }
                else "$builderMealType Custom Macro Meal"
            }

            if (finalKcal <= 0 && p == 0 && c == 0 && f == 0) {
                showBanner("Enter macros or pick a food item first to calculate calories!")
                return@primaryButton
            }

            db.saveMeal(
                MealLog(
                    id = "meal_${System.currentTimeMillis()}",
                    dateIso = selectedDateIso,
                    mealType = builderMealType,
                    name = finalName,
                    calories = finalKcal.coerceAtLeast(1),
                    proteinG = p,
                    carbsG = c,
                    fatG = f,
                    loggedAtEpochMs = System.currentTimeMillis()
                ),
                notifyWidget = false
            )
            builderMealName = ""
            builderIngredients.clear()
            builderProteinG = 0; builderCarbsG = 0; builderFatG = 0; builderManualKcal = 0
            HyperLogStreakWidgetProvider.onMealSaved(this)
            if (hapticEnabled) NativeHardwareBridge.hapticTick(this)
            showBanner("Logged '$finalName' ($finalKcal kcal) · Home widget updated!")
            renderActivePage()
        }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.2f).apply {
                rightMargin = UiKit.rdp(this@MainActivity, 6)
            }
        })

        actRow.addView(UiKit.outlineButton(this, "Save Preset", UiKit.COL_ACCENT) {
            val p = pEd.text.toString().toIntOrNull() ?: 0
            val c = cEd.text.toString().toIntOrNull() ?: 0
            val f = fEd.text.toString().toIntOrNull() ?: 0
            val autoKcal = autoCalculateCaloriesFromMacros(p.toDouble(), c.toDouble(), f.toDouble())
            val finalKcal = if (builderManualKcalOverride) (manualOverrideIn.text.toString().toIntOrNull() ?: autoKcal) else autoKcal
            val finalName = nameEd.text.toString().trim().ifBlank { "Custom $builderMealType" }
            if (finalKcal > 0) {
                val summary = if (builderIngredients.isNotEmpty()) {
                    builderIngredients.joinToString(", ") { "${it.food.name.substringBefore(" (")} ${it.grams}g" }
                } else "${p}g P · ${c}g C · ${f}g F"
                db.saveCustomMealPreset(SavedCustomMeal(
                    "scm_${System.currentTimeMillis()}",
                    finalName,
                    builderMealType,
                    finalKcal,
                    p,
                    c,
                    f,
                    summary
                ))
                showBanner("Saved '$finalName' ($finalKcal kcal) to 1-Tap Presets!")
                renderActivePage()
            } else {
                showBanner("Enter macros or add ingredients before saving a preset.")
            }
        }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.9f)
        })

        card.addView(actRow)
        pageContent.addView(card)
    }

    private fun showFoodPortionDialog(food: OfflineFoodItem) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = UiKit.dp(this@MainActivity, 16)
            setPadding(p, p, p, p)
        }
        box.addView(UiKit.text(this, "Base serving: ${food.unitHint} = ${food.kcalPerBase} kcal", 12f, UiKit.COL_TEXT_MUTED))
        box.addView(UiKit.spacerV(this, 8))
        val gEd = UiKit.inputBox(this, food.baseGrams.toString(), "Portion in grams (g)", InputType.TYPE_CLASS_NUMBER)
        val previewTv = UiKit.text(this, "", 12.5f, UiKit.COL_ACCENT, bold = true, tabular = true)

        fun updatePortionPreview() {
            val g = gEd.text.toString().toIntOrNull() ?: food.baseGrams
            val sc = food.scaledMacros(g)
            previewTv.text = "${sc.grams}g = ${sc.calories} kcal · P ${sc.proteinG}g · C ${sc.carbsG}g · F ${sc.fatG}g"
        }
        updatePortionPreview()
        gEd.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { updatePortionPreview() }
        })

        val quickRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(50, 100, 150, 200).forEachIndexed { idx, gVal ->
            quickRow.addView(UiKit.chip(this, "${gVal}g", false) {
                gEd.setText(gVal.toString())
            }.apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    if (idx < 3) rightMargin = UiKit.dp(this@MainActivity, 5)
                }
            })
        }

        box.addView(quickRow)
        box.addView(UiKit.spacerV(this, 8))
        box.addView(gEd)
        box.addView(UiKit.spacerV(this, 8))
        box.addView(previewTv)

        AlertDialog.Builder(this, UiKit.dialogTheme())
            .setTitle("Add ${food.name}")
            .setView(box)
            .setPositiveButton("Add to Meal") { _, _ ->
                val g = (gEd.text.toString().toIntOrNull() ?: food.baseGrams).coerceIn(1, 2000)
                val existingIdx = builderIngredients.indexOfFirst { it.food.id == food.id }
                if (existingIdx >= 0) {
                    val cur = builderIngredients[existingIdx]
                    builderIngredients[existingIdx] = cur.copy(grams = cur.grams + g)
                } else {
                    builderIngredients.add(MealIngredientPick(food, g))
                }
                syncBuilderMacrosFromIngredients()
                renderActivePage()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun renderGuidedStudioSection() {
        val flows = SeedCatalog.offlineGuidedFlows()
        val activeFlow = flows.find { it.id == selectedFlowId } ?: flows.first()
        studioStepIdx = studioStepIdx.coerceIn(0, activeFlow.steps.lastIndex)
        val curStep = activeFlow.steps[studioStepIdx]

        val introCard = UiKit.card(this, padDp = 14)
        introCard.addView(UiKit.text(this, "Yoga, Stretching & Cardio Studio", 16.5f, UiKit.COL_TEXT_DARK, bold = true))
        introCard.addView(UiKit.text(
            this,
            "100% offline guided pose & interval sessions with audio tones, Calendar logging, Streak sync, and Health Connect support.",
            11.5f,
            UiKit.COL_TEXT_MUTED
        ))
        introCard.addView(UiKit.spacerV(this, 8))

        val (flowScroll, flowRow) = UiKit.hScrollRow(this)
        flows.forEach { fl ->
            flowRow.addView(UiKit.chip(this, "${fl.modality} · ${fl.durationMin}m", fl.id == activeFlow.id) {
                mainHandler.removeCallbacks(studioTickRunnable)
                studioTimerRunning = false
                selectedFlowId = fl.id
                studioStepIdx = 0
                studioSecondsLeft = fl.steps.first().durationSec
                NativeHardwareBridge.playTimerSetTone(this, soundOnTimer)
                renderActivePage()
            })
            flowRow.addView(UiKit.spacerH(this, 6))
        }
        introCard.addView(flowScroll)
        pageContent.addView(introCard)

        val playerCard = UiKit.card(this, borderColor = UiKit.COL_ACCENT, borderDp = 1.4f, padDp = 14)
        playerCard.addView(UiKit.text(this, "${activeFlow.modality} · ${activeFlow.durationMin} min", 11.5f, UiKit.COL_ACCENT, bold = true))
        playerCard.addView(UiKit.text(this, activeFlow.title, 16f, UiKit.COL_TEXT_DARK, bold = true))
        playerCard.addView(UiKit.text(this, activeFlow.summary, 12f, UiKit.COL_TEXT_MUTED))
        playerCard.addView(UiKit.spacerV(this, 10))

        val stepBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = UiKit.roundedBg(UiKit.COL_SUBTLE, 12f, this@MainActivity, UiKit.COL_BORDER, 1f)
            val p = UiKit.rdp(this@MainActivity, 12)
            setPadding(p, p, p, p)
        }
        stepBox.addView(UiKit.text(
            this,
            "Step ${studioStepIdx + 1} of ${activeFlow.steps.size} · ${curStep.name}",
            14f,
            UiKit.COL_TEXT_DARK,
            bold = true
        ))
        stepBox.addView(UiKit.spacerV(this, 3))
        stepBox.addView(UiKit.text(this, curStep.cue, 12f, UiKit.COL_TEXT_MID))
        stepBox.addView(UiKit.spacerV(this, 8))

        val clockTv = UiKit.text(this, formatClock(studioSecondsLeft), 26f, UiKit.COL_ACCENT, bold = true, tabular = true).apply {
            gravity = Gravity.CENTER
        }
        studioClockView = clockTv
        stepBox.addView(clockTv)
        stepBox.addView(UiKit.spacerV(this, 8))

        val ctrlRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        ctrlRow.addView(UiKit.primaryButton(this, if (studioTimerRunning) "Pause" else "Start Timer", UiKit.COL_ACCENT) {
            if (studioTimerRunning) {
                studioTimerRunning = false
                mainHandler.removeCallbacks(studioTickRunnable)
            } else {
                if (studioSecondsLeft <= 0) studioSecondsLeft = curStep.durationSec
                studioTimerRunning = true
                NativeHardwareBridge.playTimerSetTone(this, soundOnTimer)
                mainHandler.removeCallbacks(studioTickRunnable)
                mainHandler.postDelayed(studioTickRunnable, 1000L)
            }
            renderActivePage()
        }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.2f).apply {
                rightMargin = UiKit.rdp(this@MainActivity, 6)
            }
        })
        ctrlRow.addView(UiKit.outlineButton(this, "Next Step") {
            mainHandler.removeCallbacks(studioTickRunnable)
            studioTimerRunning = false
            studioStepIdx = (studioStepIdx + 1) % activeFlow.steps.size
            studioSecondsLeft = activeFlow.steps[studioStepIdx].durationSec
            NativeHardwareBridge.playTimerSetTone(this, soundOnTimer)
            renderActivePage()
        }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.9f).apply {
                rightMargin = UiKit.rdp(this@MainActivity, 6)
            }
        })
        ctrlRow.addView(UiKit.outlineButton(this, "Reset") {
            mainHandler.removeCallbacks(studioTickRunnable)
            studioTimerRunning = false
            studioStepIdx = 0
            studioSecondsLeft = activeFlow.steps.first().durationSec
            renderActivePage()
        }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.75f)
        })
        stepBox.addView(ctrlRow)
        playerCard.addView(stepBox)
        playerCard.addView(UiKit.spacerV(this, 10))

        activeFlow.steps.forEachIndexed { idx, st ->
            val active = idx == studioStepIdx
            val r = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                val py = UiKit.rdp(this@MainActivity, 5)
                setPadding(0, py, 0, py)
                setOnClickListener {
                    mainHandler.removeCallbacks(studioTickRunnable)
                    studioTimerRunning = false
                    studioStepIdx = idx
                    studioSecondsLeft = st.durationSec
                    NativeHardwareBridge.playTimerSetTone(this@MainActivity, soundOnTimer)
                    renderActivePage()
                }
            }
            r.addView(UiKit.text(
                this,
                "${idx + 1}. ${st.name}",
                12.5f,
                if (active) UiKit.COL_ACCENT else UiKit.COL_TEXT_DARK,
                bold = active
            ).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            r.addView(UiKit.text(this, "${st.durationSec}s", 11.5f, UiKit.COL_TEXT_MUTED, bold = true, tabular = true))
            playerCard.addView(r)
        }

        playerCard.addView(UiKit.spacerV(this, 10))
        playerCard.addView(UiKit.primaryButton(this, "Log Guided Session to Calendar & Streak", 0xFF059669.toInt()) {
            val todayIso = LocalDate.now().toString()
            val sid = "studio_${System.currentTimeMillis()}"
            val logs = activeFlow.steps.mapIndexed { idx, st ->
                SetLog(
                    id = "${sid}_s${idx + 1}",
                    week = activeWeek,
                    dayNumber = 0,
                    templateSessionId = sid,
                    exerciseId = "guided_${activeFlow.id}_${idx + 1}",
                    exerciseName = st.name,
                    muscleId = st.primaryMuscle,
                    setIndex = idx + 1,
                    weightKg = 0.0,
                    reps = st.durationSec,
                    rir = 2.0,
                    restSeconds = 20,
                    completed = true,
                    completedDateIso = todayIso,
                    rpe = 7.5
                )
            }
            db.logManualWorkoutForDate(
                dateIso = todayIso,
                title = "${activeFlow.modality} · ${activeFlow.title}",
                durationMin = activeFlow.durationMin,
                notes = activeFlow.summary,
                sets = logs
            )
            val wb = db.getWellbeingForDate(todayIso)
            db.saveWellbeingRecord(wb.copy(mobilityMinutes = wb.mobilityMinutes + activeFlow.durationMin))
            NativeHardwareBridge.playTimerCompleteTone(this, soundOnTimer)
            if (hapticEnabled) NativeHardwareBridge.hapticTick(this)
            showBanner("Logged '${activeFlow.title}' (${logs.size} steps) to Calendar, Anatomy & Streak!")
            renderActivePage()
        })
        playerCard.addView(UiKit.spacerV(this, 6))
        playerCard.addView(UiKit.outlineButton(this, "Sync Guided Session to Health Connect", UiKit.COL_ACCENT) {
            NativeHardwareBridge.syncWorkoutToHealthConnect(
                activity = this,
                db = db,
                title = "${activeFlow.modality} · ${activeFlow.title}",
                completedSets = activeFlow.steps.size,
                tonnageKg = 0.0,
                durationMinutes = activeFlow.durationMin,
                modality = activeFlow.modality.lowercase(Locale.US)
            ) { msg ->
                showBanner(msg)
            }
        })
        pageContent.addView(playerCard)
    }

    private fun renderWellbeingSection() {
        val wb = db.getWellbeingForDate(selectedDateIso)
        val readiness = wb.readinessScore()
        val readinessCol = when {
            readiness >= 75 -> 0xFF059669.toInt()
            readiness >= 55 -> UiKit.COL_ACCENT
            else -> 0xFFF59E0B.toInt()
        }
        val readinessPhrase = when {
            readiness >= 75 -> "Well rested · Great day for steady movement"
            readiness >= 55 -> "Steady energy · Move comfortably and sip water"
            else -> "Gentle recovery day · Favor walking, stretching, or calm breathing"
        }

        val metrics = db.getDailyMetrics(selectedDateIso)
        val meals = db.getMealsForDate(selectedDateIso)
        val eatenKcal = meals.sumOf { it.calories }
        val eatenP = meals.sumOf { it.proteinG }
        val eatenC = meals.sumOf { it.carbsG }
        val eatenF = meals.sumOf { it.fatG }
        val targetKcal = metrics.baseTdee.coerceAtLeast(1400)
        val targetP = (metrics.bodyweightKg * metrics.proteinPerKg).roundToInt().coerceAtLeast(95)

        // 1. Calm "Today's Daily Balance" Summary Card (Progressive Disclosure)
        val balCard = UiKit.card(this, borderColor = UiKit.COL_ACCENT, borderDp = 1.3f, padDp = 15)
        val balTop = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val balLeft = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        balLeft.addView(UiKit.text(this, "Today's Daily Balance", 12f, UiKit.COL_ACCENT, bold = true))
        balLeft.addView(UiKit.spacerV(this, 2))
        balLeft.addView(UiKit.text(this, readinessPhrase, 15f, UiKit.COL_TEXT_DARK, bold = true))
        balTop.addView(balLeft)
        balTop.addView(UiKit.spacerH(this, 6))
        balTop.addView(UiKit.primaryButton(this, "+ 250 ml Water", UiKit.COL_ACCENT) {
            db.saveWellbeingRecord(wb.copy(waterMl = (wb.waterMl + 250).coerceIn(0, 8000)))
            if (hapticEnabled) NativeHardwareBridge.hapticTick(this)
            renderActivePage()
        })
        balCard.addView(balTop)
        balCard.addView(UiKit.spacerV(this, 10))

        listOf(
            Triple("Nourishment", "$eatenKcal / $targetKcal kcal", eatenKcal.toFloat() / targetKcal.toFloat() to UiKit.COL_ACCENT),
            Triple("Protein", "$eatenP / ${targetP}g", eatenP.toFloat() / targetP.toFloat() to 0xFF10B981.toInt()),
            Triple("Hydration", "${wb.waterMl} / 3000 ml", wb.waterMl / 3000f to 0xFF0EA5E9.toInt())
        ).forEach { (lbl, valStr, pair) ->
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            r.addView(UiKit.text(this, lbl, 12f, UiKit.COL_TEXT_MID, bold = true).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            r.addView(UiKit.text(this, valStr, 12f, UiKit.COL_TEXT_DARK, bold = true, tabular = true))
            balCard.addView(r)
            balCard.addView(UiKit.progressBar(this, pair.first, pair.second))
            balCard.addView(UiKit.spacerV(this, 4))
        }

        val balFooter = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        balFooter.addView(UiKit.chip(
            this,
            if (showWellnessMacroDetails) "Hide Macro Details ▴" else "Macro & Readiness Details ▾",
            showWellnessMacroDetails
        ) {
            showWellnessMacroDetails = !showWellnessMacroDetails
            renderActivePage()
        })
        balFooter.addView(UiKit.spacerH(this, 8))
        balFooter.addView(UiKit.outlineButton(this, "Log a Meal →", UiKit.COL_ACCENT) {
            wellnessSubTab = "nutrition"
            renderActivePage()
        })
        balCard.addView(balFooter)

        if (showWellnessMacroDetails) {
            balCard.addView(UiKit.spacerV(this, 8))
            val detRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            listOf(
                "Carbs" to "${eatenC}g",
                "Healthy Fats" to "${eatenF}g",
                "Readiness" to "$readiness/100"
            ).forEachIndexed { idx, (lbl, v) ->
                detRow.addView(UiKit.metricBox(this, lbl, v).apply {
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                        if (idx < 2) rightMargin = UiKit.rdp(this@MainActivity, 5)
                    }
                })
            }
            balCard.addView(detRow)
        }
        pageContent.addView(balCard)

        val hydExpanded = "hydration" in expandedWellnessDropdownKeys
        val (hydOuter, hydBody) = UiKit.collapsibleDropdownCard(
            ctx = this,
            title = "Sleep, Energy & Hydration Check-In",
            subtitle = "Optional daily check-in for water, rest, stress, and muscle recovery",
            expanded = hydExpanded,
            badgeText = "${wb.sleepHours}h · ${wb.waterMl} ml",
            accentBorderColor = readinessCol
        ) {
            if (hydExpanded) expandedWellnessDropdownKeys.remove("hydration")
            else expandedWellnessDropdownKeys.add("hydration")
            renderActivePage()
        }
        hydBody.addView(UiKit.progressBar(this, readiness / 100f, readinessCol))
        hydBody.addView(UiKit.spacerV(this, 8))

        // Hydration Tracker
        hydBody.addView(UiKit.text(this, "Hydration: ${wb.waterMl} / 3000 ml", 13f, UiKit.COL_TEXT_DARK, bold = true, tabular = true))
        hydBody.addView(UiKit.progressBar(this, wb.waterMl / 3000f, 0xFF0EA5E9.toInt()))
        hydBody.addView(UiKit.spacerV(this, 6))
        val waterRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("+250 ml" to 250, "+500 ml" to 500, "Reset" to -wb.waterMl).forEachIndexed { idx, (lbl, delta) ->
            waterRow.addView(UiKit.outlineButton(this, lbl, UiKit.COL_ACCENT) {
                db.saveWellbeingRecord(wb.copy(waterMl = (wb.waterMl + delta).coerceIn(0, 8000)))
                if (hapticEnabled) NativeHardwareBridge.hapticTick(this)
                renderActivePage()
            }.apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    if (idx < 2) rightMargin = UiKit.rdp(this@MainActivity, 6)
                }
            })
        }
        hydBody.addView(waterRow)
        hydBody.addView(UiKit.spacerV(this, 10))

        // Sleep Hours Chips
        hydBody.addView(UiKit.text(this, "Sleep Duration: ${wb.sleepHours} hrs", 12.5f, UiKit.COL_TEXT_DARK, bold = true, tabular = true))
        hydBody.addView(UiKit.spacerV(this, 4))
        val (slpScroll, slpRow) = UiKit.hScrollRow(this)
        listOf(5.5, 6.5, 7.0, 7.5, 8.0, 8.5, 9.0).forEach { hrs ->
            slpRow.addView(UiKit.chip(this, "${hrs}h", kotlin.math.abs(wb.sleepHours - hrs) < 0.1) {
                db.saveWellbeingRecord(wb.copy(sleepHours = hrs))
                renderActivePage()
            })
            slpRow.addView(UiKit.spacerH(this, 5))
        }
        hydBody.addView(slpScroll)
        hydBody.addView(UiKit.spacerV(this, 8))

        fun addScoreSelector(title: String, current: Int, onPick: (Int) -> Unit) {
            hydBody.addView(UiKit.text(this, "$title ($current / 5)", 12f, UiKit.COL_TEXT_MID, bold = true, tabular = true))
            hydBody.addView(UiKit.spacerV(this, 4))
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            (1..5).forEach { v ->
                row.addView(UiKit.chip(this, v.toString(), current == v) {
                    onPick(v)
                    renderActivePage()
                }.apply {
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                        if (v < 5) rightMargin = UiKit.rdp(this@MainActivity, 5)
                    }
                })
            }
            hydBody.addView(row)
            hydBody.addView(UiKit.spacerV(this, 8))
        }

        addScoreSelector("Daily Energy", wb.energyScore) { v -> db.saveWellbeingRecord(wb.copy(energyScore = v)) }
        addScoreSelector("Stress (1 Very Calm – 5 Busy)", wb.stressScore) { v -> db.saveWellbeingRecord(wb.copy(stressScore = v)) }
        addScoreSelector("Muscle Feel (1 Fresh – 5 Sore)", wb.sorenessScore) { v -> db.saveWellbeingRecord(wb.copy(sorenessScore = v)) }

        hydBody.addView(UiKit.text(
            this,
            "Mobility: ${wb.mobilityMinutes} min · Breathwork: ${wb.breathMinutes} min",
            11.5f,
            UiKit.COL_TEXT_MUTED,
            tabular = true
        ))
        pageContent.addView(hydOuter)

        // Collapsible Guided Breathwork Timer Dropdown Card
        val breathExpanded = breathTimerRunning || ("breathwork" in expandedWellnessDropdownKeys)
        val (breathOuter, breathCard) = UiKit.collapsibleDropdownCard(
            ctx = this,
            title = "Calm Breathing & Ambient Sound",
            subtitle = "Unwind with gentle rhythmic breathing and ocean, rain, or singing bowl audio",
            expanded = breathExpanded,
            badgeText = formatClock(breathSecondsLeft)
        ) {
            if ("breathwork" in expandedWellnessDropdownKeys) expandedWellnessDropdownKeys.remove("breathwork")
            else expandedWellnessDropdownKeys.add("breathwork")
            renderActivePage()
        }

        val (patScroll, patRow) = UiKit.hScrollRow(this)
        listOf(
            "box" to "Box 4-4-4-4",
            "478" to "4-7-8 Reset",
            "coherent" to "Coherent 5-5",
            "pranayama" to "Pranayama 4-4-6-2"
        ).forEach { (pId, pLbl) ->
            patRow.addView(UiKit.chip(this, pLbl, breathPattern == pId) {
                mainHandler.removeCallbacks(breathTickRunnable)
                breathTimerRunning = false
                lastBreathPhaseKey = ""
                BreathingSoundscapeEngine.stop()
                breathPattern = pId
                breathSecondsLeft = 120
                NativeHardwareBridge.playTimerSetTone(this, soundOnTimer)
                renderActivePage()
            })
            patRow.addView(UiKit.spacerH(this, 6))
        }
        breathCard.addView(patScroll)
        breathCard.addView(UiKit.spacerV(this, 10))

        breathCard.addView(UiKit.text(this, "Soothing Audio Soundscape", 12f, UiKit.COL_TEXT_DARK, bold = true))
        breathCard.addView(UiKit.spacerV(this, 5))
        val tracks = SeedCatalog.breathingAudioTracks()
        val (trkScroll, trkRow) = UiKit.hScrollRow(this)
        tracks.forEach { trk ->
            trkRow.addView(UiKit.chip(this, trk.title, breathAudioTrackId == trk.id) {
                breathAudioTrackId = trk.id
                savePrefs()
                BreathingSoundscapeEngine.setTrack(trk.id)
                if (hapticEnabled) NativeHardwareBridge.hapticTick(this)
                renderActivePage()
            })
            trkRow.addView(UiKit.spacerH(this, 6))
        }
        breathCard.addView(trkScroll)
        val activeTrk = tracks.find { it.id == breathAudioTrackId } ?: tracks.first()
        breathCard.addView(UiKit.spacerV(this, 3))
        breathCard.addView(UiKit.text(this, activeTrk.subtitle, 11f, UiKit.COL_TEXT_MUTED))
        breathCard.addView(UiKit.spacerV(this, 8))

        val volRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        volRow.addView(UiKit.text(this, "Audio Level", 11.5f, UiKit.COL_TEXT_MID, bold = true).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        listOf(0.35f to "Soft", 0.65f to "Balanced", 0.90f to "Rich").forEach { (lvl, lbl) ->
            val sel = !breathAudioMuted && kotlin.math.abs(breathAudioVolume - lvl) < 0.08f
            volRow.addView(UiKit.chip(this, lbl, sel) {
                breathAudioMuted = false
                breathAudioVolume = lvl
                savePrefs()
                BreathingSoundscapeEngine.setMutedState(false)
                BreathingSoundscapeEngine.setVolumeLevel(lvl)
                renderActivePage()
            })
            volRow.addView(UiKit.spacerH(this, 4))
        }
        volRow.addView(UiKit.chip(this, if (breathAudioMuted) "Muted" else "Mute", breathAudioMuted) {
            breathAudioMuted = !breathAudioMuted
            savePrefs()
            BreathingSoundscapeEngine.setMutedState(breathAudioMuted)
            renderActivePage()
        })
        breathCard.addView(volRow)
        breathCard.addView(UiKit.spacerV(this, 10))

        val bClock = UiKit.text(this, formatClock(breathSecondsLeft), 24f, UiKit.COL_ACCENT, bold = true, tabular = true).apply {
            gravity = Gravity.CENTER
        }
        val bCue = UiKit.text(
            this,
            if (breathTimerRunning) "Inhale & exhale smoothly with ${activeTrk.title}..." else "Ready · 2:00 guided audio breathwork",
            13f,
            UiKit.COL_TEXT_DARK,
            bold = true
        ).apply { gravity = Gravity.CENTER }
        breathClockView = bClock
        breathCueView = bCue
        breathCard.addView(bClock)
        breathCard.addView(UiKit.spacerV(this, 4))
        breathCard.addView(bCue)
        breathCard.addView(UiKit.spacerV(this, 10))

        val bBtnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        bBtnRow.addView(UiKit.primaryButton(this, if (breathTimerRunning) "Pause Audio & Timer" else "Start Breathwork + Audio", UiKit.COL_ACCENT) {
            if (breathTimerRunning) {
                breathTimerRunning = false
                lastBreathPhaseKey = ""
                mainHandler.removeCallbacks(breathTickRunnable)
                BreathingSoundscapeEngine.stop()
            } else {
                if (breathSecondsLeft <= 0) breathSecondsLeft = 120
                breathTimerRunning = true
                lastBreathPhaseKey = "inhale"
                BreathingSoundscapeEngine.start(breathAudioTrackId, breathAudioVolume, breathAudioMuted)
                BreathingSoundscapeEngine.onPhaseChange("inhale")
                mainHandler.removeCallbacks(breathTickRunnable)
                mainHandler.postDelayed(breathTickRunnable, 1000L)
            }
            renderActivePage()
        }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.35f).apply {
                rightMargin = UiKit.rdp(this@MainActivity, 6)
            }
        })
        bBtnRow.addView(UiKit.outlineButton(this, "Reset") {
            mainHandler.removeCallbacks(breathTickRunnable)
            breathTimerRunning = false
            lastBreathPhaseKey = ""
            BreathingSoundscapeEngine.stop()
            breathSecondsLeft = 120
            renderActivePage()
        }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.65f)
        })
        breathCard.addView(bBtnRow)
        pageContent.addView(breathOuter)
    }

    private fun renderFitnessToolsSection() {
        // 1. Collapsible 1RM Strength Estimator Dropdown Card
        val rmExpanded = "1rm" in expandedWellnessDropdownKeys
        val (rmOuter, rmCard) = UiKit.collapsibleDropdownCard(
            ctx = this,
            title = "1RM Strength & Load Percentage Calculator",
            subtitle = "Epley & Brzycki average 1RM with hypertrophy working percentages",
            expanded = rmExpanded,
            badgeText = "Epley + Brzycki"
        ) {
            if (rmExpanded) expandedWellnessDropdownKeys.remove("1rm")
            else expandedWellnessDropdownKeys.add("1rm")
            renderActivePage()
        }

        val inRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val wEd = UiKit.numericSetInputBox(
            this,
            formatCleanDecimal(tool1RmWeightInput),
            weightUnit,
            InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        ).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                rightMargin = UiKit.rdp(this@MainActivity, 6)
            }
        }
        val rEd = UiKit.numericSetInputBox(
            this,
            tool1RmRepsInput.toString(),
            "Reps",
            InputType.TYPE_CLASS_NUMBER
        ).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        inRow.addView(wEd)
        inRow.addView(rEd)
        rmCard.addView(inRow)
        rmCard.addView(UiKit.spacerV(this, 8))

        val rmOutTv = UiKit.text(this, "", 16f, UiKit.COL_ACCENT, bold = true, tabular = true)
        val rmPctTv = UiKit.text(this, "", 12f, UiKit.COL_TEXT_MID, tabular = true)
        rmCard.addView(rmOutTv)
        rmCard.addView(UiKit.spacerV(this, 4))
        rmCard.addView(rmPctTv)

        fun update1RmDisplay() {
            val w = wEd.text.toString().toDoubleOrNull()?.coerceAtLeast(1.0) ?: tool1RmWeightInput
            val r = (rEd.text.toString().toIntOrNull() ?: tool1RmRepsInput).coerceIn(1, 30)
            tool1RmWeightInput = w
            tool1RmRepsInput = r
            val epley = if (r == 1) w else w * (1.0 + r / 30.0)
            val brzycki = if (r == 1) w else w * (36.0 / (37.0 - r.coerceAtMost(35)))
            val est = ((epley + brzycki) / 2.0 * 10.0).roundToInt() / 10.0
            rmOutTv.text = "Estimated 1RM: ${formatCleanDecimal(est)} $weightUnit"
            val p90 = formatCleanDecimal((est * 0.90 * 10.0).roundToInt() / 10.0)
            val p85 = formatCleanDecimal((est * 0.85 * 10.0).roundToInt() / 10.0)
            val p80 = formatCleanDecimal((est * 0.80 * 10.0).roundToInt() / 10.0)
            val p75 = formatCleanDecimal((est * 0.75 * 10.0).roundToInt() / 10.0)
            val p70 = formatCleanDecimal((est * 0.70 * 10.0).roundToInt() / 10.0)
            rmPctTv.text = "90%: $p90 · 85%: $p85 · 80%: $p80 · 75%: $p75 · 70%: $p70 $weightUnit"
        }
        update1RmDisplay()
        val rmWatcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { update1RmDisplay() }
        }
        wEd.addTextChangedListener(rmWatcher)
        rEd.addTextChangedListener(rmWatcher)
        pageContent.addView(rmOuter)

        // 2. Collapsible Barbell Plate Loader Dropdown Card
        val barWeight = if (weightUnit == "lb") 45.0 else 20.0
        val plateExpanded = "plates" in expandedWellnessDropdownKeys
        val (plateOuter, plateCard) = UiKit.collapsibleDropdownCard(
            ctx = this,
            title = "Barbell Plate Loader (${barWeight.toInt()} $weightUnit Bar)",
            subtitle = "Exact per-side plate breakdown for standard Olympic gym plates",
            expanded = plateExpanded,
            badgeText = "${formatCleanDecimal(toolPlateTargetInput)} $weightUnit"
        ) {
            if (plateExpanded) expandedWellnessDropdownKeys.remove("plates")
            else expandedWellnessDropdownKeys.add("plates")
            renderActivePage()
        }
        val targetEd = UiKit.numericSetInputBox(
            this,
            formatCleanDecimal(toolPlateTargetInput),
            "Target $weightUnit",
            InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        )
        plateCard.addView(targetEd)
        plateCard.addView(UiKit.spacerV(this, 8))
        val plateOutTv = UiKit.text(this, "", 13f, UiKit.COL_ACCENT, bold = true, tabular = true)
        plateCard.addView(plateOutTv)

        fun updatePlateDisplay() {
            val target = targetEd.text.toString().toDoubleOrNull() ?: toolPlateTargetInput
            toolPlateTargetInput = target
            if (target <= barWeight) {
                plateOutTv.text = "Empty bar (${barWeight.toInt()} $weightUnit) — enter a weight above ${barWeight.toInt()} $weightUnit."
                return
            }
            var perSide = (target - barWeight) / 2.0
            val denoms = if (weightUnit == "lb") listOf(45.0, 35.0, 25.0, 10.0, 5.0, 2.5)
            else listOf(25.0, 20.0, 15.0, 10.0, 5.0, 2.5, 1.25)
            val picks = mutableListOf<String>()
            for (d in denoms) {
                var cnt = 0
                while (perSide + 0.01 >= d) {
                    perSide -= d
                    cnt += 1
                }
                if (cnt > 0) picks.add("${cnt}×${formatCleanDecimal(d)}")
            }
            plateOutTv.text = if (picks.isEmpty()) "No standard plates needed." else "Per Side: ${picks.joinToString(" + ")} $weightUnit"
        }
        updatePlateDisplay()
        targetEd.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { updatePlateDisplay() }
        })
        pageContent.addView(plateOuter)

        // 3. Collapsible HIIT / Tabata Interval Timer Dropdown Card
        val hiitExpanded = hiitTimerRunning || ("hiit" in expandedWellnessDropdownKeys)
        val (hiitOuter, hiitCard) = UiKit.collapsibleDropdownCard(
            ctx = this,
            title = "HIIT / Tabata Interval Timer",
            subtitle = "Audio tones fire automatically when set, on work/rest shifts, and on completion",
            expanded = hiitExpanded,
            badgeText = formatClock(hiitSecondsLeft),
            accentBorderColor = UiKit.COL_ACCENT
        ) {
            if ("hiit" in expandedWellnessDropdownKeys) expandedWellnessDropdownKeys.remove("hiit")
            else expandedWellnessDropdownKeys.add("hiit")
            renderActivePage()
        }

        val (preScroll, preRow) = UiKit.hScrollRow(this)
        listOf(
            Triple("Tabata 20/10×8", 20 to 10, 8),
            Triple("HIIT 30/30×8", 30 to 30, 8),
            Triple("EMOM 45/15×6", 45 to 15, 6)
        ).forEach { (lbl, wr, rnds) ->
            val selected = hiitWorkSec == wr.first && hiitRestSec == wr.second && hiitTotalRounds == rnds
            preRow.addView(UiKit.chip(this, lbl, selected) {
                mainHandler.removeCallbacks(hiitTickRunnable)
                hiitTimerRunning = false
                hiitWorkSec = wr.first
                hiitRestSec = wr.second
                hiitTotalRounds = rnds
                hiitCurrentRound = 1
                hiitInWorkPhase = true
                hiitSecondsLeft = wr.first
                NativeHardwareBridge.playTimerSetTone(this, soundOnTimer)
                renderActivePage()
            })
            preRow.addView(UiKit.spacerH(this, 6))
        }
        hiitCard.addView(preScroll)
        hiitCard.addView(UiKit.spacerV(this, 10))

        val hClock = UiKit.text(
            this,
            "${if (hiitInWorkPhase) "WORK" else "REST"} · ${formatClock(hiitSecondsLeft)} (Rd $hiitCurrentRound/$hiitTotalRounds)",
            20f,
            if (hiitInWorkPhase) 0xFF059669.toInt() else UiKit.COL_ACCENT,
            bold = true,
            tabular = true
        ).apply { gravity = Gravity.CENTER }
        hiitClockView = hClock
        hiitCard.addView(hClock)
        hiitCard.addView(UiKit.spacerV(this, 8))

        val hBtns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        hBtns.addView(UiKit.primaryButton(this, if (hiitTimerRunning) "Pause HIIT" else "Start HIIT Timer", UiKit.COL_ACCENT) {
            if (hiitTimerRunning) {
                hiitTimerRunning = false
                mainHandler.removeCallbacks(hiitTickRunnable)
            } else {
                if (hiitSecondsLeft <= 0) {
                    hiitCurrentRound = 1
                    hiitInWorkPhase = true
                    hiitSecondsLeft = hiitWorkSec
                }
                hiitTimerRunning = true
                NativeHardwareBridge.playTimerSetTone(this, soundOnTimer)
                mainHandler.removeCallbacks(hiitTickRunnable)
                mainHandler.postDelayed(hiitTickRunnable, 1000L)
            }
            renderActivePage()
        }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.3f).apply {
                rightMargin = UiKit.rdp(this@MainActivity, 6)
            }
        })
        hBtns.addView(UiKit.outlineButton(this, "Reset") {
            mainHandler.removeCallbacks(hiitTickRunnable)
            hiitTimerRunning = false
            hiitCurrentRound = 1
            hiitInWorkPhase = true
            hiitSecondsLeft = hiitWorkSec
            renderActivePage()
        }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.7f)
        })
        hiitCard.addView(hBtns)
        pageContent.addView(hiitOuter)
    }

    private fun switchUserVaultAndRehydrate(newDb: HyperLogDatabase, label: String) {
        // Stop any running timers from the outgoing profile so state never bleeds across users
        mainHandler.removeCallbacks(timerTickRunnable)
        mainHandler.removeCallbacks(globalWorkoutTickRunnable)
        mainHandler.removeCallbacks(cardioTickRunnable)
        mainHandler.removeCallbacks(studioTickRunnable)
        mainHandler.removeCallbacks(breathTickRunnable)
        mainHandler.removeCallbacks(hiitTickRunnable)
        BreathingSoundscapeEngine.stop()

        completedWorkoutState = null
        activeCardioExId = null
        cardioCompletedMap.clear()
        cardioRemainingSecMap.clear()
        val todayIso = LocalDate.now().toString()
        selectedDateIso = todayIso
        calendarSelectedDateIso = todayIso
        weightInputDateIso = todayIso
        calendarYear = LocalDate.now().year
        calendarMonth = LocalDate.now().monthValue

        db = newDb
        loadUserPrefsIntoState()
        NativeHardwareBridge.setKeepScreenOn(this, keepScreenOn)

        // Phase-1 Fast Login Optimization: Immediately hydrate only First-10 prioritized exercises!
        cachedFirst10Library = db.getLibraryExercisesPrioritized(limit = 10, offset = 0)
        cachedTotalLibraryCount = cachedFirst10Library.size
        loginHydratedFirst10Only = true
        libraryVisibleLimit = 10
        HyperLogStreakWidgetProvider.refreshAllWidgets(this)
        refreshShellTheme()

        if (globalWorkoutActive && !globalWorkoutPaused) {
            mainHandler.post(globalWorkoutTickRunnable)
        }
        if (restTimerRunning && restSecondsRemaining > 0) {
            mainHandler.postDelayed(timerTickRunnable, 1000L)
        }

        val freshnessNote = if (db.isGuestVault) "Demo Guest Vault" else "100% Isolated Personal Vault"
        showBanner("✓ Active Profile: $label ($freshnessNote)")
        mainHandler.postDelayed({
            runCatching {
                db.ensureDaySetRowsMaterialized(activeWeek, activeDay)
                cachedTotalLibraryCount = db.getTotalLibraryExerciseCount()
                loginHydratedFirst10Only = false
                if (activeTab == 3) renderActivePage()
            }
        }, 160L)
    }

    private fun showAccountVaultDialog() {
        val outerWrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val pad = UiKit.dp(this@MainActivity, 10)
            setPadding(pad, pad, pad, pad)
        }
        val scroll = ScrollView(this)
        val box = UiKit.clayAuthDialogShell(this)
        scroll.addView(box)
        outerWrap.addView(scroll)

        lateinit var dialogRef: AlertDialog
        val activeAcc = HyperLogDatabase.getActiveAccount(this)
        val savedAccounts = HyperLogDatabase.getSavedAccounts(this)

        box.addView(UiKit.text(
            this,
            "CLAYMORPHISM VAULT · 32DP SOFT SHELL",
            10.5f,
            UiKit.COL_ACCENT,
            bold = true
        ))
        box.addView(UiKit.spacerV(this, 3))
        box.addView(UiKit.text(
            this,
            "Isolated Athlete Login & Fresh Data Guarantee",
            15.5f,
            UiKit.COL_TEXT_DARK,
            bold = true
        ))
        box.addView(UiKit.spacerV(this, 4))
        box.addView(UiKit.text(
            this,
            "Every profile logs into its own isolated SQLite file (`hyperlog_user_<id>.db`) with a 100% clean Day-Zero slate (0 sets, 0 streaks, 70kg baseline). User A's workouts and body metrics are never visible to User B.",
            11.5f,
            UiKit.COL_TEXT_MUTED
        ))
        box.addView(UiKit.spacerV(this, 12))

        savedAccounts.forEach { acc ->
            val isAct = acc.uid == activeAcc.uid
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = UiKit.roundedBg(
                    if (isAct) UiKit.COL_ROW_COMPLETED else UiKit.COL_SUBTLE,
                    14f,
                    this@MainActivity,
                    if (isAct) UiKit.COL_ACCENT else UiKit.COL_BORDER,
                    if (isAct) 1.5f else 1f
                )
                val p = UiKit.rdp(this@MainActivity, 11)
                setPadding(p, p, p, p)
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = UiKit.rdp(this@MainActivity, 6)
                }
                UiKit.attachInstantPressFeedback(this, 0.98f)
                setOnClickListener {
                    dialogRef.dismiss()
                    val switched = HyperLogDatabase.switchActiveAccount(this@MainActivity, acc.uid)
                    switchUserVaultAndRehydrate(switched, acc.displayName)
                }
            }
            val info = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            info.addView(UiKit.text(this, "${acc.displayName} (${acc.provider})", 13f, UiKit.COL_TEXT_DARK, bold = true))
            info.addView(UiKit.text(this, "${acc.email} · ${acc.dbFileName}", 10.5f, UiKit.COL_TEXT_MUTED, tabular = true))
            row.addView(info)
            row.addView(UiKit.text(
                this,
                if (isAct) "Active ✓" else "Switch →",
                12f,
                if (isAct) 0xFF059669.toInt() else UiKit.COL_ACCENT,
                bold = true
            ))
            box.addView(row)
        }

        box.addView(UiKit.spacerV(this, 10))
        box.addView(UiKit.text(this, "Sign In or Create New Clay Vault", 13.5f, UiKit.COL_TEXT_DARK, bold = true))
        box.addView(UiKit.spacerV(this, 6))
        val nameIn = UiKit.inputBox(this, "", "Display Name (e.g. Aarav)", InputType.TYPE_CLASS_TEXT)
        val emailIn = UiKit.inputBox(this, "", "Email (e.g. aarav@example.com)", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS)
        box.addView(nameIn)
        box.addView(UiKit.spacerV(this, 6))
        box.addView(emailIn)
        box.addView(UiKit.spacerV(this, 10))

        val authRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Email", "Google", "Facebook").forEachIndexed { idx, prov ->
            val btnView = if (idx == 0) {
                UiKit.primaryButton(this, "Sign In ($prov)", UiKit.COL_ACCENT) {
                    val nm = nameIn.text.toString().trim()
                    val em = emailIn.text.toString().trim()
                    if (nm.isEmpty() && em.isEmpty()) {
                        showBanner("Enter a name or email to open an isolated vault.")
                        return@primaryButton
                    }
                    dialogRef.dismiss()
                    val createdDb = HyperLogDatabase.registerOrSignInAccount(
                        this@MainActivity,
                        nm.ifEmpty { "$prov Athlete" },
                        em.ifEmpty { "${prov.lowercase(Locale.US)}@hyperlog.local" },
                        prov
                    )
                    val active = HyperLogDatabase.getActiveAccount(this@MainActivity)
                    switchUserVaultAndRehydrate(createdDb, active.displayName)
                }
            } else {
                UiKit.outlineButton(this, "+ $prov", UiKit.COL_ACCENT) {
                    val nm = nameIn.text.toString().trim()
                    val em = emailIn.text.toString().trim()
                    if (nm.isEmpty() && em.isEmpty()) {
                        showBanner("Enter a name or email to open an isolated vault.")
                        return@outlineButton
                    }
                    dialogRef.dismiss()
                    val createdDb = HyperLogDatabase.registerOrSignInAccount(
                        this@MainActivity,
                        nm.ifEmpty { "$prov Athlete" },
                        em.ifEmpty { "${prov.lowercase(Locale.US)}@hyperlog.local" },
                        prov
                    )
                    val active = HyperLogDatabase.getActiveAccount(this@MainActivity)
                    switchUserVaultAndRehydrate(createdDb, active.displayName)
                }
            }
            btnView.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                if (idx < 2) rightMargin = UiKit.rdp(this@MainActivity, 5)
            }
            authRow.addView(btnView)
        }
        box.addView(authRow)

        if (activeAcc.uid != "guest") {
            box.addView(UiKit.spacerV(this, 10))
            box.addView(UiKit.outlineButton(this, "Delete '${activeAcc.displayName}' Vault & Data", 0xFFEF4444.toInt()) {
                dialogRef.dismiss()
                val fallbackDb = HyperLogDatabase.deleteAccountVault(this@MainActivity, activeAcc.uid)
                switchUserVaultAndRehydrate(fallbackDb, "Guest Local Vault")
            })
        }

        box.addView(UiKit.spacerV(this, 8))
        box.addView(UiKit.outlineButton(this, "Close Vault") {
            dialogRef.dismiss()
        })

        dialogRef = AlertDialog.Builder(this, UiKit.dialogTheme())
            .setView(outerWrap)
            .create()
        dialogRef.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialogRef.show()
    }

    // =========================================================================
    // PAGE 6: DEDICATED SETTINGS TAB (ACCOUNT VAULTS + WIDGET + THEMES + BACKUP)
    // =========================================================================
    private fun renderSettingsPage() {
        val snap = db.getWidgetProgressSnapshot(activeWeek)
        val activeAcc = HyperLogDatabase.getActiveAccount(this)

        val headCard = UiKit.card(this, padDp = 14)
        headCard.addView(UiKit.text(this, "App Settings & Preferences", 18f, UiKit.COL_TEXT_DARK, bold = true))
        headCard.addView(UiKit.text(
            this,
            "Active Vault: ${activeAcc.displayName} (${activeAcc.dbFileName}) · Manage accounts, Home Screen Widget, dark themes, and backups.",
            12f,
            UiKit.COL_TEXT_MUTED,
            tabular = true
        ))
        headCard.addView(UiKit.spacerV(this, 8))
        val topBtns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        topBtns.addView(UiKit.primaryButton(this, "Manage User Vaults", UiKit.COL_ACCENT) {
            showAccountVaultDialog()
        }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.15f).apply {
                rightMargin = UiKit.rdp(this@MainActivity, 6)
            }
        })
        topBtns.addView(UiKit.outlineButton(this, "Force Refresh", UiKit.COL_ACCENT) {
            forceRefreshTrackerFromSqlite()
        }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.85f)
        })
        headCard.addView(topBtns)
        pageContent.addView(headCard)

        // 1. HOME SCREEN PROGRESS & STREAK WIDGET PREVIEW + DYNAMIC REMOTEVIEWS GRID SCALER
        val detectedSw = UiKit.screenWidthDp(this)
        val effectiveTier = when (widgetPreviewTier) {
            "compact" -> "compact"
            "standard" -> "standard"
            "expanded" -> "expanded"
            else -> when {
                detectedSw < 350 -> "compact"
                detectedSw >= 412 -> "expanded"
                else -> "standard"
            }
        }

        val widgetCard = UiKit.card(this, borderColor = UiKit.COL_ACCENT, borderDp = 1.5f, padDp = 14)
        widgetCard.addView(UiKit.text(this, "Home Screen Progress & Streak Widget", 15.5f, UiKit.COL_TEXT_DARK, bold = true))
        widgetCard.addView(UiKit.text(
            this,
            "Dynamic RemoteViews GridLayout that scales streak count & weekly mesocycle set progress bars to your phone display (${detectedSw}dp).",
            11.5f,
            UiKit.COL_TEXT_MUTED
        ))
        widgetCard.addView(UiKit.spacerV(this, 8))

        val (tierScroll, tierRow) = UiKit.hScrollRow(this)
        listOf(
            "auto" to "Auto (${detectedSw}dp)",
            "compact" to "Small Display",
            "standard" to "Standard 4×2",
            "expanded" to "Large / 4×3"
        ).forEachIndexed { idx, (key, lbl) ->
            tierRow.addView(UiKit.chip(this, lbl, widgetPreviewTier == key) {
                widgetPreviewTier = key
                renderActivePage()
            })
            if (idx < 3) tierRow.addView(UiKit.spacerH(this, 5))
        }
        widgetCard.addView(tierScroll)
        widgetCard.addView(UiKit.spacerV(this, 10))

        // Live Visual Preview matching dynamic RemoteViews GridLayouts
        val previewShell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = UiKit.roundedBg(0xFF0C1324.toInt(), 18f, this@MainActivity, 0xFF233252.toInt(), 1f)
            val p = UiKit.rdp(this@MainActivity, if (effectiveTier == "compact") 10 else 12)
            setPadding(p, p, p, p)
        }
        val pvTop = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val pvIcon = ImageView(this).apply {
            setImageResource(R.drawable.ic_hyperlog_crest)
            val sz = UiKit.rdp(this@MainActivity, if (effectiveTier == "compact") 22 else 26)
            layoutParams = LinearLayout.LayoutParams(sz, sz).apply { rightMargin = UiKit.rdp(this@MainActivity, 8) }
        }
        pvTop.addView(pvIcon)
        val pvTitles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        pvTitles.addView(UiKit.text(
            this,
            if (effectiveTier == "expanded") "HyperLog · Mesocycle" else "HyperLog",
            if (effectiveTier == "compact") 12f else 13.5f,
            0xFFF8FAFC.toInt(),
            bold = true
        ))
        pvTitles.addView(UiKit.text(
            this,
            if (effectiveTier == "compact") "Best ${snap.bestStreakDays}d Streak"
            else "${snap.weekSubtitle} · Best ${snap.bestStreakDays}d",
            if (effectiveTier == "compact") 9.5f else 10.5f,
            0xFF94A3B8.toInt()
        ))
        pvTop.addView(pvTitles)

        val streakLabelText = if (effectiveTier == "compact") "🔥 ${snap.streakDays}d" else "🔥 ${snap.streakDays}d Streak"
        val streakBadge = UiKit.text(this, streakLabelText, if (effectiveTier == "expanded") 12f else 11f, 0xFFFDBA74.toInt(), bold = true, tabular = true).apply {
            background = UiKit.roundedBg(0xFF3A1A08.toInt(), 10f, this@MainActivity, 0xFFF97316.toInt(), 1f)
            val px = UiKit.rdp(this@MainActivity, 9); val py = UiKit.rdp(this@MainActivity, 4)
            setPadding(px, py, px, py)
        }
        pvTop.addView(streakBadge)
        previewShell.addView(pvTop)
        previewShell.addView(UiKit.spacerV(this, 7))

        val pvDays = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        snap.last7Days.forEachIndexed { idx, (dChar, active) ->
            val isToday = idx == snap.last7Days.lastIndex
            val col = when {
                active && isToday -> 0xFFFDBA74.toInt()
                active -> 0xFFBAE6FD.toInt()
                else -> 0xFF64748B.toInt()
            }
            val bgCol = when {
                active && isToday -> 0xFF3A1A08.toInt()
                active -> 0xFF152B48.toInt()
                else -> 0xFF111A2E.toInt()
            }
            val brdCol = when {
                active && isToday -> 0xFFF97316.toInt()
                active -> 0xFF38BDF8.toInt()
                else -> 0xFF1E2D4A.toInt()
            }
            val label = if (effectiveTier == "compact") {
                if (active) "$dChar✓" else dChar
            } else {
                "$dChar ${if (active) "●" else "○"}"
            }
            pvDays.addView(UiKit.text(this, label, if (effectiveTier == "compact") 9f else 9.5f, col, bold = true).apply {
                gravity = Gravity.CENTER
                background = UiKit.roundedBg(bgCol, 6f, this@MainActivity, brdCol, 1f)
                val py = UiKit.rdp(this@MainActivity, 3)
                setPadding(0, py, 0, py)
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    if (idx < 6) rightMargin = UiKit.rdp(this@MainActivity, 3)
                }
            })
        }
        previewShell.addView(pvDays)
        previewShell.addView(UiKit.spacerV(this, 7))

        val setsPct = ((snap.completedSets * 100.0) / snap.plannedSets.coerceAtLeast(1).toDouble()).roundToInt().coerceIn(0, 100)
        val kcalPct = ((snap.todayCalories * 100.0) / snap.targetCalories.coerceAtLeast(1).toDouble()).roundToInt().coerceIn(0, 100)

        if (effectiveTier == "compact") {
            val setsTile = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = UiKit.roundedBg(0xFF141F38.toInt(), 11f, this@MainActivity, 0xFF253659.toInt(), 1f)
                val p = UiKit.rdp(this@MainActivity, 8)
                setPadding(p, p, p, p)
            }
            setsTile.addView(UiKit.text(this, "TRAINING SETS · ${snap.completedSets}/${snap.plannedSets}", 10.5f, 0xFFFFFFFF.toInt(), bold = true, tabular = true))
            setsTile.addView(UiKit.progressBar(this, setsPct / 100f, 0xFF3B82F6.toInt()))
            setsTile.addView(UiKit.text(this, "$setsPct% done · Full-width compact grid", 9f, 0xFF94A3B8.toInt(), tabular = true))
            previewShell.addView(setsTile)
            previewShell.addView(UiKit.spacerV(this, 5))

            val kcalTile = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = UiKit.roundedBg(0xFF141F38.toInt(), 11f, this@MainActivity, 0xFF253659.toInt(), 1f)
                val p = UiKit.rdp(this@MainActivity, 8)
                setPadding(p, p, p, p)
            }
            kcalTile.addView(UiKit.text(this, "TODAY NUTRITION · ${snap.todayCalories}/${snap.targetCalories} kcal", 10.5f, 0xFFFFFFFF.toInt(), bold = true, tabular = true))
            kcalTile.addView(UiKit.progressBar(this, kcalPct / 100f, 0xFFF97316.toInt()))
            kcalTile.addView(UiKit.text(this, "Protein ${snap.todayProteinG}/${snap.targetProteinG}g", 9f, 0xFF94A3B8.toInt(), tabular = true))
            previewShell.addView(kcalTile)
        } else {
            val pvCols = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val leftTile = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = UiKit.roundedBg(0xFF141F38.toInt(), 12f, this@MainActivity, 0xFF253659.toInt(), 1f)
                val p = UiKit.rdp(this@MainActivity, 9)
                setPadding(p, p, p, p)
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    rightMargin = UiKit.rdp(this@MainActivity, 5)
                }
            }
            leftTile.addView(UiKit.text(this, "TRAINING VOLUME SETS", 9.5f, 0xFF93C5FD.toInt(), bold = true))
            leftTile.addView(UiKit.text(this, "${snap.completedSets} / ${snap.plannedSets} sets", 12.5f, 0xFFFFFFFF.toInt(), bold = true, tabular = true))
            leftTile.addView(UiKit.progressBar(this, setsPct / 100f, 0xFF3B82F6.toInt()))
            leftTile.addView(UiKit.text(this, "$setsPct% target volume", 9.5f, 0xFF94A3B8.toInt(), tabular = true))

            val rightTile = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = UiKit.roundedBg(0xFF141F38.toInt(), 12f, this@MainActivity, 0xFF253659.toInt(), 1f)
                val p = UiKit.rdp(this@MainActivity, 9)
                setPadding(p, p, p, p)
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    leftMargin = UiKit.rdp(this@MainActivity, 5)
                }
            }
            rightTile.addView(UiKit.text(this, "TODAY NUTRITION", 9.5f, 0xFFFDBA74.toInt(), bold = true))
            rightTile.addView(UiKit.text(this, "${snap.todayCalories} / ${snap.targetCalories}", 12.5f, 0xFFFFFFFF.toInt(), bold = true, tabular = true))
            rightTile.addView(UiKit.progressBar(this, kcalPct / 100f, 0xFFF97316.toInt()))
            rightTile.addView(UiKit.text(this, "Protein ${snap.todayProteinG}/${snap.targetProteinG}g", 9.5f, 0xFF94A3B8.toInt(), tabular = true))

            pvCols.addView(leftTile)
            pvCols.addView(rightTile)
            previewShell.addView(pvCols)

            // 2x2 Mesocycle Split Set Progress Bars Grid Preview
            if (snap.mesoSplitBars.size >= 4) {
                previewShell.addView(UiKit.spacerV(this, 6))
                val splitColors = intArrayOf(
                    0xFF3B82F6.toInt(),
                    0xFF10B981.toInt(),
                    0xFF38BDF8.toInt(),
                    0xFFF97316.toInt()
                )
                val splitWrap = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    background = UiKit.roundedBg(0xFF141F38.toInt(), 12f, this@MainActivity, 0xFF253659.toInt(), 1f)
                    val p = UiKit.rdp(this@MainActivity, 8)
                    setPadding(p, p, p, p)
                }
                for (rowIdx in 0..1) {
                    val r = LinearLayout(this).apply {
                        orientation = LinearLayout.HORIZONTAL
                        if (rowIdx == 0) {
                            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                                bottomMargin = UiKit.rdp(this@MainActivity, 4)
                            }
                        }
                    }
                    for (colIdx in 0..1) {
                        val bIdx = rowIdx * 2 + colIdx
                        val bar = snap.mesoSplitBars[bIdx]
                        val cell = LinearLayout(this).apply {
                            orientation = LinearLayout.VERTICAL
                            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                                if (colIdx == 0) rightMargin = UiKit.rdp(this@MainActivity, 5)
                                else leftMargin = UiKit.rdp(this@MainActivity, 5)
                            }
                        }
                        val title = if (effectiveTier == "expanded") "${bar.fullTitle} · ${bar.completedSets}/${bar.plannedSets}" else "${bar.shortTitle} ${bar.completedSets}/${bar.plannedSets}"
                        cell.addView(UiKit.text(this, title, 9.5f, 0xFFE2E8F0.toInt(), bold = true, tabular = true))
                        cell.addView(UiKit.progressBar(this, bar.progressPct / 100f, splitColors[bIdx]))
                        r.addView(cell)
                    }
                    splitWrap.addView(r)
                }
                previewShell.addView(splitWrap)
            }
        }
        widgetCard.addView(previewShell)
        widgetCard.addView(UiKit.spacerV(this, 6))

        val prefs = HyperLogDatabase.getPrefsForActiveUser(this)
        val lastTriggerRaw = prefs.getString("lastWidgetTrigger", "data_sync") ?: "data_sync"
        val triggerReadable = when (lastTriggerRaw) {
            HyperLogStreakWidgetProvider.SOURCE_SET_COMPLETED -> "Set Completed in Tracker"
            HyperLogStreakWidgetProvider.SOURCE_MEAL_SAVED -> "Meal Saved in Calories"
            else -> "Live SQLite Sync"
        }
        widgetCard.addView(UiKit.text(
            this,
            "Real-time AppWidgetManager sync active · Last trigger: $triggerReadable",
            11f,
            UiKit.COL_TEXT_MUTED,
            tabular = true
        ))
        widgetCard.addView(UiKit.spacerV(this, 8))

        val wBtnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        wBtnRow.addView(UiKit.primaryButton(this, "+ Pin Widget to Home Screen", UiKit.COL_ACCENT) {
            val pinned = HyperLogStreakWidgetProvider.requestPinToHomeScreen(this)
            HyperLogStreakWidgetProvider.refreshAllWidgets(this)
            if (pinned) {
                showBanner("Confirm the Android prompt to place your HyperLog widget!")
            } else {
                showBanner("Long-press your Android Home Screen → Widgets → HyperLog to place!")
            }
        }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.3f).apply {
                rightMargin = UiKit.rdp(this@MainActivity, 6)
            }
        })
        wBtnRow.addView(UiKit.outlineButton(this, "Sync Widget") {
            HyperLogStreakWidgetProvider.refreshAllWidgets(this)
            if (hapticEnabled) NativeHardwareBridge.hapticTick(this)
            showBanner("Home screen widget synced with latest SQLite progress!")
        }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.7f)
        })
        widgetCard.addView(wBtnRow)
        pageContent.addView(widgetCard)

        // 2. APPEARANCE & THEME DROPDOWN MENU (ALL 7 THEMES CONSOLIDATED IN DROPDOWN)
        val themeCard = UiKit.card(this, padDp = 14)
        themeCard.addView(UiKit.text(this, "Appearance & Theme Dropdown", 15.5f, UiKit.COL_TEXT_DARK, bold = true))
        themeCard.addView(UiKit.text(this, "Select any of the 7 light, frosted Pastel Glass, Clay 3D, or OLED dark themes from the dropdown menu", 11.5f, UiKit.COL_TEXT_MUTED))
        themeCard.addView(UiKit.spacerV(this, 8))

        val allModes = AppThemeMode.entries
        val curThemeIdx = allModes.indexOf(UiKit.themeMode).coerceAtLeast(0)
        val themeSpinnerLabels = allModes.map { m ->
            val kind = if (m.isDark) "Dark" else "Light"
            "Theme: ${m.label} ($kind) ▾"
        }
        val themeSpinner = Spinner(this, Spinner.MODE_DROPDOWN).apply {
            background = if (UiKit.isPastelGlass) {
                UiKit.pastelGlassSurfaceDrawable(this@MainActivity, radiusDp = 13f, subtle = false)
            } else {
                UiKit.roundedBg(UiKit.COL_SUBTLE, 12f, this@MainActivity, UiKit.COL_ACCENT, 1.3f)
            }
            minimumHeight = UiKit.dp(this@MainActivity, 46)
            adapter = object : ArrayAdapter<String>(this@MainActivity, android.R.layout.simple_spinner_item, themeSpinnerLabels) {
                override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                    return UiKit.text(this@MainActivity, themeSpinnerLabels[position], 13f, UiKit.COL_TEXT_DARK, bold = true).apply {
                        val px = UiKit.rdp(this@MainActivity, 12)
                        val py = UiKit.rdp(this@MainActivity, 10)
                        setPadding(px, py, px, py)
                    }
                }

                override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
                    val m = allModes[position]
                    val active = m == UiKit.themeMode
                    return LinearLayout(this@MainActivity).apply {
                        orientation = LinearLayout.VERTICAL
                        setBackgroundColor(if (active) UiKit.COL_SUBTLE else UiKit.COL_CARD)
                        val px = UiKit.dp(this@MainActivity, 14)
                        val py = UiKit.dp(this@MainActivity, 10)
                        setPadding(px, py, px, py)
                        addView(UiKit.text(
                            this@MainActivity,
                            "${m.label}${if (active) " ✓" else ""}",
                            13.5f,
                            if (active) UiKit.COL_ACCENT else UiKit.COL_TEXT_DARK,
                            bold = true
                        ))
                        addView(UiKit.text(this@MainActivity, m.subtitle, 11f, UiKit.COL_TEXT_MUTED))
                    }
                }
            }
            setSelection(curThemeIdx, false)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    val chosen = allModes.getOrNull(position) ?: return
                    if (chosen != UiKit.themeMode) {
                        UiKit.themeMode = chosen
                        savePrefs()
                        if (hapticEnabled) NativeHardwareBridge.hapticTick(this@MainActivity)
                        refreshShellTheme()
                    }
                }
                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
        }
        themeCard.addView(themeSpinner)
        themeCard.addView(UiKit.spacerV(this, 8))

        val activeThemePreview = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = if (UiKit.isPastelGlass) {
                UiKit.pastelGlassSurfaceDrawable(this@MainActivity, radiusDp = 12f, subtle = true)
            } else {
                UiKit.roundedBg(UiKit.COL_SUBTLE, 11f, this@MainActivity, UiKit.COL_BORDER, 1f)
            }
            val p = UiKit.rdp(this@MainActivity, 11)
            setPadding(p, p, p, p)
        }
        activeThemePreview.addView(UiKit.text(
            this,
            "Active Theme: ${UiKit.themeMode.label} (${if (UiKit.themeMode.isDark) "Dark Mode" else "Light / Pastel Mode"})",
            12.5f,
            UiKit.COL_ACCENT,
            bold = true
        ))
        activeThemePreview.addView(UiKit.spacerV(this, 2))
        activeThemePreview.addView(UiKit.text(this, UiKit.themeMode.subtitle, 11.5f, UiKit.COL_TEXT_MUTED))
        themeCard.addView(activeThemePreview)
        pageContent.addView(themeCard)

        // 2B. CLAYMORPHISM 3D STUDIO, WCAG ACCESSIBILITY & DAY-ZERO TELEMETRY CONSOLE
        val clayCard = UiKit.card(this, padDp = 14)
        clayCard.addView(UiKit.text(this, "Claymorphism 3D Studio & Day-Zero Telemetry", 15.5f, UiKit.COL_TEXT_DARK, bold = true))
        clayCard.addView(UiKit.text(
            this,
            "Inspect 4-screen Claymorphic wireframes, WCAG AA/AAA accessibility controls, and live Day-Zero ring-buffer telemetry (${db.getTelemetryLogCount()}/${HyperLogTelemetryLogger.MAX_RING_BUFFER_ENTRIES} events).",
            11.5f,
            UiKit.COL_TEXT_MUTED,
            tabular = true
        ))
        clayCard.addView(UiKit.spacerV(this, 8))
        clayCard.addView(UiKit.primaryButton(this, "Open 4-Screen Claymorphism Wireframes & Palette", UiKit.COL_ACCENT) {
            showClaymorphismDesignStudioDialog()
        })
        clayCard.addView(UiKit.spacerV(this, 10))

        // Accessibility Toggle 1: High-Contrast Clay Borders
        val hcClayRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val hcClayCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        hcClayCol.addView(UiKit.text(this, "High-Contrast Clay Borders (WCAG AAA)", 13f, UiKit.COL_TEXT_DARK, bold = true))
        hcClayCol.addView(UiKit.text(this, "Adds crisp 2dp indigo rims around pastel clay surfaces", 11.5f, UiKit.COL_TEXT_MUTED))
        hcClayRow.addView(hcClayCol)
        hcClayRow.addView(Switch(this).apply {
            isChecked = UiKit.clayHighContrast
            setOnCheckedChangeListener { _, checked ->
                UiKit.clayHighContrast = checked
                savePrefs()
                HyperLogTelemetryLogger.logEvent(this@MainActivity, db, "ACTION", "ui", "clay_high_contrast_toggled", metadata = mapOf("enabled" to checked))
                refreshShellTheme()
            }
        })
        clayCard.addView(hcClayRow)
        clayCard.addView(UiKit.spacerV(this, 8))

        // Accessibility Toggle 2: Reduced 3D Depth
        val flatClayRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val flatClayCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        flatClayCol.addView(UiKit.text(this, "Reduced 3D Clay Depth", 13f, UiKit.COL_TEXT_DARK, bold = true))
        flatClayCol.addView(UiKit.text(this, "Softens multi-layer bevel shadows for glare sensitivity", 11.5f, UiKit.COL_TEXT_MUTED))
        flatClayRow.addView(flatClayCol)
        flatClayRow.addView(Switch(this).apply {
            isChecked = UiKit.clayFlatDepth
            setOnCheckedChangeListener { _, checked ->
                UiKit.clayFlatDepth = checked
                savePrefs()
                HyperLogTelemetryLogger.logEvent(this@MainActivity, db, "ACTION", "ui", "clay_flat_depth_toggled", metadata = mapOf("enabled" to checked))
                refreshShellTheme()
            }
        })
        clayCard.addView(flatClayRow)
        clayCard.addView(UiKit.spacerV(this, 10))

        // Live Day-Zero Telemetry Log Preview + Archive / Purge Actions
        val recentTelemetry = db.getTelemetryLogs(limit = 5)
        if (recentTelemetry.isNotEmpty()) {
            clayCard.addView(UiKit.text(this, "Recent Day-Zero Telemetry Events", 11.5f, UiKit.COL_TEXT_MUTED, bold = true))
            recentTelemetry.forEach { tEntry ->
                clayCard.addView(UiKit.spacerV(this, 3))
                val durSuffix = if (tEntry.durationMs != null) " (${tEntry.durationMs}ms)" else ""
                clayCard.addView(UiKit.text(
                    this,
                    "• [T+${tEntry.dayZeroOffsetMin}m] ${tEntry.level} · ${tEntry.category}/${tEntry.event}$durSuffix",
                    11f,
                    UiKit.COL_TEXT_DARK,
                    tabular = true
                ))
            }
            clayCard.addView(UiKit.spacerV(this, 8))
        }

        val logActionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        logActionRow.addView(UiKit.outlineButton(this, "Archive Logs (.JSON)", UiKit.COL_ACCENT) {
            val receipt = HyperLogTelemetryLogger.archiveLogsToJson(this, db)
            showBanner("✓ Archived ${receipt.archivedCount} logs -> ${receipt.archiveFileName}")
            renderActivePage()
        }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                rightMargin = UiKit.rdp(this@MainActivity, 6)
            }
        })
        logActionRow.addView(UiKit.outlineButton(this, "Purge Logs (Day-Zero)", 0xFFD97706.toInt()) {
            val purged = HyperLogTelemetryLogger.purgeLogsToDayZero(this, db, deleteArchives = false)
            showBanner("✓ Purged $purged live telemetry logs & reset Day-Zero clock to T+0.0m!")
            renderActivePage()
        }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        clayCard.addView(logActionRow)
        pageContent.addView(clayCard)

        // 3. TRAINING, UNITS, HAPTICS & PHONE SCREEN ADAPTATION
        val prefCard = UiKit.card(this, padDp = 14)
        prefCard.addView(UiKit.text(this, "Training, Units & Device Hardware", 15.5f, UiKit.COL_TEXT_DARK, bold = true))
        prefCard.addView(UiKit.spacerV(this, 8))

        // Weight Unit Row
        val unitRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        unitRow.addView(UiKit.text(this, "Barbell & Bodyweight Unit", 13f, UiKit.COL_TEXT_DARK, bold = true).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        listOf("kg", "lb").forEachIndexed { idx, u ->
            unitRow.addView(UiKit.chip(this, u.uppercase(), weightUnit == u) {
                weightUnit = u
                savePrefs()
                renderActivePage()
            })
            if (idx == 0) unitRow.addView(UiKit.spacerH(this, 6))
        }
        prefCard.addView(unitRow)
        prefCard.addView(UiKit.spacerV(this, 10))

        // Default Rest Timer Duration
        prefCard.addView(UiKit.text(this, "Default Rest Timer (${customRestDurationSec}s)", 13f, UiKit.COL_TEXT_DARK, bold = true))
        prefCard.addView(UiKit.spacerV(this, 5))
        val (restScroll, restRow) = UiKit.hScrollRow(this)
        listOf(60, 90, 120, 180).forEach { sec ->
            restRow.addView(UiKit.chip(this, "${sec}s", customRestDurationSec == sec) {
                setPresetRestSeconds(sec)
            })
            restRow.addView(UiKit.spacerH(this, 6))
        }
        restRow.addView(UiKit.outlineButton(this, "Custom Sec", UiKit.COL_ACCENT) {
            showCustomRestSecondsDialog()
        })
        prefCard.addView(restScroll)
        prefCard.addView(UiKit.spacerV(this, 10))

        // Native Vibration Motor Switch
        val vibRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val motorStatus = if (NativeHardwareBridge.hasVibrator(this)) "Native Motor Ready" else "Simulated"
        val vibCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        vibCol.addView(UiKit.text(this, "Vibration Rest Alarm", 13f, UiKit.COL_TEXT_DARK, bold = true))
        vibCol.addView(UiKit.text(this, "Triple-pulse vibration when rest ends ($motorStatus)", 11.5f, UiKit.COL_TEXT_MUTED))
        vibRow.addView(vibCol)
        vibRow.addView(UiKit.outlineButton(this, "Test") {
            NativeHardwareBridge.hapticRestComplete(this)
            showBanner("Triggered native vibration motor test pulse!")
        })
        vibRow.addView(UiKit.spacerH(this, 6))
        vibRow.addView(Switch(this).apply {
            isChecked = hapticEnabled
            setOnCheckedChangeListener { _, checked ->
                hapticEnabled = checked
                savePrefs()
                if (checked) NativeHardwareBridge.hapticTick(this@MainActivity)
            }
        })
        prefCard.addView(vibRow)
        prefCard.addView(UiKit.spacerV(this, 10))

        // Timer Audio Tone Switch (Set & Complete Chimes)
        val toneRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val toneCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        toneCol.addView(UiKit.text(this, "Timer Audio Tones (Set & Finish)", 13f, UiKit.COL_TEXT_DARK, bold = true))
        toneCol.addView(UiKit.text(this, "Plays crisp chime when Rest, Workout, Yoga, or HIIT timers are set & finish", 11.5f, UiKit.COL_TEXT_MUTED))
        toneRow.addView(toneCol)
        toneRow.addView(UiKit.outlineButton(this, "Test") {
            NativeHardwareBridge.playTimerSetTone(this, true)
            showBanner("Played timer set confirmation tone!")
        })
        toneRow.addView(UiKit.spacerH(this, 6))
        toneRow.addView(Switch(this).apply {
            isChecked = soundOnTimer
            setOnCheckedChangeListener { _, checked ->
                soundOnTimer = checked
                savePrefs()
                if (checked) NativeHardwareBridge.playTimerSetTone(this@MainActivity, true)
            }
        })
        prefCard.addView(toneRow)
        prefCard.addView(UiKit.spacerV(this, 10))

        // Keep Screen Awake Switch
        val wakeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val wakeCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        wakeCol.addView(UiKit.text(this, "Keep Gym Screen Awake", 13f, UiKit.COL_TEXT_DARK, bold = true))
        wakeCol.addView(UiKit.text(this, "Prevents screen timeout during active set logging", 11.5f, UiKit.COL_TEXT_MUTED))
        wakeRow.addView(wakeCol)
        wakeRow.addView(Switch(this).apply {
            isChecked = keepScreenOn
            setOnCheckedChangeListener { _, checked ->
                keepScreenOn = checked
                savePrefs()
                NativeHardwareBridge.setKeepScreenOn(this@MainActivity, checked)
            }
        })
        prefCard.addView(wakeRow)
        prefCard.addView(UiKit.spacerV(this, 10))

        // Auto-Detected Phone Screen Adaptation & Network Info
        val sw = UiKit.screenWidthDp(this)
        val sh = UiKit.screenHeightDp(this)
        val dpi = resources.displayMetrics.densityDpi
        val (_, netLabel) = NativeHardwareBridge.getNetworkStatus(this)
        val profileTag = when {
            sw < 360 -> "Compact Android Phone"
            sw < 412 -> "Standard Android Phone"
            else -> "Expanded / Large Android Phone"
        }
        prefCard.addView(UiKit.text(
            this,
            "HyperLog v4.0.0 (Build 14) · ${sw}dp × ${sh}dp · ${dpi}dpi ($profileTag) · Net: $netLabel",
            11f,
            UiKit.COL_TEXT_MUTED,
            tabular = true
        ))
        pageContent.addView(prefCard)

        // 3.1 DEDICATED HEALTH INTEGRATION SUB-SECTION (HEALTH CONNECT + GOOGLE FIT)
        val healthCard = UiKit.card(this, padDp = 14)
        healthCard.addView(UiKit.text(this, "Health Integration", 15.5f, UiKit.COL_TEXT_DARK, bold = true))
        healthCard.addView(UiKit.text(
            this,
            "Consolidated Android Health Connect & Google Fit activity sync controls.",
            11.5f,
            UiKit.COL_TEXT_MUTED
        ))
        healthCard.addView(UiKit.spacerV(this, 10))
        val hcSyncBtnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        hcSyncBtnRow.addView(UiKit.primaryButton(this, "Sync Latest Workout", UiKit.COL_ACCENT) {
            val todayDone = db.getCompletedSetsForDate(LocalDate.now().toString())
            val tonKg = todayDone.sumOf { it.weightKg * it.reps }
            NativeHardwareBridge.syncWorkoutToHealthConnect(
                activity = this,
                db = db,
                title = "HyperLog Training Session",
                completedSets = todayDone.size,
                tonnageKg = tonKg,
                durationMinutes = 45,
                modality = "strength"
            ) { msg ->
                showBanner(msg)
                renderActivePage()
            }
        }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                rightMargin = UiKit.rdp(this@MainActivity, 6)
            }
        })
        hcSyncBtnRow.addView(UiKit.outlineButton(this, "Google Fit Ready ✓", 0xFF059669.toInt()) {
            val todayDone = db.getCompletedSetsForDate(LocalDate.now().toString())
            db.logHealthConnectSync(
                "Google Fit Activity Segment (${todayDone.size} sets)",
                todayDone.size,
                todayDone.sumOf { it.weightKg * it.reps },
                "SYNCED"
            )
            showBanner("✓ Recorded workout activity segment for Google Fit & Health Connect")
            renderActivePage()
        }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        healthCard.addView(hcSyncBtnRow)
        val recentHcSyncs = db.getRecentHealthConnectSyncs(3)
        if (recentHcSyncs.isNotEmpty()) {
            healthCard.addView(UiKit.spacerV(this, 8))
            recentHcSyncs.forEach { rec ->
                healthCard.addView(UiKit.text(
                    this,
                    "• ${rec.summary} · ${rec.status}",
                    11f,
                    UiKit.COL_TEXT_MUTED,
                    tabular = true
                ))
                healthCard.addView(UiKit.spacerV(this, 3))
            }
        }
        pageContent.addView(healthCard)

        // 3A. POST-TESTING USER FEEDBACK LOOP & APK TESTING / BUG TRIAGE GUIDE
        val fbCard = UiKit.card(this, padDp = 14)
        fbCard.addView(UiKit.text(this, "Beta Tester Feedback & Bug Report Loop", 15.5f, UiKit.COL_TEXT_DARK, bold = true))
        fbCard.addView(UiKit.text(
            this,
            "Found a bug or have an idea while testing HyperLog v4.0.0? Rate your experience below — reports save offline to SQLite + HyperLogData/feedback and sync when online.",
            11.5f,
            UiKit.COL_TEXT_MUTED
        ))
        fbCard.addView(UiKit.spacerV(this, 8))

        val (starScroll, starRow) = UiKit.hScrollRow(this)
        (1..5).forEach { stars ->
            starRow.addView(UiKit.chip(this, "$stars ★", feedbackRating == stars) {
                feedbackRating = stars
                if (hapticEnabled) NativeHardwareBridge.hapticTick(this)
                renderActivePage()
            })
            starRow.addView(UiKit.spacerH(this, 6))
        }
        fbCard.addView(starScroll)
        fbCard.addView(UiKit.spacerV(this, 6))

        val (fbCatScroll, fbCatRow) = UiKit.hScrollRow(this)
        listOf("Workout Tracker", "Forearms & Grip", "Breathing Audio", "Indian Recipes", "UI Simplicity", "Bug Report").forEach { cat ->
            fbCatRow.addView(UiKit.chip(this, cat, feedbackCategory == cat) {
                feedbackCategory = cat
                renderActivePage()
            })
            fbCatRow.addView(UiKit.spacerH(this, 6))
        }
        fbCard.addView(fbCatScroll)
        fbCard.addView(UiKit.spacerV(this, 8))

        val fbInput = UiKit.inputBox(
            this,
            feedbackDraftText,
            "Describe what worked well or any issue you noticed...",
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        ).apply {
            minLines = 2
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    feedbackDraftText = s?.toString() ?: ""
                }
            })
        }
        fbCard.addView(fbInput)
        fbCard.addView(UiKit.spacerV(this, 8))

        val deviceTag = "${Build.MANUFACTURER} ${Build.MODEL} · Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT}) · ${sw}x${sh}dp"
        fbCard.addView(UiKit.primaryButton(this, "Submit Feedback Report", UiKit.COL_ACCENT) {
            val cleanMsg = fbInput.text.toString().trim()
            if (cleanMsg.length < 3) {
                showBanner("Please enter a short note (3+ characters) before submitting.")
            } else {
                val saved = db.saveUserFeedback(feedbackRating, feedbackCategory, cleanMsg, deviceTag)
                feedbackDraftText = ""
                HyperLogStorageManager.saveDatabaseSnapshotAsync(this, db)
                syncFeedbackToServerAsync(saved)
                if (hapticEnabled) NativeHardwareBridge.hapticTick(this)
                showBanner("✓ Thank you! Feedback (${saved.rating}★ · ${saved.category}) saved & queued for review.")
                renderActivePage()
            }
        })

        val savedFeedbackList = db.getUserFeedbackList(5)
        if (savedFeedbackList.isNotEmpty()) {
            fbCard.addView(UiKit.spacerV(this, 8))
            fbCard.addView(UiKit.text(this, "Recent Device Feedback (${savedFeedbackList.size})", 11.5f, UiKit.COL_TEXT_MUTED, bold = true))
            savedFeedbackList.forEach { item ->
                fbCard.addView(UiKit.spacerV(this, 4))
                fbCard.addView(UiKit.text(
                    this,
                    "• ${item.rating}★ [${item.category}] ${item.message}",
                    11.5f,
                    UiKit.COL_TEXT_DARK,
                    tabular = true
                ))
            }
        }

        fbCard.addView(UiKit.spacerV(this, 8))
        fbCard.addView(UiKit.outlineButton(
            this,
            if (showTestingGuideDrawer) "Hide Multi-Device Testing Checklist ▴" else "Show Multi-Device Testing Checklist ▾"
        ) {
            showTestingGuideDrawer = !showTestingGuideDrawer
            renderActivePage()
        })
        if (showTestingGuideDrawer) {
            fbCard.addView(UiKit.spacerV(this, 6))
            listOf(
                "1. User Vault Isolation: Tap 'Profile' in the top bar -> create 'User B' -> verify 0 workout history, 0 streaks, and clean 70kg weight with zero data bleed from User A.",
                "2. Offline Demo Videos: Open Library -> 'Offline Videos' -> download Starter Pack, enable Airplane Mode, and tap '▶ Watch Offline Demo'.",
                "3. Manual Entry & Delete Mistakes: Open Workouts -> 'History & Streaks' -> '+ Log Missed / Phone-Free Workout' -> save 2 exercises, then test '✕ Delete' or 'Delete Session'.",
                "4. Pastel Glass Theme & Touch Response: Select 'Pastel Glass' under Appearance and verify zero-delay button press feedback across all tabs.",
                "5. Multi-Screen & Widget Sync: Verify portrait/landscape scaling + Home Screen Streak Widget auto-update per active profile."
            ).forEach { line ->
                fbCard.addView(UiKit.text(this, line, 11f, UiKit.COL_TEXT_MID))
                fbCard.addView(UiKit.spacerV(this, 3))
            }
        }

        fbCard.addView(UiKit.spacerV(this, 6))
        fbCard.addView(UiKit.outlineButton(
            this,
            if (showTriagePlanDrawer) "Hide Post-Testing Bug Resolution Plan ▴" else "Show Post-Testing Bug Resolution Plan ▾"
        ) {
            showTriagePlanDrawer = !showTriagePlanDrawer
            renderActivePage()
        })
        if (showTriagePlanDrawer) {
            fbCard.addView(UiKit.spacerV(this, 6))
            listOf(
                "• P0 Critical (Crash / Data Loss): Reproduce via JSON snapshot, patch SQLite migration, ship signed hotfix APK within 24h.",
                "• P1 High (Timer / Audio / Sync Glitch): Verify Android API 26–35 compatibility & audio focus, release in weekly build.",
                "• P2 Medium (UI / Layout / Recipe Request): Adjust dp scaling or expand training-bundle JSON without requiring reinstall."
            ).forEach { line ->
                fbCard.addView(UiKit.text(this, line, 11f, UiKit.COL_TEXT_MID))
                fbCard.addView(UiKit.spacerV(this, 3))
            }
        }
        pageContent.addView(fbCard)

        // 3B. ANDROID INTERNAL STORAGE FOLDERS & STARTUP TRAINING PACKAGE
        val pkgOverview = HyperLogStorageManager.getOverview(this)
        val pkgCard = UiKit.card(this, padDp = 14)
        pkgCard.addView(UiKit.text(this, "Internal Storage Folders & Training Package", 15.5f, UiKit.COL_TEXT_DARK, bold = true))
        pkgCard.addView(UiKit.text(
            this,
            "Package v${pkgOverview.packageVersion} · ${pkgOverview.exerciseCount} exercises · ${pkgOverview.videoGuideCount} video guides stored offline in internal folders",
            11.5f,
            UiKit.COL_TEXT_MUTED,
            tabular = true
        ))
        pkgCard.addView(UiKit.spacerV(this, 8))
        pkgOverview.folders.forEach { f ->
            val fRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = UiKit.roundedBg(UiKit.COL_SUBTLE, 9f, this@MainActivity, UiKit.COL_BORDER, 1f)
                val p = UiKit.rdp(this@MainActivity, 8)
                setPadding(p, p, p, p)
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = UiKit.rdp(this@MainActivity, 5)
                }
            }
            fRow.addView(UiKit.text(this, f.relativePath, 12f, UiKit.COL_TEXT_DARK, bold = true, tabular = true).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            fRow.addView(UiKit.text(
                this,
                "${f.fileCount} files · ${HyperLogStorageManager.formatBytes(f.totalBytes)}",
                11.5f,
                UiKit.COL_TEXT_MUTED,
                tabular = true
            ))
            pkgCard.addView(fRow)
        }
        pkgCard.addView(UiKit.spacerV(this, 6))
        pkgCard.addView(UiKit.outlineButton(this, "Re-Download Training Package (v${HyperLogStorageManager.PACKAGE_VERSION})", UiKit.COL_ACCENT) {
            HyperLogStorageManager.downloadStartupTrainingPackageIfNeeded(
                context = this,
                db = db,
                forceRedownload = true,
                onProgress = { pct, lbl ->
                    mainHandler.post { showBanner("📦 Package $pct% · $lbl") }
                },
                onComplete = { updated ->
                    mainHandler.post {
                        showBanner("✓ Unpacked Training Package v${updated.packageVersion} into HyperLogData folders!")
                        renderActivePage()
                    }
                }
            )
        })
        pageContent.addView(pkgCard)

        // 4. ONLINE CATALOG SYNC, HEALTH CONNECT & EXPORT ALL DATA
        val setsByDateDesc = db.getCompletedSetsByDateDesc()
        val notesMap = db.getWorkoutDayNotesMap()
        val landmarks = db.getLandmarks()
        val allCompletedSets = setsByDateDesc.values.flatten()
        val totalVolKg = allCompletedSets.sumOf { it.weightKg * it.reps }
        val dispLifetimeVol = if (weightUnit == "lb") "${(totalVolKg * 2.20462).roundToInt()} lb" else "${totalVolKg.roundToInt()} kg"

        val dataCard = UiKit.card(this, padDp = 14)
        dataCard.addView(UiKit.text(this, "Online Sync, Health Connect & Export All Data", 15.5f, UiKit.COL_TEXT_DARK, bold = true))
        val hcPresent = NativeHardwareBridge.isHealthConnectInstalled(this)
        dataCard.addView(UiKit.text(
            this,
            if (hcPresent) "Standalone Offline SQLite v6 + Mobile Data / Wi-Fi Exercise Sync + Android Health Connect Ready."
            else "All workouts, wellbeing, and meals live 100% offline in SQLite. Pull 870+ online exercises anytime over Mobile Data or Wi-Fi.",
            11.5f,
            UiKit.COL_TEXT_MUTED
        ))
        dataCard.addView(UiKit.spacerV(this, 8))
        dataCard.addView(UiKit.primaryButton(
            this,
            if (isSyncingOnlineCatalog) "Syncing Online Catalog..." else "Pull 870+ Online Exercises & Workouts ($netLabel)",
            UiKit.COL_ACCENT
        ) {
            triggerOnlineCatalogSync()
        })
        dataCard.addView(UiKit.spacerV(this, 10))

        // All-Time Historical KPI Row
        val allKpiRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(
            "WORKOUT DAYS" to setsByDateDesc.size.toString(),
            "ALL-TIME SETS" to allCompletedSets.size.toString(),
            "LIFETIME VOL" to dispLifetimeVol
        ).forEachIndexed { idx, (lbl, v) ->
            allKpiRow.addView(UiKit.metricBox(this, lbl, v).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    if (idx < 2) rightMargin = UiKit.rdp(this@MainActivity, 6)
                }
            })
        }
        dataCard.addView(allKpiRow)
        dataCard.addView(UiKit.spacerV(this, 10))

        // Primary All-History PDF Export & Share Row
        val pdfExportRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        pdfExportRow.addView(UiKit.primaryButton(this, "Export All Data (.PDF)", UiKit.COL_ACCENT) {
            triggerExportAllHistoryPdf()
        }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                rightMargin = UiKit.rdp(this@MainActivity, 6)
            }
        })
        pdfExportRow.addView(UiKit.outlineButton(this, "Share All (.PDF)", UiKit.COL_ACCENT) {
            triggerShareAllHistoryPdf()
        }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        dataCard.addView(pdfExportRow)
        dataCard.addView(UiKit.spacerV(this, 8))

        dataCard.addView(UiKit.outlineButton(this, "Export All Workouts (.CSV)") {
            triggerExportCsv()
        })
        dataCard.addView(UiKit.spacerV(this, 8))

        val bRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        bRow.addView(UiKit.outlineButton(this, "Export .JSON Backup", UiKit.COL_ACCENT) {
            triggerExportJson()
        }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                rightMargin = UiKit.rdp(this@MainActivity, 6)
            }
        })
        bRow.addView(UiKit.outlineButton(this, "Import .JSON Backup") {
            triggerImportJson()
        }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        dataCard.addView(bRow)
        dataCard.addView(UiKit.spacerV(this, 8))

        // Collapsible Complete Historical Sessions Browser
        dataCard.addView(UiKit.outlineButton(
            this,
            if (showAllHistoryInSettings) "Hide All Workout Sessions (${setsByDateDesc.size}) ▴"
            else "Browse All Workout Sessions (${setsByDateDesc.size}) ▾"
        ) {
            showAllHistoryInSettings = !showAllHistoryInSettings
            renderActivePage()
        })

        if (showAllHistoryInSettings && setsByDateDesc.isNotEmpty()) {
            dataCard.addView(UiKit.spacerV(this, 8))
            setsByDateDesc.entries.forEach { (dIso, dSets) ->
                val note = notesMap[dIso]
                val sessTitle = note?.title?.takeIf { it.isNotBlank() }
                    ?: dSets.firstOrNull()?.let { if (it.dayNumber > 0) "Week ${it.week} · Day ${it.dayNumber}" else "Logged Session" }
                    ?: "Workout"
                val rowCard = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    background = UiKit.roundedBg(UiKit.COL_SUBTLE, 10f, this@MainActivity, UiKit.COL_BORDER, 1f)
                    val p = UiKit.rdp(this@MainActivity, 9)
                    setPadding(p, p, p, p)
                    layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                        bottomMargin = UiKit.rdp(this@MainActivity, 6)
                    }
                }
                val leftCol = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                val musclesStr = dSets.map { landmarks[it.muscleId]?.shortName ?: it.muscleId }.distinct().joinToString(", ")
                leftCol.addView(UiKit.text(this, "$dIso · $sessTitle", 12.5f, UiKit.COL_TEXT_DARK, bold = true, tabular = true))
                leftCol.addView(UiKit.text(this, "${dSets.size} sets · $musclesStr", 11f, UiKit.COL_TEXT_MUTED, tabular = true))
                rowCard.addView(leftCol)
                rowCard.addView(UiKit.spacerH(this, 6))
                rowCard.addView(UiKit.chip(this, "Open Day", false) {
                    val parsed = try { LocalDate.parse(dIso) } catch (_: Exception) { LocalDate.now() }
                    calendarYear = parsed.year
                    calendarMonth = parsed.monthValue
                    calendarSelectedDateIso = dIso
                    workoutsSubTab = "calendar"
                    activeTab = 2
                    rebuildTopSettingsButton()
                    rebuildBottomNav()
                    renderActivePage()
                })
                dataCard.addView(rowCard)
            }
        }

        dataCard.addView(UiKit.spacerV(this, 8))
        val hcRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        hcRow.addView(UiKit.outlineButton(this, "Sync Latest Workout to Health Connect", UiKit.COL_ACCENT) {
            val todayIso = LocalDate.now().toString()
            val todaySets = db.getCompletedSetsForDate(todayIso).ifEmpty { allCompletedSets.take(8) }
            val tonKg = todaySets.sumOf { it.weightKg * it.reps }
            NativeHardwareBridge.syncWorkoutToHealthConnect(
                activity = this,
                db = db,
                title = notesMap[todayIso]?.title ?: "HyperLog Workout Session",
                completedSets = todaySets.size.coerceAtLeast(1),
                tonnageKg = tonKg,
                durationMinutes = notesMap[todayIso]?.durationMinutes ?: 50,
                modality = "strength"
            ) { msg ->
                showBanner(msg)
                renderActivePage()
            }
        }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.25f).apply {
                rightMargin = UiKit.rdp(this@MainActivity, 6)
            }
        })
        hcRow.addView(UiKit.outlineButton(this, "HC Settings") {
            showBanner(NativeHardwareBridge.openHealthConnectOrReportOffline(this, "HyperLog Permissions"))
        }.apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.75f)
        })
        dataCard.addView(hcRow)

        val recentHc = db.getRecentHealthConnectSyncs(3)
        if (recentHc.isNotEmpty()) {
            dataCard.addView(UiKit.spacerV(this, 6))
            recentHc.forEach { rec ->
                dataCard.addView(UiKit.text(
                    this,
                    "• HC Sync: ${rec.summary} (${rec.setsCount} sets) — ${rec.status}",
                    11f,
                    UiKit.COL_TEXT_MUTED,
                    tabular = true
                ))
            }
        }
        dataCard.addView(UiKit.spacerV(this, 8))

        dataCard.addView(UiKit.outlineButton(this, "Clear My Personal Logs (Fresh Slate)", 0xFFD97706.toInt()) {
            AlertDialog.Builder(this, UiKit.dialogTheme())
                .setTitle("Start Fresh Personal Log?")
                .setMessage("This clears all workout history, streaks, logged meals, and weight entries for '${activeAcc.displayName}' while keeping your custom exercises, templates, and downloaded offline videos.")
                .setPositiveButton("Clear Personal Logs") { _, _ ->
                    db.clearPersonalLogsToFreshState()
                    activeWeek = 1
                    activeDay = 1
                    standaloneSession = null
                    hasSelectedScheduleDay = false
                    stopRestTimer()
                    stopAndResetGlobalWorkoutTimer()
                    savePrefs()
                    HyperLogStorageManager.saveDatabaseSnapshotAsync(this, db)
                    showBanner("✓ Cleared personal logs — '${activeAcc.displayName}' is now a fresh slate!")
                    renderActivePage()
                }
                .setNegativeButton("Cancel", null)
                .show()
        })
        dataCard.addView(UiKit.spacerV(this, 8))

        dataCard.addView(UiKit.outlineButton(this, "Reset App Data to Factory Seed", 0xFFEF4444.toInt()) {
            AlertDialog.Builder(this, UiKit.dialogTheme())
                .setTitle("Reset Offline SQLite Database?")
                .setMessage("This will restore default hypertrophy landmarks, starter templates, and profile defaults. Export a JSON or PDF backup first if you want to keep your custom logs.")
                .setPositiveButton("Reset Data") { _, _ ->
                    db.resetToDefaults()
                    HyperLogStreakWidgetProvider.refreshAllWidgets(this)
                    showBanner("Reset offline SQLite database to factory defaults")
                    renderActivePage()
                }
                .setNegativeButton("Cancel", null)
                .show()
        })
        pageContent.addView(dataCard)
    }

    /**
     * Best-effort background sync of user beta feedback to `/api/feedback`.
     * Even if the phone has zero internet, the feedback is already safely saved in SQLite
     * and inside `HyperLogData/feedback/tester_feedback.json`!
     */
    private fun syncFeedbackToServerAsync(entry: UserFeedbackEntry) {
        val (online, _) = NativeHardwareBridge.getNetworkStatus(this)
        if (!online) return
        Thread {
            var conn: HttpURLConnection? = null
            try {
                val url = URL("https://ais-pre-qzg7nmjamtuqyedml457av-240410553463.asia-southeast1.run.app/api/feedback")
                conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 6000
                    readTimeout = 6000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
                val payload = JSONObject()
                    .put("id", entry.id)
                    .put("rating", entry.rating)
                    .put("category", entry.category)
                    .put("message", entry.message)
                    .put("deviceInfo", entry.deviceInfo)
                    .put("source", "android-apk-v4.0.0")
                    .put("createdAtIso", entry.createdAtIso)
                    .toString()
                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(payload) }
                conn.responseCode
            } catch (_: Exception) {
                // Offline fallback already persisted in SQLite & HyperLogData/feedback/
            } finally {
                conn?.disconnect()
            }
        }.start()
    }

    private fun triggerExportAllHistoryPdf() {
        val setsByDateDesc = db.getCompletedSetsByDateDesc()
        if (setsByDateDesc.isEmpty()) {
            showBanner("No completed workouts found to export.")
            return
        }
        try {
            val file = WorkoutPdfExporter.generateAllHistoryPdf(
                context = this,
                setsByDateDesc = setsByDateDesc,
                notesMap = db.getWorkoutDayNotesMap(),
                landmarks = db.getLandmarks(),
                weightUnit = weightUnit
            )
            pendingExportSourceFile = file
            val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "application/pdf"
                putExtra(Intent.EXTRA_TITLE, file.name)
            }
            startActivityForResult(intent, REQ_SAVE_PDF)
        } catch (e: Exception) {
            showBanner("All-history PDF export failed: ${e.message}")
        }
    }

    private fun triggerShareAllHistoryPdf() {
        val setsByDateDesc = db.getCompletedSetsByDateDesc()
        if (setsByDateDesc.isEmpty()) {
            showBanner("No completed workouts found to share.")
            return
        }
        try {
            val file = WorkoutPdfExporter.generateAllHistoryPdf(
                context = this,
                setsByDateDesc = setsByDateDesc,
                notesMap = db.getWorkoutDayNotesMap(),
                landmarks = db.getLandmarks(),
                weightUnit = weightUnit
            )
            val ok = WorkoutPdfExporter.shareExportFile(
                activity = this,
                file = file,
                mimeType = "application/pdf",
                chooserTitle = "Share Complete Workout History PDF",
                subject = "HyperLog Complete Workout History"
            )
            if (!ok) {
                triggerExportAllHistoryPdf()
            }
        } catch (e: Exception) {
            showBanner("Share failed: ${e.message}")
        }
    }

    private fun triggerExportCsv() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/csv"
            putExtra(Intent.EXTRA_TITLE, "hyperlog-all-workouts-${LocalDate.now()}.csv")
        }
        try {
            startActivityForResult(intent, REQ_EXPORT_CSV)
        } catch (e: Exception) {
            showBanner("File picker unavailable: ${e.message}")
        }
    }

    private fun triggerExportJson() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/json"
            putExtra(Intent.EXTRA_TITLE, "hyperlog-backup-${LocalDate.now()}.json")
        }
        try {
            startActivityForResult(intent, REQ_EXPORT_JSON)
        } catch (e: Exception) {
            showBanner("File picker unavailable: ${e.message}")
        }
    }

    private fun triggerImportJson() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        try {
            startActivityForResult(intent, REQ_IMPORT_JSON)
        } catch (e: Exception) {
            showBanner("File picker unavailable: ${e.message}")
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        when (requestCode) {
            REQ_EXPORT_JSON -> {
                try {
                    val json = db.exportFullJsonBackup()
                    contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray(Charsets.UTF_8)) }
                    showBanner("Saved offline JSON backup to device storage!")
                } catch (e: Exception) {
                    showBanner("Export failed: ${e.message}")
                }
            }
            REQ_IMPORT_JSON -> {
                try {
                    val json = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                    if (!json.isNullOrBlank()) {
                        db.importFullJsonBackup(json)
                        HyperLogStreakWidgetProvider.refreshAllWidgets(this)
                        showBanner("Restored offline JSON backup into SQLite!")
                        renderActivePage()
                    }
                } catch (e: Exception) {
                    showBanner("Import failed: ${e.message}")
                }
            }
            REQ_SAVE_PDF -> {
                val src = pendingExportSourceFile
                if (src != null && src.exists()) {
                    try {
                        FileInputStream(src).use { input ->
                            contentResolver.openOutputStream(uri)?.use { output ->
                                input.copyTo(output)
                            }
                        }
                        showBanner("Saved PDF report (${src.name}) to device storage!")
                    } catch (e: Exception) {
                        showBanner("Failed to save PDF: ${e.message}")
                    }
                }
            }
            REQ_EXPORT_CSV -> {
                try {
                    val csv = db.exportAllWorkoutsCsv(weightUnit)
                    contentResolver.openOutputStream(uri)?.use { it.write(csv.toByteArray(Charsets.UTF_8)) }
                    showBanner("Saved complete workout history CSV to device storage!")
                } catch (e: Exception) {
                    showBanner("CSV export failed: ${e.message}")
                }
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == NativeHardwareBridge.REQ_HEALTH_PERMISSIONS) {
            val anyGranted = grantResults.any { it == android.content.pm.PackageManager.PERMISSION_GRANTED }
            showBanner(
                if (anyGranted) "✓ Health Connect permission granted! Tap Sync to Health Connect again to write your session."
                else "Health Connect permission not granted — workouts remain safely stored in Offline SQLite."
            )
        }
    }

    /**
     * Interactive Claymorphism 3D APK Design Studio & 4-Screen Wireframe Showcase Dialog.
     * Displays live Claymorphic surfaces, color swatches, 3-layer bevel formulas, and 4 screen wireframes.
     */
    private fun showClaymorphismDesignStudioDialog() {
        HyperLogTelemetryLogger.logEvent(this, db, "ACTION", "ui", "claymorphism_studio_opened")
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = UiKit.dp(this@MainActivity, 16)
            setPadding(p, p, p, p)
            setBackgroundColor(UiKit.COL_BG)
        }
        scroll.addView(root)

        root.addView(UiKit.text(this, "Claymorphism 3D Design System (v4.0)", 16.5f, UiKit.COL_TEXT_DARK, bold = true))
        root.addView(UiKit.text(
            this,
            "Plump 22dp squircle clay cards, smooth top-to-bottom pastel gradients, dual-inset specular + rim bevels, and sunken clay inputs with 15.1:1 WCAG AAA contrast.",
            11.5f,
            UiKit.COL_TEXT_MID
        ))
        root.addView(UiKit.spacerV(this, 10))

        // Theme Quick Switch Row inside Studio
        val modeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(AppThemeMode.CLAYMORPHISM, AppThemeMode.CLAY_DARK).forEachIndexed { idx, m ->
            modeRow.addView(UiKit.chip(this, m.label, UiKit.themeMode == m) {
                UiKit.themeMode = m
                savePrefs()
                refreshShellTheme()
            }.apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    if (idx == 0) rightMargin = UiKit.dp(this@MainActivity, 6)
                }
            })
        }
        root.addView(modeRow)
        root.addView(UiKit.spacerV(this, 10))

        // Color Palette Swatches Card
        val palCard = UiKit.card(this, padDp = 12)
        palCard.addView(UiKit.text(this, "1. Claymorphic Color Palette & Contrast", 13.5f, UiKit.COL_TEXT_DARK, bold = true))
        palCard.addView(UiKit.spacerV(this, 6))
        listOf(
            Triple("Porcelain Canvas", "#F3F1FF", 0xFFF3F1FF.toInt()),
            Triple("Alabaster Clay Card", "#FAF9FF -> #F4F2FF", 0xFFFAF9FF.toInt()),
            Triple("Recessed Lilac Input", "#E6E4F8 (Inset)", 0xFFE6E4F8.toInt()),
            Triple("Royal Indigo 3D CTA", "#6366F1 -> #4338CA", 0xFF4F46E5.toInt()),
            Triple("Emerald MAV Clay", "#34D399 -> #059669", 0xFF10B981.toInt()),
            Triple("Obsidian Ink (15.1:1)", "#16182C", 0xFF16182C.toInt())
        ).forEach { (name, hex, colorInt) ->
            val swRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = UiKit.dp(this@MainActivity, 5)
                }
            }
            val swatch = View(this).apply {
                background = UiKit.roundedBg(colorInt, 7f, this@MainActivity, UiKit.COL_BORDER, 1f)
                val sz = UiKit.dp(this@MainActivity, 22)
                layoutParams = LinearLayout.LayoutParams(sz, sz).apply {
                    rightMargin = UiKit.dp(this@MainActivity, 8)
                }
            }
            swRow.addView(swatch)
            swRow.addView(UiKit.text(this, name, 12f, UiKit.COL_TEXT_DARK, bold = true).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            swRow.addView(UiKit.text(this, hex, 11f, UiKit.COL_TEXT_MUTED, tabular = true))
            palCard.addView(swRow)
        }
        root.addView(palCard)

        // 4-Screen APK Wireframes Card
        val wfCard = UiKit.card(this, padDp = 12)
        wfCard.addView(UiKit.text(this, "2. 4-Screen APK Claymorphic Wireframes", 13.5f, UiKit.COL_TEXT_DARK, bold = true))
        wfCard.addView(UiKit.spacerV(this, 6))
        listOf(
            "Screen A · Set Tracker (Day Zero)" to "Floating Clay Header -> Week 1 · Day 1 Hero Cushion -> Recessed kg/reps/RIR Wells -> Plump Emerald Checkmark CTA",
            "Screen B · 13-Region Anatomy & Streak" to "Anterior/Posterior Clay Toggle -> Interactive SVG Muscle Landmarks -> 0d Day-Zero Streak & MEV-MAV Volume Bars",
            "Screen C · First-10 Library & Offline Vault" to "Recessed Clay Search Bar -> Instant First-10 Exercise Cards (+10 Scroll-to-Load) -> Airplane-Mode Demo Video Vault",
            "Screen D · Telemetry & Isolated Vaults" to "Isolated Per-User SQLite Vault Switcher -> Soft/Midnight Clay Theme Selector -> 500-Event Ring Buffer Archive/Purge"
        ).forEach { (title, spec) ->
            wfCard.addView(UiKit.text(this, title, 12f, UiKit.COL_ACCENT, bold = true))
            wfCard.addView(UiKit.text(this, spec, 11f, UiKit.COL_TEXT_MID))
            wfCard.addView(UiKit.spacerV(this, 6))
        }
        root.addView(wfCard)

        AlertDialog.Builder(this, UiKit.dialogTheme())
            .setView(scroll)
            .setPositiveButton("Done", null)
            .show()
    }
}

